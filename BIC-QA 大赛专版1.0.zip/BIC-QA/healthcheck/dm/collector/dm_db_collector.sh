#!/bin/bash
# 达梦数据库健康检查采集工具
# 使用 disql 连接数据库，使用 ssh 连接操作系统
# BIC-QA 单文件输出：UTF-8，SECTION:metadata + 各数据区块（db_type=2103）；章节碎片仅写临时目录 FRAG_DIR，由 -o 指定终包路径

set -Eeo pipefail
set -u
IFS=$'\n\t'

# 尽量统一到 UTF-8 运行环境，避免中文章节标题乱码
export PYTHONIOENCODING=UTF-8
ensure_utf8_locale() {
    local loc
    if ! command -v locale >/dev/null 2>&1; then
        return 0
    fi
    for loc in C.UTF-8 en_US.UTF-8 zh_CN.UTF-8; do
        if locale -a 2>/dev/null | tr '[:upper:]' '[:lower:]' | grep -q "^$(echo "$loc" | tr '[:upper:]' '[:lower:]')$"; then
            export LANG="$loc"
            export LC_ALL="$loc"
            return 0
        fi
    done
    return 0
}
ensure_utf8_locale

# 调用时的工作目录（随后会 cd 到脚本目录；-o 无绝对路径时相对此目录）
INVOCATION_CWD="$(pwd -L 2>/dev/null || pwd)"

# 脚本目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 默认配置
DEFAULT_LOG_DIR="./logs"
DEFAULT_LOG_LEVEL="INFO"
DEFAULT_OS_PORT=22
DEFAULT_DB_PORT=5236
DEFAULT_SQL_TIMEOUT=180  # SQL执行超时时间（秒）

# 全局变量
DB_HOST=""
DB_PORT=$DEFAULT_DB_PORT
DB_USERNAME="SYSDBA"
DB_PASSWORD=""
DBNAME=""
DM_HOME=""
DISQL_CMD="disql"
LD_LIBRARY_PATH_OVERRIDE=""    # --ld-library-path；显式指定动态库搜索路径（覆盖/追加）
OS_HOST=""
OS_PORT=$DEFAULT_OS_PORT
OS_USERNAME=""
OS_PASSWORD=""
OS_SSH_KEY_PATH=""
OS_SSH_KEY_USER="root"
LOG_DIR=$DEFAULT_LOG_DIR
LOG_LEVEL=$DEFAULT_LOG_LEVEL
QUIET_LOG=false
NO_LOG_FILE=false
OS_COLLECT_INTERVAL=0
OS_COLLECT_COUNT=0
DB_COLLECT_INTERVAL=30
SQL_TIMEOUT=$DEFAULT_SQL_TIMEOUT
LOCAL_MODE=false  # 本地采集模式标志
LOCAL_MODE_FROM_ARG=false  # 是否通过命令行明确指定了本地模式

# BIC-QA 平台采集文件（SECTION 格式）
COLLECT_START_TIME=""          # 格式 YYYY-MM-DD HH:MM:SS，run_collection 内设置
COLLECT_END_TIME=""
TOOL_CODE="dm_db_health_check" # 对应规范 tool_code
BIC_DEBUG=false                # 元数据 debug（布尔，禁止加引号）
OUTPUT_ARG=""                  # -o / --output 原始参数；空则默认 DM_bic_qa_data_<PROGRAM_START_TIME>.txt
BIC_QA_OUT_FILE=""             # 解析后的终包绝对路径
PERMISSIVE_HOST_LOGS=false      # 为 true（-f）时允许覆盖已存在输出文件；不影响采集项执行
KEEP_TMP_ON_EXIT=false         # --debug 时保留 /tmp 目录用于排障
SQLTEXT_MAX_LEN=0              # --sqllen；>0 时截断 topsql::sqltext 的 SQL_TEXT 长度
FILENAME_FIX=false             # --filenamefix；为 true 时输出文件名规则：<yyyy-dd-mm-hh24-mi-ss>-CxxMxx-<原文件名>
MAX_CPU_USAGE_PCT="0"
MAX_MEM_USAGE_PCT="0"

# 数据库状态全局变量
ARCHIVED_ENABLED=false
INSTANCE_NAME=""
WAITEVENT_SNAPSHOT1=""  # 等待事件第一次快照数据
TIME_MODEL_SNAPSHOT1=""  # TIME MODEL第一次快照数据

# 程序启动时间戳
PROGRAM_START_TIME=$(date +%Y%m%d_%H%M%S)
PROGRAM_START_TIME_FILEFIX=$(date +%Y-%m-%d-%H-%M-%S)
PROGRAM_START_TIME_FILEFIX_USER=$(date +%Y-%d-%m-%H-%M-%S)

# 日志文件路径
LOG_FILE=""

# 临时文件目录
TMP_DIR="/tmp/dm_collector_$$"
mkdir -p "$TMP_DIR"
# 合并 BIC-QA 终包前的章节碎片目录（随 TMP_DIR 删除）；不向 hcdata 时间戳子目录散落 param.txt 等
FRAG_DIR="${TMP_DIR}/dm_sections"
mkdir -p "$FRAG_DIR"
cleanup_tmp_dir() {
    if [ "$KEEP_TMP_ON_EXIT" = "true" ]; then
        log INFO "DEBUG 模式: 保留临时目录用于排障: $TMP_DIR"
        return 0
    fi
    rm -rf "$TMP_DIR"
}
trap cleanup_tmp_dir EXIT

# 统一错误诊断：避免 set -e 直接退出但无明确报错信息
on_error() {
    local exit_code=$?
    local line_no="${1:-?}"
    local cmd="${2:-<unknown>}"
    # logger 未初始化前也要能看到错误
    if command -v log >/dev/null 2>&1; then
        log ERROR "脚本执行失败: exit_code=${exit_code}, line=${line_no}, cmd=${cmd}"
    else
        echo "[ERROR] 脚本执行失败: exit_code=${exit_code}, line=${line_no}, cmd=${cmd}" >&2
    fi
    return "$exit_code"
}
trap 'on_error "${LINENO}" "${BASH_COMMAND}"' ERR

# 快照「时间 + 正文」分隔符：正文为多行且含 |，禁止用单字符 | 拼接（否则 cut 破坏 SYSSTAT/等待事件/TIME_MODEL 解析）
_DM_SNAP_RS=$'\x1e'

# 文本日志块：去重（保留时间上最后一条相同内容）后最多保留 n 行（需 tac）
_dm_log_dedupe_tail_max() {
    local n="${1:-50}"
    if command -v tac >/dev/null 2>&1; then
        tac | awk '!seen[$0]++' | tac | tail -n "$n"
    else
        tail -n "$n"
    fi
}

# 根据 -o 设置 BIC_QA_OUT_FILE：绝对路径原样；否则相对 INVOCATION_CWD
bic_qa_set_output_path() {
    local raw="${1:-}"
    if [ -z "$raw" ]; then
        raw="DM_bic_qa_data_${PROGRAM_START_TIME}.txt"
    fi
    if [ "$FILENAME_FIX" = "true" ]; then
        local dir_part base_part name_part ext_part
        dir_part="$(dirname "$raw")"
        base_part="$(basename "$raw")"
        if [[ "$base_part" == *.* ]]; then
            name_part="${base_part%.*}"
            ext_part=".${base_part##*.}"
        else
            name_part="$base_part"
            ext_part=""
        fi
        raw="${dir_part%/}/${PROGRAM_START_TIME_FILEFIX_USER}-C00M00-${name_part}${ext_part}"
        raw="${raw#./}"
    fi
    if [[ "$raw" == /* ]]; then
        BIC_QA_OUT_FILE="$raw"
    else
        BIC_QA_OUT_FILE="${INVOCATION_CWD%/}/${raw#./}"
    fi
    mkdir -p "$(dirname "$BIC_QA_OUT_FILE")"
}

_update_peak_pct() {
    local current="$1"
    local peak="$2"
    awk -v c="$current" -v p="$peak" 'BEGIN{
        cv=(c+0); pv=(p+0);
        if(cv>pv) printf "%.2f", cv; else printf "%.2f", pv;
    }'
}

_fmt_peak_int() {
    local v="$1"
    awk -v x="$v" 'BEGIN{
        n=int(x+0.5);
        if(n<0) n=0;
        if(n<10) printf "0%d", n; else printf "%d", n;
    }'
}

bic_qa_apply_filenamefix_metrics() {
    [ "$FILENAME_FIX" = "true" ] || return 0
    [ -n "$BIC_QA_OUT_FILE" ] || return 0
    [ -f "$BIC_QA_OUT_FILE" ] || return 0

    local dir base cpu_i mem_i new_base new_path
    dir="$(dirname "$BIC_QA_OUT_FILE")"
    base="$(basename "$BIC_QA_OUT_FILE")"
    cpu_i="$(_fmt_peak_int "$MAX_CPU_USAGE_PCT")"
    mem_i="$(_fmt_peak_int "$MAX_MEM_USAGE_PCT")"

    if echo "$base" | grep -q -- "-C00M00-"; then
        new_base="$(echo "$base" | sed -E "s/-C00M00-/-C${cpu_i}M${mem_i}-/")"
    else
        new_base="${PROGRAM_START_TIME_FILEFIX_USER}-C${cpu_i}M${mem_i}-${base}"
    fi
    new_path="${dir%/}/${new_base}"
    if [ "$new_path" != "$BIC_QA_OUT_FILE" ]; then
        mv -f "$BIC_QA_OUT_FILE" "$new_path"
        BIC_QA_OUT_FILE="$new_path"
        log INFO "已按 --filenamefix 规则更新文件名: $BIC_QA_OUT_FILE"
    fi
}

_update_peak_pct() {
    local current="$1"
    local peak="$2"
    awk -v c="$current" -v p="$peak" 'BEGIN{
        cv=(c+0); pv=(p+0);
        if(cv>pv) printf "%.2f", cv; else printf "%.2f", pv;
    }'
}

_fmt_peak_int() {
    local v="$1"
    awk -v x="$v" 'BEGIN{
        n=int(x+0.5);
        if(n<0) n=0;
        if(n<10) printf "0%d", n; else printf "%d", n;
    }'
}

# ==================== 工具函数 ====================

# 日志函数
log() {
    local level=$1
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    if [ "$NO_LOG_FILE" != "true" ] && [ -n "$LOG_FILE" ]; then
        echo "[$timestamp] - $level - $message" >> "$LOG_FILE"
    fi
    if [ "$QUIET_LOG" = "true" ]; then
        return 0
    fi
    
    case $level in
        ERROR)
            echo "[ERROR] $message" >&2
            ;;
        WARNING)
            echo "[WARNING] $message" >&2
            ;;
        INFO)
            echo "[INFO] $message"
            ;;
        DEBUG)
            if [ "$LOG_LEVEL" = "DEBUG" ]; then
                echo "[DEBUG] $message"
            fi
            ;;
    esac
}

# 初始化日志
init_logger() {
    local log_path=$1
    local log_level=$2
    if [ "$NO_LOG_FILE" = "true" ]; then
        LOG_FILE=""
        return 0
    fi
    
    # 生成时间戳
    local timestamp_str=$(date +%Y%m%d_%H%M%S)
    
    # 解析日志路径
    if [ -d "$log_path" ]; then
        LOG_FILE="$log_path/dm_collector_${timestamp_str}.log"
    elif [ ! -f "$log_path" ] && [[ ! "$log_path" =~ \.[^/]+$ ]]; then
        # 路径不存在且没有扩展名，视为目录
        mkdir -p "$log_path"
        LOG_FILE="$log_path/dm_collector_${timestamp_str}.log"
    else
        # 文件路径，在文件名中插入时间戳
        local log_dir=$(dirname "$log_path")
        local log_filename=$(basename "$log_path")
        if [ -z "$log_dir" ] || [ "$log_dir" = "." ]; then
            log_dir="."
        fi
        local name="${log_filename%.*}"
        local ext="${log_filename##*.}"
        if [ -z "$name" ]; then
            name="dm_collector"
        fi
        if [ "$name" = "$ext" ]; then
            ext="log"
        fi
        mkdir -p "$log_dir"
        LOG_FILE="$log_dir/${name}_${timestamp_str}.${ext}"
    fi
    
    # 创建日志文件
    touch "$LOG_FILE"
    
    log INFO "============================================================"
    log INFO "达梦数据库健康检查采集工具启动"
    log INFO "日志文件位置: $(realpath "$LOG_FILE")"
    log INFO "============================================================"
}

# 检查命令是否存在
check_command() {
    local cmd=$1
    local level=${2:-ERROR}
    
    if ! command -v "$cmd" >/dev/null 2>&1; then
        if [ "$level" != "silent" ]; then
            log "$level" "命令 $cmd 未安装，请先安装"
        fi
        return 1
    fi
    return 0
}

# 解析 disql 路径（兼容 cron 最小环境）
resolve_disql_cmd() {
    if [ -n "$DM_HOME" ] && [ -x "$DM_HOME/bin/disql" ]; then
        DISQL_CMD="$DM_HOME/bin/disql"
        export PATH="$DM_HOME/bin:$PATH"
        if [ -n "$LD_LIBRARY_PATH_OVERRIDE" ]; then
            export LD_LIBRARY_PATH="$LD_LIBRARY_PATH_OVERRIDE"
        else
            # 达梦常见库在 bin/ 或 lib/ 目录下
            if [ -d "$DM_HOME/lib" ]; then
                export LD_LIBRARY_PATH="$DM_HOME/bin:$DM_HOME/lib:${LD_LIBRARY_PATH:-}"
            else
                export LD_LIBRARY_PATH="$DM_HOME/bin:${LD_LIBRARY_PATH:-}"
            fi
        fi
        return 0
    fi

    local cmd_path
    cmd_path=$(command -v disql 2>/dev/null || true)
    if [ -n "$cmd_path" ] && [ -x "$cmd_path" ]; then
        DISQL_CMD="$cmd_path"
        if [ -z "$DM_HOME" ]; then
            DM_HOME=$(dirname "$(dirname "$cmd_path")")
        fi
        if [ -n "$LD_LIBRARY_PATH_OVERRIDE" ]; then
            export LD_LIBRARY_PATH="$LD_LIBRARY_PATH_OVERRIDE"
        else
            if [ -d "$DM_HOME/lib" ]; then
                export LD_LIBRARY_PATH="$DM_HOME/bin:$DM_HOME/lib:${LD_LIBRARY_PATH:-}"
            else
                export LD_LIBRARY_PATH="$DM_HOME/bin:${LD_LIBRARY_PATH:-}"
            fi
        fi
        return 0
    fi

    local candidates=(
        "/dmdbms/bin/disql"
        "/opt/dmdbms/bin/disql"
        "/usr/local/dmdbms/bin/disql"
        "/home/dmdba/dmdbms/bin/disql"
    )
    local p=""
    for p in "${candidates[@]}"; do
        if [ -x "$p" ]; then
            DISQL_CMD="$p"
            if [ -z "$DM_HOME" ]; then
                DM_HOME=$(dirname "$(dirname "$p")")
            fi
            export PATH="$(dirname "$p"):$PATH"
            if [ -n "$LD_LIBRARY_PATH_OVERRIDE" ]; then
                export LD_LIBRARY_PATH="$LD_LIBRARY_PATH_OVERRIDE"
            else
                if [ -d "$DM_HOME/lib" ]; then
                    export LD_LIBRARY_PATH="$(dirname "$p"):$DM_HOME/lib:${LD_LIBRARY_PATH:-}"
                else
                    export LD_LIBRARY_PATH="$(dirname "$p"):${LD_LIBRARY_PATH:-}"
                fi
            fi
            return 0
        fi
    done
    return 1
}

# 检查必需的命令
check_required_commands() {
    local missing_commands=()

    # 检查disql命令（先自动解析，兼容cron）
    if ! resolve_disql_cmd; then
        log ERROR "未找到disql命令（cron环境常见为PATH过短）"
        log ERROR "当前DM_HOME: ${DM_HOME:-<empty>}"
        log ERROR "当前PATH: ${PATH:-<empty>}"
        log ERROR "建议：1) crontab 显式传 --dm-home；2) crontab 头部设置 PATH；3) 使用绝对路径调用脚本。"
        missing_commands+=("disql")
    else
        log INFO "disql路径: $DISQL_CMD"
    fi
    
    # 只有在非本地模式下才检查ssh命令
    if [ "$LOCAL_MODE" != "true" ]; then
        if ! check_command ssh; then
            missing_commands+=("ssh")
        fi
    fi
    
    if [ ${#missing_commands[@]} -gt 0 ]; then
        log ERROR "缺少必需的命令: ${missing_commands[*]}"
        return 1
    fi
    
    return 0
}

# ==================== DISQL相关函数 ====================

# 构建disql连接字符串
build_disql_conn() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local esc_pwd="${password//\"/\\\"}"
    
    if [ "$LOCAL_MODE" = "true" ]; then
        # 本地模式
        # disql 对 #/@ 等特殊字符敏感，口令统一用双引号包裹
        echo "${username}/\"${esc_pwd}\""
    else
        # 远程模式
        echo "${username}/\"${esc_pwd}\"@${host}:${port}"
    fi
}

# 获取disql可执行文件路径
get_disql_cmd() {
    echo "${DISQL_CMD:-disql}"
}

# 执行SQL语句
execute_sql() {
    local sql=$1
    local disql_cmd=$(get_disql_cmd)
    local conn_str=$(build_disql_conn "$DB_HOST" "$DB_PORT" "$DB_USERNAME" "$DB_PASSWORD")
    local tagged_sql="/* DMHC_COLLECTOR */"$'\n'"$sql"
    
    log DEBUG "执行SQL: $sql"
    
    # 首次执行（-S 静默模式）
    local result rc primary_rc
    set +e
    result=$(timeout ${SQL_TIMEOUT}s "$disql_cmd" -S "$conn_str" <<EOF 2>&1
SET ECHO OFF
SET FEEDBACK OFF
SET LINESIZE 255
set pages 999
set LINESHOW OFF
$tagged_sql
exit;
EOF
)
    rc=$?
    primary_rc=$rc
    set -e
    
    # 某些环境下 -S + 会话设置会出现“无输出但非报错”，空结果时回退一次非 -S
    if [ -z "$(echo "$result" | tr -d '[:space:]')" ]; then
        log WARN "SQL返回空结果，回退重试(非-S模式)"
        local retry_result retry_rc
        set +e
        retry_result=$(timeout ${SQL_TIMEOUT}s "$disql_cmd" "$conn_str" <<EOF 2>&1
SET ECHO OFF
SET FEEDBACK OFF
SET LINESIZE 255
set pages 999
set LINESHOW OFF
$tagged_sql
exit;
EOF
)
        retry_rc=$?
        set -e
        if [ -n "$(echo "$retry_result" | tr -d '[:space:]')" ]; then
            result="$retry_result"
            rc=$retry_rc
        fi
        if [ "$BIC_DEBUG" = "true" ]; then
            {
                echo "=== execute_sql fallback debug ==="
                echo "primary_rc=$primary_rc"
                echo "retry_rc=$retry_rc"
                echo "sql=$sql"
                echo ""
                echo "----- retry_result -----"
                echo "$retry_result"
            } > "${TMP_DIR}/debug_sql_fallback_last.txt"
        fi
    fi
    
    if [ "$rc" -ne 0 ]; then
        log WARN "SQL执行返回非零状态: rc=$rc"
    fi

    # 清理 disql 附加尾行（执行耗时/执行号），避免混入业务数据与乱码
    result=$(echo "$result" | sed -E \
        -e '/^[[:space:]]*已用时间.*执行号[:：]?[[:space:]]*[0-9?]+\.?[[:space:]]*$/d' \
        -e '/^[[:space:]]*used[[:space:]]+time.*Execute[[:space:]]+id[:：]?[[:space:]]*[0-9?]+\.?[[:space:]]*$/Id' \
        -e '/^[[:space:]]*.*\([[:space:]]*(毫秒|ms)[[:space:]]*\).*执行号[:：]?[[:space:]]*[0-9?]+\.?[[:space:]]*$/d')

    echo "$result"
}

# 执行SQL并保存结果到文件
execute_sql_to_file() {
    local sql=$1
    local output_file=$2
    
    local result=$(execute_sql "$sql")
    echo "$result" > "$output_file"
    if [ "$BIC_DEBUG" = "true" ]; then
        local base_name
        base_name="$(basename "$output_file")"
        printf "=== sql ===\n%s\n\n=== result ===\n%s\n" "$sql" "$result" > "${TMP_DIR}/debug_sql_${base_name}"
    fi
}

# 修复已知中文表头乱码，统一改为稳定英文列名，避免跨平台编码误判
normalize_known_mojibake_headers() {
    local target_file=$1
    [ -f "$target_file" ] || return 0

    sed -i \
        -e 's/琛ㄧ┖闂村悕绉?/TABLESPACE_NAME/g' \
        -e 's/琛ㄧ┖闂村ぇ灏?M)/TOTAL_MB/g' \
        -e 's/琛ㄧ┖闂村墿浣欏ぇ灏?M)/FREE_MB/g' \
        -e 's/琛ㄧ┖闂翠娇鐢ㄥぇ灏?M)/USED_MB/g' \
        -e 's/琛ㄧ┖闂村ぇ灏?G)/TOTAL_GB/g' \
        -e 's/琛ㄧ┖闂村墿浣欏ぇ灏?G)/FREE_GB/g' \
        -e 's/琛ㄧ┖闂翠娇鐢ㄥぇ灏?G)/USED_GB/g' \
        -e 's/浣跨敤鐜?%/USED_PCT/g' \
        "$target_file"
}

# ==================== SSH相关函数 ====================

# 执行SSH命令
execute_ssh() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local cmd=$6
    
    log DEBUG "执行SSH命令: $cmd"
    
    local result
    if [ -n "$ssh_key_path" ]; then
        result=$(ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 -i "$ssh_key_path" -p "$port" "${username}@${host}" "$cmd" 2>&1)
    else
        result=$(sshpass -p "$password" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 -p "$port" "${username}@${host}" "$cmd" 2>&1)
    fi
    
    echo "$result"
}

# 本地执行命令
execute_local() {
    local cmd=$1
    log DEBUG "本地执行命令: $cmd"
    eval "$cmd" 2>&1
}

# 在目标 OS 上执行本机已写入的临时脚本（stdin 传脚本，避免多行与引号在 SSH 中断裂）
run_os_script_file_on_target() {
    local script_path=$1
    if [ ! -f "$script_path" ]; then
        echo "内部错误: 采集脚本不存在 $script_path"
        return 1
    fi
    if [ "$LOCAL_MODE" = "true" ]; then
        bash "$script_path" 2>&1
        return
    fi
    if [ -n "$OS_SSH_KEY_PATH" ] && [ -f "$OS_SSH_KEY_PATH" ]; then
        ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 -i "$OS_SSH_KEY_PATH" -p "$OS_PORT" "${OS_USERNAME}@${OS_HOST}" "bash -s" < "$script_path" 2>&1
    else
        sshpass -p "$OS_PASSWORD" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 -p "$OS_PORT" "${OS_USERNAME}@${OS_HOST}" "bash -s" < "$script_path" 2>&1
    fi
}

# 仅采集 dmesg 最近1小时风险信息（纯文本，输出到 os_host_alerts.txt）
collect_host_dmesg_and_alerts() {
    log INFO "采集主机 dmesg 最近1小时健康相关告警..."
    local out="$FRAG_DIR/os_host_alerts.txt"
    cat > "${TMP_DIR}/host_alerts.sh" << 'HOST_ALERTS_SH'
#!/bin/bash
# 在数据库服务器本地执行：仅 dmesg
set +e
_dm_tail100_dedupe() {
    if command -v tac >/dev/null 2>&1; then
        tac | awk '!seen[$0]++' | tac | tail -n 100
    else
        tail -n 100
    fi
}
echo "=== 主机告警摘要（dmesg）==="
echo "主机: $(hostname 2>/dev/null)  采集时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""
echo "=== dmesg 近1小时重点告警 ==="
if command -v dmesg >/dev/null 2>&1; then
    DOUT=$(dmesg -T --since "1 hour ago" 2>/dev/null)
    if [ -z "$DOUT" ]; then
        # 兼容不支持 --since 的环境，回退全量后按关键字过滤
        DOUT=$(dmesg -T 2>/dev/null)
    fi
    [ -n "$DOUT" ] || DOUT=$(dmesg 2>/dev/null)
    if [ -z "$DOUT" ]; then
        echo "无权限访问"
    else
        DMSG=$(echo "$DOUT" | grep -iE "error|fail|fault|i/o|oom|out of memory|killed process|ext4|xfs|nvme|ata[0-9]|scsi|hung task|soft lockup|hard lockup|watchdog|read-only|reset|segfault|corrupt|timeout|blocked for more than|call trace" | _dm_tail100_dedupe)
        if [ -n "$DMSG" ]; then
            echo "$DMSG"
        else
            echo "近1小时未发现风险日志"
        fi
    fi
else
    echo "无权限访问"
fi
HOST_ALERTS_SH
    chmod +x "${TMP_DIR}/host_alerts.sh" 2>/dev/null || true
    {
        run_os_script_file_on_target "${TMP_DIR}/host_alerts.sh" || echo "（主机 dmesg/系统告警采集失败或为权限限制）"
    } > "$out" 2>&1
    log INFO "dmesg 近1小时健康告警文本: $out"
}

# ==================== 数据采集函数 ====================

# 采集数据库参数
collect_instance_info() {
    local output_file="$FRAG_DIR/instance_info.txt"
    log INFO "Collecting instance info..."

    local sql="select name,instance_name,instance_number,HOST_NAME,SVR_VERSION,DB_VERSION,START_TIME,STATUS\$,MODE\$,DSC_SEQNO,DSC_ROLE from v\$instance;"
    execute_sql_to_file "$sql" "$output_file"

    log INFO "Instance info collection completed: $output_file"
}

# 采集数据库参数
collect_db_params() {
    local output_file="$FRAG_DIR/param.txt"
    log INFO "采集数据库参数..."
    
    local sql="select name,value,default_value,isdefault from v\$parameter;"
    execute_sql_to_file "$sql" "$output_file"
    
    log INFO "参数采集完成: $output_file"
}

# 采集归档目录
collect_archive_path() {
    local output_file="$FRAG_DIR/archive.txt"
    log INFO "采集归档目录..."
    
    local sql="SELECT PARA_VALUE FROM V\$DM_INI WHERE PARA_NAME = 'SYSTEM_PATH';"
    execute_sql_to_file "$sql" "$output_file"
    
    log INFO "归档目录采集完成: $output_file"
}

# 采集sysstat数据（采集5次，每次间隔30秒）
# 注意：以"time(ms)"结尾的指标会被过滤，这些指标在time_model中单独采集
collect_sysstat_multiple() {
    log INFO "Start collecting SYSSTAT snapshots (5 rounds, interval ${DB_COLLECT_INTERVAL}s)..."
    
    local sql="select id,name,stat_val from v\$sysstat where stat_val>0;"
    local snapshot_count=5
    local interval=${DB_COLLECT_INTERVAL}
    
    # 数组存储所有快照
    declare -a SYSSTAT_SNAPSHOTS
    
    for ((i=1; i<=snapshot_count; i++)); do
        log INFO "Collecting SYSSTAT snapshot ${i}/${snapshot_count}..."
        local snapshot=$(execute_sql "$sql")
        local snapshot_time=$(date '+%Y-%m-%d %H:%M:%S')
        if [ "$BIC_DEBUG" = "true" ]; then
            printf "=== sysstat snapshot %s @ %s ===\n%s\n" "$i" "$snapshot_time" "$snapshot" > "${TMP_DIR}/debug_sysstat_snapshot_${i}.txt"
        fi
        
        # 保存快照：时间 + RS + 正文（正文多行且含 |，禁止 TIMESTAMP:...| 单管道拼接）
        SYSSTAT_SNAPSHOTS[$i]="${snapshot_time}${_DM_SNAP_RS}${snapshot}"
        
        # 最后一次不等待
        if [ $i -lt $snapshot_count ]; then
            log INFO "Waiting ${interval}s before next snapshot..."
            sleep $interval
        fi
    done
    
    # 计算增量并生成最终结果（过滤time指标）
    log INFO "Computing SYSSTAT deltas (excluding time(ms) metrics)..."
    local output_file="$FRAG_DIR/sysstat.txt"
    
    {
        echo "=== SYSSTAT Delta (per-second average between snapshots) ==="
        echo ""
        echo "Note: metrics ending with 'time(ms)' are moved to time_model"
        echo ""
        
        for ((i=2; i<=snapshot_count; i++)); do
            local prev_snapshot="${SYSSTAT_SNAPSHOTS[$((i-1))]}"
            local curr_snapshot="${SYSSTAT_SNAPSHOTS[$i]}"
            
            local prev_time="${prev_snapshot%%${_DM_SNAP_RS}*}"
            local curr_time="${curr_snapshot%%${_DM_SNAP_RS}*}"
            local prev_data="${prev_snapshot#*${_DM_SNAP_RS}}"
            local curr_data="${curr_snapshot#*${_DM_SNAP_RS}}"
            
            echo "--- Delta $((i-1)): ${prev_time} -> ${curr_time} (interval ${interval}s) ---"
            echo ""
            
            # 解析并计算增量
            echo "id          name                                delta_per_sec       "
            echo "----------- ----------------------------------- --------------------"
            log INFO "Computing SYSSTAT delta $((i-1))/$((snapshot_count-1))..." >&2
            declare -A curr_val_map
            while IFS= read -r curr_line; do
                if [[ "$curr_line" =~ ^[[:space:]]*[0-9]+[[:space:]]+([0-9]+)[[:space:]]+(.+)[[:space:]]+([0-9]+)[[:space:]]*$ ]]; then
                    curr_val_map["${BASH_REMATCH[1]}"]="${BASH_REMATCH[3]}"
                elif [[ "$curr_line" =~ ^[[:space:]]*([0-9]+)[[:space:]]+(.+)[[:space:]]+([0-9]+)[[:space:]]*$ ]]; then
                    curr_val_map["${BASH_REMATCH[1]}"]="${BASH_REMATCH[3]}"
                fi
            done <<< "$curr_data"

            while IFS= read -r prev_line; do
                local stat_id="" stat_name="" prev_val=""
                if [[ "$prev_line" =~ ^[[:space:]]*[0-9]+[[:space:]]+([0-9]+)[[:space:]]+(.+)[[:space:]]+([0-9]+)[[:space:]]*$ ]]; then
                    stat_id="${BASH_REMATCH[1]}"
                    stat_name="${BASH_REMATCH[2]}"
                    prev_val="${BASH_REMATCH[3]}"
                elif [[ "$prev_line" =~ ^[[:space:]]*([0-9]+)[[:space:]]+(.+)[[:space:]]+([0-9]+)[[:space:]]*$ ]]; then
                    stat_id="${BASH_REMATCH[1]}"
                    stat_name="${BASH_REMATCH[2]}"
                    prev_val="${BASH_REMATCH[3]}"
                else
                    continue
                fi

                stat_name=$(echo "$stat_name" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                if [[ "$stat_name" =~ time\(ms\)$ ]]; then
                    continue
                fi

                local curr_val="${curr_val_map[$stat_id]:-}"
                if [[ "$prev_val" =~ ^[0-9]+$ ]] && [[ "$curr_val" =~ ^[0-9]+$ ]]; then
                    local delta=$((curr_val - prev_val))
                    if [ $delta -ge 0 ]; then
                        local delta_per_sec
                        delta_per_sec=$(awk "BEGIN {printf \"%.2f\", $delta / $interval}")
                        printf "%-11s %-35s %20s\n" "$stat_id" "$stat_name" "$delta_per_sec"
                    fi
                fi
            done <<< "$prev_data"
            
            echo ""
        done
    } > "$output_file"
    
    log INFO "SYSSTAT collection completed: $output_file"
}

# 采集REDO LOG数据
collect_redo() {
    local output_file="$FRAG_DIR/redo.txt"
    log INFO "采集REDO LOG数据..."
    
    local sql="SELECT A.FILE_ID, A.PATH, A.CLIENT_PATH, A.RLOG_SIZE, B.FREE_SPACE, B.TOTAL_SPACE, B.CUR_FILE 
from (select * from V\$RLOGFILE where true) A, 
(select * from V\$RLOG where true) B;"
    execute_sql_to_file "$sql" "$output_file"
    normalize_known_mojibake_headers "$output_file"
    
    log INFO "REDO LOG数据采集完成: $output_file"
}

# 采集表空间数据
collect_tablespace() {
    local output_file="$FRAG_DIR/tbs.txt"
    log INFO "采集表空间数据..."
    
    local sql="SELECT a.tablespace_name \"TABLESPACE_NAME\", 
total / (1024 * 1024) \"TOTAL_MB\", 
free / (1024 * 1024) \"FREE_MB\", 
(total - free) / (1024 * 1024 ) \"USED_MB\",
total / (1024 * 1024 * 1024) \"TOTAL_GB\", 
free / (1024 * 1024 * 1024) \"FREE_GB\", 
(total - free) / (1024 * 1024 * 1024) \"USED_GB\", 
round((total - free) / total, 4) * 100 \"USED_PCT\" 
FROM (SELECT tablespace_name, SUM(bytes) free FROM dba_free_space GROUP BY tablespace_name) a, 
(SELECT tablespace_name, SUM(bytes) total FROM dba_data_files GROUP BY tablespace_name) b
WHERE a.tablespace_name = b.tablespace_name;"
    execute_sql_to_file "$sql" "$output_file"
    normalize_known_mojibake_headers "$output_file"
    
    log INFO "表空间数据采集完成: $output_file"
}

# 采集ASM组信息
collect_asm_group() {
    local output_file="$FRAG_DIR/asm_group.txt"
    log INFO "采集ASM组信息..."
    
    local sql="SET PAGES 99
SELECT
    GROUP_ID,
    GROUP_NAME,
    TOTAL_MB,
    FREE_MB,
    (TOTAL_MB - FREE_MB) AS USED_MB,
    ROUND(FREE_MB * 100.0 / TOTAL_MB, 2) AS FREE_PCT
FROM
    V\$ASMGROUP;"
    execute_sql_to_file "$sql" "$output_file"
    normalize_known_mojibake_headers "$output_file"
    
    log INFO "ASM组信息采集完成: $output_file"
}

# 采集数据文件信息
collect_datafiles() {
    local output_file="$FRAG_DIR/dbfile.txt"
    log INFO "采集数据文件信息..."
    
    local sql="select path,create_time,status\$,rw_status,last_ckpt_time,modify_time,total_size,free_size,auto_extend,max_size,real_free_size from v\$datafile;"
    execute_sql_to_file "$sql" "$output_file"
    normalize_known_mojibake_headers "$output_file"
    
    log INFO "数据文件信息采集完成: $output_file"
}

# 采集回滚段信息
collect_rollback() {
    local output_file="$FRAG_DIR/rbs.txt"
    log INFO "采集回滚段信息..."
    
    local sql="SELECT ID AS TRX_ID, SESS_ID, STATUS, ROLLBACK_FLAG, START_LSN, 
(SELECT CUR_LSN FROM V\$RLOG) AS CURRENT_LSN, 
(SELECT CKPT_LSN FROM V\$CKPT) AS CHECKPOINT_LSN 
FROM V\$TRX;"
    execute_sql_to_file "$sql" "$output_file"
    normalize_known_mojibake_headers "$output_file"
    
    log INFO "回滚段信息采集完成: $output_file"
}

# 采集 TopSQL
collect_topsql() {
    local by_exec_file="$FRAG_DIR/topsql_by_exec_time.txt"
    local long_exec_file="$FRAG_DIR/topsql_long_exec_sql.txt"
    local by_mem_file="$FRAG_DIR/topsql_sql_by_mem.txt"
    local sql_exec_count_file="$FRAG_DIR/topsql_sql_exec_count.txt"
    local sql_id_list_file="$FRAG_DIR/topsql_sql_id_list.txt"
    local sqltext_file="$FRAG_DIR/topsql_sqltext.txt"
    log INFO "Collecting TopSQL data..."

    # 1) topsql::sql_by_exec_time
    local sql_by_exec_time="SELECT TOP 50 SQL_ID,START_TIME,TIME_USED/1000 TIME_USED,AFFECTED_ROWS,HARD_PARSE_FLAG FROM V\$SQL_HISTORY ORDER BY TIME_USED DESC;"
    execute_sql_to_file "$sql_by_exec_time" "$by_exec_file"

    # 2) topsql::long_exec_sql
    local sql_long_exec="SELECT TOP 50 SQL_ID,SESS_ID,SESS_SEQ,EXEC_TIME,FINISH_TIME,N_RUNS,MIN_EXEC_TIME,MAX_EXEC_TIME,TOTAL_EXEC_TIME FROM V\$SYSTEM_LONG_EXEC_SQLS ORDER BY TOTAL_EXEC_TIME DESC;"
    execute_sql_to_file "$sql_long_exec" "$long_exec_file"

    # 3) topsql::sql_by_mem
    local sql_by_mem="SELECT TOP 50 SQL_ID,MEM_USED_BY_K MEM_USED_KB,FINISH_TIME,N_RUNS RUN_COUNT FROM V\$SYSTEM_LARGE_MEM_SQLS ORDER BY MEM_USED_BY_K DESC;"
    execute_sql_to_file "$sql_by_mem" "$by_mem_file"

    # 4) topsql::sql_exec_count：按执行数量统计 TOP 50，并关注解析/硬解析
    # 说明：
    # - 执行数：SQL 在 V$SQL_HISTORY 中出现次数（EXEC_COUNT）
    # - 解析数：按硬解析标记可识别的解析次数（PARSE_COUNT）
    # - 硬解析数：HARD_PARSE_FLAG=1 的次数（HARD_PARSE_COUNT）
    local sql_exec_count="SELECT TOP 50
    SQL_ID,
    COUNT(*) AS EXEC_COUNT,
    SUM(CASE WHEN HARD_PARSE_FLAG IN (0,1) THEN 1 ELSE 0 END) AS PARSE_COUNT,
    SUM(CASE WHEN HARD_PARSE_FLAG = 1 THEN 1 ELSE 0 END) AS HARD_PARSE_COUNT
FROM V\$SQL_HISTORY
GROUP BY SQL_ID
ORDER BY EXEC_COUNT DESC;"
    execute_sql_to_file "$sql_exec_count" "$sql_exec_count_file"

    # 5) 汇总 SQL_ID（直接由 SQL 生成，避免文本解析误判）
    local sql_id_union_sql="SELECT SQL_ID FROM (SELECT TOP 50 SQL_ID FROM V\$SQL_HISTORY ORDER BY TIME_USED DESC) A
UNION
SELECT SQL_ID FROM (SELECT TOP 50 SQL_ID FROM V\$SYSTEM_LONG_EXEC_SQLS ORDER BY TOTAL_EXEC_TIME DESC) B
UNION
SELECT SQL_ID FROM (SELECT TOP 50 SQL_ID FROM V\$SYSTEM_LARGE_MEM_SQLS ORDER BY MEM_USED_BY_K DESC) C;"
    execute_sql_to_file "$sql_id_union_sql" "$sql_id_list_file"

    # 6) topsql::sqltext：按 SQL_ID 清单查询 v$sqltext
    local cleaned_sql_ids=""
    if [ -s "$sql_id_list_file" ]; then
        cleaned_sql_ids=$(awk '
            {
                gsub(/\r/, "", $0)
                if ($0 ~ /^[[:space:]]*$/) next
                if ($0 ~ /^[[:space:]]*SQL_ID[[:space:]]*$/) next
                if ($0 ~ /^[[:space:]]*---+/) next
                if ($0 ~ /rows[[:space:]]got|rows[[:space:]]fetched|used[[:space:]]time|Execute[[:space:]]id|行号/) next
                n=split($0, a, /[[:space:]]+/)
                idx=1
                while (idx<=n && a[idx]=="") idx++
                if (idx<=n && a[idx] ~ /^[0-9]+$/ && idx<n && a[idx+1] ~ /^[A-Za-z0-9_]+$/) idx++
                if (idx<=n && a[idx] ~ /^[A-Za-z0-9_]+$/) print toupper(a[idx])
            }
        ' "$sql_id_list_file" | sort -u)
    fi

    if [ -n "$cleaned_sql_ids" ]; then
        local in_clause
        in_clause=$(echo "$cleaned_sql_ids" | awk '{printf("%s'\''%s'\''", (NR==1?"":","), $1)}')
        local sql_sqltext
        if [ "$SQLTEXT_MAX_LEN" -gt 0 ]; then
            sql_sqltext="SELECT SQL_ID,SUBSTR(SQL_TEXT,1,${SQLTEXT_MAX_LEN}) AS SQL_TEXT FROM V\$SQLTEXT WHERE SQL_ID IN (${in_clause}) ORDER BY SQL_ID;"
        else
            sql_sqltext="SELECT SQL_ID,SQL_TEXT FROM V\$SQLTEXT WHERE SQL_ID IN (${in_clause}) ORDER BY SQL_ID;"
        fi
        execute_sql_to_file "$sql_sqltext" "$sqltext_file"
    else
        {
            echo "No SQL_ID collected from topsql::sql_by_exec_time, topsql::long_exec_sql and topsql::sql_by_mem"
        } > "$sqltext_file"
    fi

    log INFO "TopSQL collection completed: $by_exec_file, $long_exec_file, $by_mem_file, $sql_exec_count_file, $sqltext_file"
}

# 采集等待事件第一次快照（和SYSSTAT第一次同时）
collect_wait_event_snapshot1() {
    log INFO "采集等待事件数据（第1次快照）..."
    
    # 使用 | 分隔符拼接字段，便于解析
    local sql="select event||'|'||total_waits||'|'||time_waited_micro||'|'||wait_class as data from v\$system_event;"
    local snapshot=$(execute_sql "$sql")
    local snapshot_time=$(date '+%Y-%m-%d %H:%M:%S')
    if [ "$BIC_DEBUG" = "true" ]; then
        printf "=== wait_event snapshot1 @ %s ===\n%s\n" "$snapshot_time" "$snapshot" > "${TMP_DIR}/debug_wait_event_snapshot_1.txt"
    fi
    
    # 保存到全局变量（会在collect_wait_event_snapshot2中使用）
    WAITEVENT_SNAPSHOT1="${snapshot_time}${_DM_SNAP_RS}${snapshot}"
    
    log INFO "等待事件第1次快照采集完成"
}

# 采集等待事件第二次快照并计算增量（在SYSSTAT全部完成后）
collect_wait_event_snapshot2() {
    log INFO "采集等待事件数据（第2次快照）..."
    
    # 使用 | 分隔符拼接字段，便于解析
    local sql="select event||'|'||total_waits||'|'||time_waited_micro||'|'||wait_class as data from v\$system_event;"
    local snapshot=$(execute_sql "$sql")
    local snapshot_time=$(date '+%Y-%m-%d %H:%M:%S')
    if [ "$BIC_DEBUG" = "true" ]; then
        printf "=== wait_event snapshot2 @ %s ===\n%s\n" "$snapshot_time" "$snapshot" > "${TMP_DIR}/debug_wait_event_snapshot_2.txt"
    fi
    
    local prev_time="${WAITEVENT_SNAPSHOT1%%${_DM_SNAP_RS}*}"
    local prev_data="${WAITEVENT_SNAPSHOT1#*${_DM_SNAP_RS}}"
    local curr_time="$snapshot_time"
    local curr_data="$snapshot"
    
    # 计算时间间隔（秒）
    local start_ts=$(date -d "$prev_time" +%s 2>/dev/null)
    local end_ts=$(date -d "$curr_time" +%s 2>/dev/null)
    
    local interval=0
    if [ -n "$start_ts" ] && [ -n "$end_ts" ] && [ "$start_ts" -gt 0 ] && [ "$end_ts" -gt 0 ]; then
        interval=$((end_ts - start_ts))
    fi

    # 修正：按真实快照间隔计算；仅在明显异常时回退到期望值
    local expected_interval=$((DB_COLLECT_INTERVAL * 4))
    if [ "$expected_interval" -le 0 ]; then
        expected_interval=12
    fi
    if [ "$interval" -le 0 ] || [ "$interval" -gt 86400 ]; then
        log WARN "等待事件快照时间间隔异常(${interval}秒)，回退为期望值${expected_interval}秒"
        interval=$expected_interval
    fi
    
    log INFO "计算等待事件增量数据（时间间隔：${interval}秒）..."
    
    # 先处理数据，存储到数组
    declare -a result_lines
    local result_count=0
    
    declare -A prev_waits_map
    declare -A prev_time_map
    
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        [[ "$line" =~ ^[[:space:]]*DATA ]] && continue
        [[ "$line" =~ ^[[:space:]]*---+ ]] && continue
        [[ "$line" =~ rows[[:space:]]got ]] && continue
        [[ "$line" =~ used[[:space:]]time ]] && continue
        [[ "$line" =~ Execute[[:space:]]id ]] && continue
        [[ "$line" =~ ^[[:space:]]*行号[[:space:]] ]] && continue
        
        if [[ "$line" =~ \| ]]; then
            local payload="$line"
            if [[ "$payload" =~ ^[[:space:]]*[0-9]+[[:space:]]+(.+)$ ]]; then
                payload="${BASH_REMATCH[1]}"
            fi
            local event=$(echo "$payload" | cut -d'|' -f1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            local waits=$(echo "$payload" | cut -d'|' -f2 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            local time_micro=$(echo "$payload" | cut -d'|' -f3 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            local wait_class=$(echo "$payload" | cut -d'|' -f4 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            
            if [[ "$waits" =~ ^[0-9]+$ ]] && [[ "$time_micro" =~ ^[0-9]+$ ]] && [ -n "$event" ]; then
                prev_waits_map["$event"]=$waits
                prev_time_map["$event"]=$time_micro
            fi
        fi
    done <<< "$prev_data"
    
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        [[ "$line" =~ ^[[:space:]]*DATA ]] && continue
        [[ "$line" =~ ^[[:space:]]*---+ ]] && continue
        [[ "$line" =~ rows[[:space:]]got ]] && continue
        [[ "$line" =~ used[[:space:]]time ]] && continue
        [[ "$line" =~ Execute[[:space:]]id ]] && continue
        [[ "$line" =~ ^[[:space:]]*行号[[:space:]] ]] && continue
        
        if [[ "$line" =~ \| ]]; then
            local payload="$line"
            if [[ "$payload" =~ ^[[:space:]]*[0-9]+[[:space:]]+(.+)$ ]]; then
                payload="${BASH_REMATCH[1]}"
            fi
            local event=$(echo "$payload" | cut -d'|' -f1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            local curr_waits=$(echo "$payload" | cut -d'|' -f2 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            local curr_time_micro=$(echo "$payload" | cut -d'|' -f3 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            local wait_class=$(echo "$payload" | cut -d'|' -f4 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            
            if [[ "$curr_waits" =~ ^[0-9]+$ ]] && [[ "$curr_time_micro" =~ ^[0-9]+$ ]] && [ -n "$event" ]; then
                local prev_waits=0
                local prev_time_micro=0
                
                if [[ -n "${prev_waits_map[$event]+isset}" ]]; then
                    prev_waits="${prev_waits_map[$event]}"
                    prev_time_micro="${prev_time_map[$event]}"
                fi
                
                local delta_waits=$((curr_waits - prev_waits))
                local delta_time_micro=$((curr_time_micro - prev_time_micro))
                
                if [ $delta_waits -ge 0 ] && [ $delta_time_micro -ge 0 ]; then
                    local wait_time_ms=$(awk "BEGIN {printf \"%.2f\", $delta_time_micro / 1000.0}")
                    local wait_time_per_sec=$(awk "BEGIN {printf \"%.2f\", $wait_time_ms / $interval}")
                    local avg_wait_time="0.00"
                    if [ $delta_waits -gt 0 ]; then
                        avg_wait_time=$(awk "BEGIN {printf \"%.2f\", $wait_time_ms / $delta_waits}")
                    fi
                    
                    result_lines[$result_count]=$(printf "%-23s %-20s %-20s %-10s %-20s %-20s" \
                        "$event" "$delta_waits" "$wait_time_ms" "$wait_class" "$wait_time_per_sec" "$avg_wait_time")
                    result_count=$((result_count + 1))
                fi
            fi
        fi
    done <<< "$curr_data"
    
    
    # ✅ 输出到文件（只包含增量结果，不包含任何原始SQL输出）
    local output_file="$FRAG_DIR/waitevent.txt"
    {
        echo "=== Wait Event Delta (snapshot#1 -> snapshot#2) ==="
        echo ""
        echo "Time Range:"
        echo "  Start: $prev_time"
        echo "  End: $curr_time"
        echo "  Interval: ${interval}s"
        echo ""
        echo "Delta Result (total events: $result_count):"
        echo ""
        printf "%-23s %-20s %-20s %-10s %-20s %-20s\n" \
            "event" "waits" "wait_time_ms" "wait_class" "wait_time_per_sec" "avg_wait_time"
        echo "----------------------- -------------------- -------------------- ---------- -------------------- --------------------"
        
        # 输出所有结果
        for ((i=0; i<result_count; i++)); do
            echo "${result_lines[$i]}"
        done
        
        if [ $result_count -eq 0 ]; then
            echo "(no wait event data)"
        fi
        
        echo ""
    } > "$output_file"
    
    log INFO "Wait event collection completed: $output_file (total events: ${result_count})"
}

# 采集TIME MODEL第一次快照（和SYSSTAT第一次同时）
collect_time_model_snapshot1() {
    log INFO "采集TIME MODEL数据（第1次快照）..."
    
    local sql="SET PAGES 99
SELECT
    name,
    stat_val,
    classid,
    CASE classid
        WHEN 1  THEN '字典信息'
        WHEN 2  THEN 'SQL'
        WHEN 3  THEN '事务'
        WHEN 4  THEN '检查点'
        WHEN 5  THEN 'RLOG'
        WHEN 6  THEN 'UNDO'
        WHEN 7  THEN 'IO'
        WHEN 8  THEN 'B树'
        WHEN 9  THEN '网络'
        WHEN 10 THEN '文件'
        WHEN 11 THEN '内存'
        WHEN 12 THEN 'CPU'
        WHEN 13 THEN 'OS'
        WHEN 14 THEN '缓冲区'
        WHEN 15 THEN '限流控制'
        WHEN 16 THEN 'DMDPC'
        WHEN 20 THEN '其它'
    END AS class_name
FROM 
    v\$sysstat
WHERE 
    name LIKE '%(ms)'
ORDER BY 
    classid, name;"
    
    local snapshot=$(execute_sql "$sql")
    local snapshot_time=$(date '+%Y-%m-%d %H:%M:%S')
    if [ "$BIC_DEBUG" = "true" ]; then
        printf "=== time_model snapshot1 @ %s ===\n%s\n" "$snapshot_time" "$snapshot" > "${TMP_DIR}/debug_time_model_snapshot_1.txt"
    fi
    
    # 保存到全局变量（会在collect_time_model_snapshot2中使用）
    TIME_MODEL_SNAPSHOT1="${snapshot_time}${_DM_SNAP_RS}${snapshot}"
    
    log INFO "TIME MODEL第1次快照采集完成"
}

# 采集TIME MODEL第二次快照并计算增量（在SYSSTAT全部完成后）
collect_time_model_snapshot2() {
    log INFO "采集TIME MODEL数据（第2次快照）..."
    
    local sql="SET PAGES 99
SELECT
    name,
    stat_val,
    classid,
    CASE classid
        WHEN 1  THEN '字典信息'
        WHEN 2  THEN 'SQL'
        WHEN 3  THEN '事务'
        WHEN 4  THEN '检查点'
        WHEN 5  THEN 'RLOG'
        WHEN 6  THEN 'UNDO'
        WHEN 7  THEN 'IO'
        WHEN 8  THEN 'B树'
        WHEN 9  THEN '网络'
        WHEN 10 THEN '文件'
        WHEN 11 THEN '内存'
        WHEN 12 THEN 'CPU'
        WHEN 13 THEN 'OS'
        WHEN 14 THEN '缓冲区'
        WHEN 15 THEN '限流控制'
        WHEN 16 THEN 'DMDPC'
        WHEN 20 THEN '其它'
    END AS class_name
FROM 
    v\$sysstat
WHERE 
    name LIKE '%time(ms)%'
ORDER BY 
    classid, name;"
    
    local snapshot=$(execute_sql "$sql")
    local snapshot_time=$(date '+%Y-%m-%d %H:%M:%S')
    if [ "$BIC_DEBUG" = "true" ]; then
        printf "=== time_model snapshot2 @ %s ===\n%s\n" "$snapshot_time" "$snapshot" > "${TMP_DIR}/debug_time_model_snapshot_2.txt"
    fi
    
    local prev_time="${TIME_MODEL_SNAPSHOT1%%${_DM_SNAP_RS}*}"
    local prev_data="${TIME_MODEL_SNAPSHOT1#*${_DM_SNAP_RS}}"
    local curr_time="$snapshot_time"
    local curr_data="$snapshot"
    
    # 计算时间间隔（秒）
    local start_ts=$(date -d "$prev_time" +%s 2>/dev/null)
    local end_ts=$(date -d "$curr_time" +%s 2>/dev/null)
    
    local interval=0
    if [ -n "$start_ts" ] && [ -n "$end_ts" ] && [ "$start_ts" -gt 0 ] && [ "$end_ts" -gt 0 ]; then
        interval=$((end_ts - start_ts))
    fi

    # 修正：按真实快照间隔计算；仅在明显异常时回退到期望值
    local expected_interval=$((DB_COLLECT_INTERVAL * 4))
    if [ "$expected_interval" -le 0 ]; then
        expected_interval=12
    fi
    if [ "$interval" -le 0 ] || [ "$interval" -gt 86400 ]; then
        log WARN "TIME MODEL快照时间间隔异常(${interval}秒)，回退为期望值${expected_interval}秒"
        interval=$expected_interval
    fi
    
    log INFO "计算TIME MODEL增量数据（时间间隔：${interval}秒）..."
    
    # 解析第1次快照数据到关联数组
    declare -A prev_stat_val_map
    declare -A prev_classid_map
    declare -A prev_class_name_map
    
    while IFS= read -r line; do
        # 跳过空行、表头、分隔线、统计行
        [[ -z "$line" ]] && continue
        [[ "$line" =~ ^[[:space:]]*NAME ]] && continue
        [[ "$line" =~ ^[[:space:]]*---+ ]] && continue
        [[ "$line" =~ rows[[:space:]]got ]] && continue
        [[ "$line" =~ used[[:space:]]time ]] && continue
        [[ "$line" =~ Execute[[:space:]]id ]] && continue
        [[ "$line" =~ ^[[:space:]]*行号[[:space:]] ]] && continue
        
        local payload="$line"
        if [[ "$payload" =~ ^[[:space:]]*[0-9]+[[:space:]]+(.+)$ ]]; then
            payload="${BASH_REMATCH[1]}"
        fi
        
        # 匹配数据行（包含time(ms)）
        if [[ "$payload" =~ time\(ms\) ]]; then
            # 解析字段：name, stat_val, classid, class_name
            # 由于disql输出是列对齐的，使用awk按列位置解析
            # 假设格式：name(可能包含空格) stat_val classid class_name(可能包含空格)
            # 使用正则匹配：行首是name（到第一个数字前），然后是stat_val（数字），classid（数字），最后是class_name
            if [[ "$payload" =~ ^[[:space:]]*(.+)[[:space:]]+([0-9]+)[[:space:]]+([0-9]+)[[:space:]]+(.+)$ ]]; then
                local name="${BASH_REMATCH[1]}"
                local stat_val="${BASH_REMATCH[2]}"
                local classid="${BASH_REMATCH[3]}"
                local class_name="${BASH_REMATCH[4]}"
                
                # 去除首尾空格
                name=$(echo "$name" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                class_name=$(echo "$class_name" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                
                # 验证stat_val和classid是否为数字
                if [[ "$stat_val" =~ ^[0-9]+$ ]] && [[ "$classid" =~ ^[0-9]+$ ]] && [ -n "$name" ]; then
                    prev_stat_val_map["$name"]=$stat_val
                    prev_classid_map["$name"]=$classid
                    prev_class_name_map["$name"]=$class_name
                fi
            fi
        fi
    done <<< "$prev_data"
    
    # 解析第2次快照并计算增量
    declare -a result_lines
    local result_count=0
    
    while IFS= read -r line; do
        # 跳过空行、表头、分隔线、统计行
        [[ -z "$line" ]] && continue
        [[ "$line" =~ ^[[:space:]]*NAME ]] && continue
        [[ "$line" =~ ^[[:space:]]*---+ ]] && continue
        [[ "$line" =~ rows[[:space:]]got ]] && continue
        [[ "$line" =~ used[[:space:]]time ]] && continue
        [[ "$line" =~ Execute[[:space:]]id ]] && continue
        [[ "$line" =~ ^[[:space:]]*行号[[:space:]] ]] && continue
        
        local payload="$line"
        if [[ "$payload" =~ ^[[:space:]]*[0-9]+[[:space:]]+(.+)$ ]]; then
            payload="${BASH_REMATCH[1]}"
        fi
        
        # 匹配数据行（包含time(ms)）
        if [[ "$payload" =~ time\(ms\) ]]; then
            # 解析字段：name, stat_val, classid, class_name
            # 由于disql输出是列对齐的，使用正则表达式解析
            # 格式：name(可能包含空格) stat_val classid class_name(可能包含空格)
            if [[ "$payload" =~ ^[[:space:]]*(.+)[[:space:]]+([0-9]+)[[:space:]]+([0-9]+)[[:space:]]+(.+)$ ]]; then
                local name="${BASH_REMATCH[1]}"
                local curr_stat_val="${BASH_REMATCH[2]}"
                local classid="${BASH_REMATCH[3]}"
                local class_name="${BASH_REMATCH[4]}"
                
                # 去除首尾空格
                name=$(echo "$name" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                class_name=$(echo "$class_name" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                
                # 验证stat_val和classid是否为数字
                if [[ "$curr_stat_val" =~ ^[0-9]+$ ]] && [[ "$classid" =~ ^[0-9]+$ ]] && [ -n "$name" ]; then
                    # 获取第1次快照中的数据（如果不存在则为0）
                    local prev_stat_val=0
                    if [[ -n "${prev_stat_val_map[$name]+isset}" ]]; then
                        prev_stat_val="${prev_stat_val_map[$name]}"
                        # 如果classid或class_name不存在，使用当前快照的值
                        if [[ -z "${prev_classid_map[$name]+isset}" ]]; then
                            prev_classid_map["$name"]=$classid
                        fi
                        if [[ -z "${prev_class_name_map[$name]+isset}" ]]; then
                            prev_class_name_map["$name"]=$class_name
                        fi
                    else
                        # 第1次快照中未找到，使用当前快照的classid和class_name
                        prev_classid_map["$name"]=$classid
                        prev_class_name_map["$name"]=$class_name
                    fi
                    
                    # 计算差值
                    local delta=$((curr_stat_val - prev_stat_val))
                    
                    # 所有指标都输出（包括增量为0的）
                    if [ $delta -ge 0 ]; then
                        # 使用第1次快照的classid和class_name（如果存在），否则使用当前快照的值
                        local final_classid="${prev_classid_map[$name]:-$classid}"
                        local final_class_name="${prev_class_name_map[$name]:-$class_name}"
                        
                        # 格式化输出：name, classid, class_name, prev_stat_val, curr_stat_val, delta
                        result_lines[$result_count]=$(printf "%-50s %-10s %-20s %20s %20s %20s" \
                            "$name" "$final_classid" "$final_class_name" "$prev_stat_val" "$curr_stat_val" "$delta")
                        result_count=$((result_count + 1))
                    fi
                fi
            fi
        fi
    done <<< "$curr_data"
    
    # 输出到文件
    local output_file="$FRAG_DIR/time_model.txt"
    {
        echo "=== TIME MODEL Delta ==="
        echo ""
        echo "Time Range:"
        echo "  Start: $prev_time"
        echo "  End: $curr_time"
        echo "  Interval: ${interval}s"
        echo ""
        echo "Delta Result (total metrics: $result_count):"
        echo ""
        printf "%-50s %-10s %-20s %20s %20s %20s\n" \
            "name" "classid" "class_name" "prev_stat_val" "curr_stat_val" "delta"
        echo "-------------------------------------------------- ---------- -------------------- -------------------- -------------------- --------------------"
        
        # 输出所有结果
        for ((i=0; i<result_count; i++)); do
            echo "${result_lines[$i]}"
        done
        
        if [ $result_count -eq 0 ]; then
            echo "(no time(ms) metrics found)"
        fi
        
        echo ""
    } > "$output_file"
    
    log INFO "TIME MODEL collection completed: $output_file (total metrics: ${result_count})"
}

# 采集已执行未提交的SQL
collect_uncommitted_sql() {
    local output_file="$FRAG_DIR/uncommittd.txt"
    log INFO "采集已执行未提交的SQL..."
    
    local sql="SELECT t1.sql_text, t1.state, t1.trx_id 
FROM v\$sessions t1, v\$trx t2 
WHERE t1.trx_id = t2.id
  AND t1.state = 'IDLE'
  AND t2.status = 'ACTIVE'
  AND (t1.sql_text IS NULL OR UPPER(t1.sql_text) NOT LIKE '%DMHC_COLLECTOR%');"
    execute_sql_to_file "$sql" "$output_file"
    
    log INFO "未提交SQL采集完成: $output_file"
}

# 采集有事务未提交的表
collect_uncommitted_objects() {
    local output_file="$FRAG_DIR/uncommitted_obj.txt"
    log INFO "采集有事务未提交的表..."
    
    local sql="SELECT b.object_name, c.sess_id, a.* 
FROM v\$lock a, dba_objects b, v\$sessions c 
WHERE a.table_id = b.object_id AND ltype = 'OBJECT' AND a.trx_id = c.trx_id AND a.blocked <> 0;"
    execute_sql_to_file "$sql" "$output_file"
    if ! awk '
        BEGIN { found=0 }
        {
            gsub(/\r/, "", $0)
            if ($0 ~ /^[[:space:]]*$/) next
            if ($0 ~ /^[[:space:]]*OBJECT_NAME[[:space:]]/) next
            if ($0 ~ /^[[:space:]]*---+/) next
            if ($0 ~ /rows[[:space:]]got|rows[[:space:]]fetched|used[[:space:]]time|Execute[[:space:]]id|行号/) next
            found=1
        }
        END { exit(found ? 0 : 1) }
    ' "$output_file"; then
        echo "当前并未发现存在阻塞的未提交对象" > "$output_file"
    fi
    
    log INFO "未提交对象采集完成: $output_file"
}

# 采集死锁信息
collect_deadlock() {
    local output_file="$FRAG_DIR/deadlock.txt"
    log INFO "采集死锁信息..."
    
    local sql="select * from V\$DEADLOCK_HISTORY;"
    local result=$(execute_sql "$sql")
    
    # 检查是否有死锁
    if echo "$result" | grep -q "no rows selected\|0 rows fetched"; then
        echo "无死锁记录" > "$output_file"
    else
        # 有死锁，查询详细信息
        local sql_detail="WITH locks AS 
(SELECT o.name, l.*, s.sess_id, s.sql_text, s.clnt_ip, s.last_send_time 
FROM v\$lock l, sysobjects o, v\$sessions s 
WHERE l.table_id = o.id AND l.trx_id = s.trx_id), 
lock_tr AS 
(SELECT trx_id wt_trxid, tid blk_trxid FROM locks WHERE blocked = 1), 
res AS 
(SELECT SYSDATE stattime, t1.name, t1.sess_id wt_sessid, s.wt_trxid, t2.sess_id blk_sessid, s.blk_trxid, t2.clnt_ip, 
SF_GET_SESSION_SQL(t1.sess_id) fulsql, 
datediff(ss, t1.last_send_time, SYSDATE) ss, 
t1.sql_text wt_sql 
FROM lock_tr s, locks t1, locks t2 
WHERE t1.ltype = 'OBJECT' AND t1.table_id <> 0 
AND t2.ltype = 'OBJECT' AND t2.table_id <> 0 
AND s.wt_trxid = t1.trx_id AND s.blk_trxid = t2.trx_id) 
SELECT DISTINCT wt_sql, clnt_ip, ss FROM res;"
        local detail_result=$(execute_sql "$sql_detail")
        
        {
            echo "=== 死锁历史 ==="
            echo "$result"
            echo ""
            echo "=== 死锁详细信息 ==="
            echo "$detail_result"
        } > "$output_file"
    fi
    
    log INFO "死锁信息采集完成: $output_file"
}

# 采集阻塞信息
collect_blocked() {
    local output_file="$FRAG_DIR/blocked.txt"
    log INFO "采集阻塞信息..."
    
    local sql="WITH TRX_TAB AS 
(SELECT O1.NAME,L1.TRX_ID FROM V\$LOCK L1,SYSOBJECTS O1 
WHERE L1.TABLE_ID=O1.ID AND O1.ID<>0), 
TRX_SESS AS (
SELECT L.TRX_ID WT_TRXID, L.ROW_IDX BLK_TRXID,L.BLOCKED,
(SELECT NAME TABLE_NAME FROM TRX_TAB A WHERE A.TRX_ID=L.TRX_ID) WT_TABLE, 
S1.SESS_ID WT_SESS,S2.SESS_ID BLK_SESS, 
S1.USER_NAME WT_USER_NAME,S2.USER_NAME BLK_USER_NAME,
S1.SQL_TEXT,S1.CLNT_IP,DATEDIFF(SS, S1.LAST_SEND_TIME, SYSDATE) SS 
FROM V\$LOCK L,V\$SESSIONS S1,V\$SESSIONS S2 
WHERE L.TRX_ID=S1.TRX_ID AND L.ROW_IDX=S2.TRX_ID) 
SELECT SYSDATE STATTIME,* FROM TRX_SESS where BLOCKED=1;"
    execute_sql_to_file "$sql" "$output_file"
    
    log INFO "阻塞信息采集完成: $output_file"
}

# 采集内存相关信息（各子项为 disql 表格式文本，写入 vmem-*.txt）
collect_memory_info() {
    log INFO "采集内存信息..."
    
    # 16.1 字典缓存
    local sql_db_cache="select * from V\$DB_CACHE;"
    local db_cache=$(execute_sql "$sql_db_cache")
    echo "$db_cache" > "$FRAG_DIR/vmem-db_cache.txt"
    
    # 16.2 数据缓冲池
    local sql_buffer_pool="select * from V\$BUFFERPOOL;"
    local buffer_pool=$(execute_sql "$sql_buffer_pool")
    echo "$buffer_pool" > "$FRAG_DIR/vmem-buffer_pool.txt"
    
    # 16.4 内存池信息
    local sql_mem_pool="select name, is_shared, is_overflow, 
org_size/1024.0/1024.0, TOTAL_size/1024.0/1024.0, 
RESERVED_SIZE/1024.0/1024.0, DATA_SIZE/1024.0/1024.0, 
EXTEND_SIZE, TARGET_SIZE, N_EXTEND_NORMAL, N_EXTEND_EXCLUSIVE 
FROM V\$MEM_POOL order by TOTAL_size desc;"
    local mem_pool=$(execute_sql "$sql_mem_pool")
    echo "$mem_pool" > "$FRAG_DIR/vmem-mem_pool.txt"
    
    # 16.5 内存总量
    local sql_mem_usage="select 
(select sum(n_pages * page_size)/1024/1024 from v\$bufferpool)||'MB' as BUFFER_SIZE, 
(select sum(total_size)/1024/1024 from v\$mem_pool)||'MB' as mem_pool, 
(select sum(n_pages * page_size)/1024/1024 from v\$bufferpool)+
(select sum(total_size)/1024/1024 from v\$mem_pool)||'MB' as TOTAL_SIZE 
from dual;"
    local mem_usage=$(execute_sql "$sql_mem_usage")
    echo "$mem_usage" > "$FRAG_DIR/vmem-memusage.txt"
    
    # 16.8 内存增长过快分析
    local sql_buffer_stat="select name, n_pages, free, N_DISCARD64 from v\$bufferpool;"
    local buffer_stat=$(execute_sql "$sql_buffer_stat")
    echo "$buffer_stat" > "$FRAG_DIR/vmem-bufferpool_stat.txt"
    
    # 16.9 SQL语句与结果缓冲池
    local sql_cache="select PLN_CNT,RS_CNT,SQL_CNT,PKGINFO_CNT,LRU_SIZE,DISABLE_SIZE,DISCARD,DISCARD_mem,n_add_fail from v\$scp_cache;"
    local sql_cache_result=$(execute_sql "$sql_cache")
    echo "$sql_cache_result" > "$FRAG_DIR/vmem-sqlcache.txt"
    
    # 缓存的SQL和执行计划占用的总空间
    local sql_cache_size="SELECT SUM(ITEM_SIZE)/1024/1024 缓存池大小_M FROM V\$CACHEITEM;"
    local cache_size=$(execute_sql "$sql_cache_size")
    echo "$cache_size" > "$FRAG_DIR/vmem-sqlcache_size.txt"
    
    # 缓冲命中率
    local sql_hit_rate="select name as cache_name, sum(page_size)*sf_get_page_size as cache_size_GB, 
TO_CHAR(round(sum(rat_hit)/count(*)*100,2),'999.99') AS hit_ratio 
from v\$bufferpool group by name;"
    local hit_rate=$(execute_sql "$sql_hit_rate")
    echo "$hit_rate" > "$FRAG_DIR/vmem-bufferhit.txt"
    
    log INFO "内存信息采集完成"
}

# 采集会话信息
collect_session_info() {
    log INFO "Collecting session data..."

    local session_info_file="$FRAG_DIR/session_info.txt"
    local session_phy_read_file="$FRAG_DIR/session_phy_read.txt"
    local session_logic_file="$FRAG_DIR/session_logic.txt"
    local session_parse_file="$FRAG_DIR/session_parse.txt"

    local sql_session_info="SELECT STATE,CLNT_HOST,CLNT_TYPE,CURR_SCH,USER_NAME,COUNT(*) COUNTS
FROM V\$SESSIONS
GROUP BY STATE,CLNT_HOST,CLNT_TYPE,CURR_SCH,USER_NAME
ORDER BY STATE;"
    execute_sql_to_file "$sql_session_info" "$session_info_file"

    local sql_session_phy_read="SELECT
    s.STATE STAT,
    s.CLNT_HOST CLIENT_HOST,
    s.CLNT_TYPE,
    s.CURR_SCH,
    s.USER_NAME,
    stat.PHY_READ_CNT AS PHYSICAL_READS,
    stat.SEL_SQL_CNT AS SELECT_SQLS,
    stat.INS_SQL_CNT AS INSERT_SQLS,
    stat.DEL_SQL_CNT AS DELETE_SQLS,
    stat.UPD_SQL_CNT AS UPDATE_SQLS,
    stat.TAB_SCAN_CNT as TABLE_SCAN_COUNT,
    stat.IO_WAIT_TIME,
    stat.BTR_SPLIT_CNT as BTREE_SPLIET_COUNT,
    stat.DDL_SQL_CNT AS DDL_SQLS
FROM
    V\$SESSIONS s
INNER JOIN
    V\$SESSION_STAT stat ON s.SESS_ID = stat.SESSID
ORDER BY
    stat.PHY_READ_CNT DESC
FETCH FIRST 20 ROWS ONLY;"
    execute_sql_to_file "$sql_session_phy_read" "$session_phy_read_file"

    local sql_session_logic="SELECT
    s.STATE STAT,
    s.CLNT_HOST CLIENT_HOST,
    s.CLNT_TYPE,
    s.CURR_SCH,
    s.USER_NAME,
    stat.LOGIC_READ_CNT AS LOGICAL_READS,
    stat.SEL_SQL_CNT AS SELECT_SQLS,
    stat.INS_SQL_CNT AS INSERT_SQLS,
    stat.DEL_SQL_CNT AS DELETE_SQLS,
    stat.UPD_SQL_CNT AS UPDATE_SQLS,
    stat.OPTIMIZED_SORT_CNT,
    stat.ONE_WAY_SORT_CNT,
    stat.MULTI_WAY_SORT_CNT,
    stat.HASH_JOIN_CNT
FROM
    V\$SESSIONS s
INNER JOIN
    V\$SESSION_STAT stat ON s.SESS_ID = stat.SESSID
ORDER BY
    stat.LOGIC_READ_CNT DESC
FETCH FIRST 20 ROWS ONLY;"
    execute_sql_to_file "$sql_session_logic" "$session_logic_file"

    local sql_session_parse="SELECT
    s.STATE STAT,
    s.CLNT_HOST CLIENT_HOST,
    s.CLNT_TYPE,
    s.CURR_SCH,
    s.USER_NAME,
    stat.PARSE_CNT,
    stat.SEL_SQL_CNT AS SELECT_SQLS,
    stat.INS_SQL_CNT AS INSERT_SQLS,
    stat.DEL_SQL_CNT AS DELETE_SQLS,
    stat.UPD_SQL_CNT AS UPDATE_SQLS,
    stat.PARSE_TIME AS PARSE_TIME,
    stat.HARD_PARSE_CNT,
    stat.HARD_PARSE_TIME,
    stat.HASH_JOIN_CNT
FROM
    V\$SESSIONS s
INNER JOIN
    V\$SESSION_STAT stat ON s.SESS_ID = stat.SESSID
ORDER BY
    stat.PARSE_TIME DESC
FETCH FIRST 20 ROWS ONLY;"
    execute_sql_to_file "$sql_session_parse" "$session_parse_file"

    log INFO "Session data collection completed: $session_info_file, $session_phy_read_file, $session_logic_file, $session_parse_file"
}

# 采集备份空间信息
collect_backup_info() {
    local output_file="$FRAG_DIR/backup.txt"
    local jobs_output_file="$FRAG_DIR/backup_jobs.txt"
    log INFO "采集备份空间信息..."
    
    # 查找备份目录（grep 无匹配时退出 1，pipefail 下会中断采集）
    local sql_bak_path="Select para_value from v\$dm_ini where para_name='BAK_PATH';"
    local bak_path=""
    set +o pipefail
    bak_path=$(execute_sql "$sql_bak_path" | grep -v "^$" | tail -n 1 | awk '{print $1}')
    set -o pipefail
    
    {
        echo "=== 备份目录 ==="
        echo "$bak_path"
        echo ""
        
        # 如果是本地模式，执行du命令查看目录大小
        if [ "$LOCAL_MODE" = "true" ]; then
            echo "=== 备份目录大小 ==="
            if [ -d "$bak_path" ]; then
                du -sh "$bak_path" 2>/dev/null || echo "无法访问备份目录"
            else
                echo "备份目录不存在或无法访问"
            fi
        else
            # 远程模式通过SSH执行
            if [ -n "$bak_path" ]; then
                echo "=== 备份目录大小 ==="
                local du_result=$(execute_ssh "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "du -sh $bak_path 2>/dev/null || echo '无法访问备份目录'")
                echo "$du_result"
            fi
        fi
    } > "$output_file"

    local sql_backup_jobs="SELECT
    PATH AS BACKUP_PATH,
    START_TIME,
    END_TIME,
    CASE
        WHEN END_TIME IS NOT NULL THEN 'SUCCESS'
        ELSE 'FAILED OR RUNNING'
    END AS STATUS,
    TYPE,
    CASE TYPE
        WHEN 0 THEN '完全备份'
        WHEN 1 THEN '增量备份'
        WHEN 2 THEN 'B树备份'
        WHEN 3 THEN '归档备份'
        WHEN 4 THEN '累积增量备份'
        ELSE '未知类型(' || TYPE || ')'
    END AS TYPE_DESC,
    ERROR AS ERROR_MSG
FROM V\$BACKUP_HISTORY
WHERE START_TIME > SYSDATE -2
ORDER BY START_TIME DESC;"
    execute_sql_to_file "$sql_backup_jobs" "$jobs_output_file"
    if ! awk '
        BEGIN { found=0 }
        {
            gsub(/\r/, "", $0)
            if ($0 ~ /^[[:space:]]*$/) next
            if ($0 ~ /^[[:space:]]*BACKUP_PATH[[:space:]]/) next
            if ($0 ~ /^[[:space:]]*---+/) next
            if ($0 ~ /rows[[:space:]]got|rows[[:space:]]fetched|used[[:space:]]time|Execute[[:space:]]id|行号/) next
            found=1
        }
        END { exit(found ? 0 : 1) }
    ' "$jobs_output_file"; then
        echo "未发现最近2天里执行过备份操作，请关注备份任务是否正常启动" > "$jobs_output_file"
    fi
    
    log INFO "备份空间信息采集完成: $output_file, $jobs_output_file"
}

# 采集安全信息
collect_security_info() {
    log INFO "采集安全信息..."
    
    # 用户信息
    local sql_user="select * from DBA_USERS;"
    execute_sql_to_file "$sql_user" "$FRAG_DIR/secure-user.txt"
    
    # 密码策略
    local sql_pwd="select * from v\$dm_ini where para_name='PWD_POLICY';"
    execute_sql_to_file "$sql_pwd" "$FRAG_DIR/secure-pwd.txt"
    
    log INFO "安全信息采集完成"
}

# 排除非实例主库日志文件名（DMAP/备份/归档 等，大小写不敏感）
_dm_basename_is_aux_log() {
    case "$(echo "$1" | tr '[:lower:]' '[:upper:]')" in
        *DMAP*|*BAKRES*|*BAKRE*|*ARCH* ) return 0 ;;
        * ) return 1 ;;
    esac
}

# 单文件达梦行格式示例: 2026-04-25 08:34:00.808 [INFO] ... —— INFO 为常规消息，默认不大量采。
# 近 1 小时内：非 [INFO] 优先；全文块经去重（相同行保留时间上最后一条）后每文件最多 50 行。
# 无 gawk 时无法严格按时间窗，仅缩小 tail + 去重截断。
_dm_dmlog_level_policy_from_file() {
    local f="$1"
    local _ag _tmp _n
    [ -f "$f" ] || { echo "（本路径不可读）"; return 0; }
    _ag=$(date -d "1 hour ago" +%s 2>/dev/null || date -v-1H +%s 2>/dev/null || echo "")
    [ -n "$_ag" ] || _ag=$(($(date +%s) - 3600))
    _tmp="${TMP_DIR}/_dmlv_$$.out"
    if command -v gawk >/dev/null 2>&1; then
        gawk -v ag="$_ag" '
        function tparse(s,  a) {
            if (match(s, /^([0-9]{4})-([0-9]{2})-([0-9]{2})[ T]([0-9]{2}):([0-9]{2}):([0-9]{2})([.][0-9]+)?/, a))
                return mktime(a[1] " " a[2] " " a[3] " " a[4] " " a[5] " " a[6] " 0")
            return -1
        }
        BEGIN { IGNORECASE=1 }
        {
            t = tparse($0)
            if (t < 0) { if (cont) print; next }
            w = (t >= ag)
            info = ($0 ~ /\[INFO\]/)
            cont = 0
            if (w && !info) { print; cont = 1 }
        }' "$f" 2>/dev/null | head -n 20000 > "$_tmp" 2>/dev/null || : > "$_tmp"
    else
        : > "$_tmp"
    fi
    if [ ! -s "$_tmp" ] && ! command -v gawk >/dev/null 2>&1; then
        tail -n 8000 "$f" 2>/dev/null | grep -Eiv '\[INFO\]' 2>/dev/null > "$_tmp" || : > "$_tmp"
    fi
    _n=0
    [ -s "$_tmp" ] && _n=$(wc -l < "$_tmp" | tr -d ' ' | head -1)
    _n=${_n:-0}
    if [ "$_n" -gt 0 ] 2>/dev/null; then
        {
            cat "$_tmp" 2>/dev/null
            echo "---------- (本文件最后 10 行，作上下文) ----------"
            tail -n 10 "$f" 2>/dev/null || true
        } | _dm_log_dedupe_tail_max 50
    else
        if grep -qEi '\[INFO\]' "$f" 2>/dev/null; then
            tail -n 4000 "$f" 2>/dev/null | grep -Ei '\[INFO\]' 2>/dev/null | _dm_log_dedupe_tail_max 50
        else
            echo "（本文件近 1 小时无非 [INFO] 行，且无 [INFO]；取文件末若干行，去重后最多 50 行）"
            tail -n 2000 "$f" 2>/dev/null | _dm_log_dedupe_tail_max 50 || true
        fi
    fi
    rm -f "$_tmp" 2>/dev/null
    return 0
}

# 将实例/服务、DMAP、备份 三类达梦 $DM_HOME/log 文本采入三个文件（本机，放宽 dm_*_YYYYMM.log 等匹配）
_dm_write_dm_logs_three_files() {
    local dlog_dir="$1" d_icm="$2" d_ipm="${3:-}" d_iname="${4:-}"
    local inst_l f b ufound m
    {
        echo "==== 达梦实例/服务日志 (近1h；非 [INFO] 优先；去重后每文件≤50行) ====" 
        echo "目录: $dlog_dir  月: $d_icm ${d_ipm:+ 上月: $d_ipm }  VINSTANCE: ${d_iname:-<无>}"
        echo "匹配: dm_*_YYYYMM.log；全表 dm_*.log 补扫 _月.log；排除 DMAP/BAKRES/ARCH 等辅助名"
        if [ ! -d "$dlog_dir" ]; then
            echo "目录不存在: $dlog_dir"
        else
            inst_l="${TMP_DIR}/_dm_inst_$$.lst"
            : > "$inst_l"
            shopt -s nullglob
            for m in "$d_icm" $d_ipm; do
                [ -z "$m" ] && continue
                for f in "$dlog_dir"/dm_*_"$m".log; do
                    [ -f "$f" ] || continue
                    _dm_basename_is_aux_log "$(basename "$f")" && continue
                    echo "$f" >> "$inst_l"
                done
            done
            for f in "$dlog_dir"/dm_*.log; do
                [ -f "$f" ] || continue
                _dm_basename_is_aux_log "$(basename "$f")" && continue
                b=$(basename "$f")
                if [[ "$b" =~ _${d_icm}\.log$ ]] || { [ -n "$d_ipm" ] && [[ "$b" =~ _${d_ipm}\.log$ ]]; }; then
                    echo "$f" >> "$inst_l"
                fi
            done
            if [ -n "$d_iname" ] && [ -f "$dlog_dir/dm_${d_iname}_$d_icm.log" ]; then
                echo "$dlog_dir/dm_${d_iname}_$d_icm.log" >> "$inst_l"
            fi
            if [ -s "$inst_l" ]; then
                sort -u "$inst_l" | while IFS= read -r f; do
                    [ -f "$f" ] || continue
                    echo "---------- $f ----------"
                    _dm_dmlog_level_policy_from_file "$f" || true
                done
            else
                echo "未找到实例/服务主日志(尝试 ${dlog_dir}/dm_*_${d_icm}.log 等)。"
            fi
            rm -f "$inst_l"
        fi
    } > "$FRAG_DIR/logs-instance.txt"
    ufound=0
    {
        echo "==== DMAP 日志 ====" 
        if [ ! -d "$dlog_dir" ]; then
            echo "目录不存在: $dlog_dir"
        else
            shopt -s nullglob
            for f in "$dlog_dir"/dm_*.log; do
                [ -f "$f" ] || continue
                b=$(basename "$f" | tr '[:lower:]' '[:upper:]')
                [[ "$b" = *DMAP* ]] || continue
                { [[ "$b" = *"$d_icm"* ]] || { [ -n "$d_ipm" ] && [[ "$b" = *"$d_ipm"* ]]; }; } || continue
                ufound=1
                echo "---------- $f ----------"
                _dm_dmlog_level_policy_from_file "$f" || true
            done
            [ "$ufound" -eq 0 ] && echo "未匹配到 DMAP 月相关文件(需文件名含 DMAP 与当前/上一月分)。"
        fi
    } > "$FRAG_DIR/logs-dmap.txt"
    ufound=0
    {
        echo "==== 备份/归档(如 BAKRES) 日志 ====" 
        if [ ! -d "$dlog_dir" ]; then
            echo "目录不存在: $dlog_dir"
        else
            shopt -s nullglob
            for f in "$dlog_dir"/dm_*.log; do
                [ -f "$f" ] || continue
                b=$(basename "$f" | tr '[:lower:]' '[:upper:]')
                { [[ "$b" = *BAKRES* ]] || [[ "$b" = *BAKRE* ]]; } || continue
                { [[ "$b" = *"$d_icm"* ]] || { [ -n "$d_ipm" ] && [[ "$b" = *"$d_ipm"* ]]; }; } || continue
                ufound=1
                echo "---------- $f ----------"
                _dm_dmlog_level_policy_from_file "$f" || true
            done
            [ "$ufound" -eq 0 ] && echo "未匹配到 BAKRES/备份类月相关日志。"
        fi
    } > "$FRAG_DIR/logs-back.txt"
}

# 将 _dm_remote_log_script_heredoc 的 stdout 按 __DM_*__ 标记拆成三份
_dm_split_remote_log_markers() {
    local in="$1"
    local d="${FRAG_DIR:-.}"
    local _x p= line
    for _x in "logs-instance.txt" "logs-dmap.txt" "logs-back.txt"; do : > "$d/$_x" 2>/dev/null; done
    if [ -z "$in" ] || [ ! -f "$in" ]; then
        for _x in "logs-instance.txt" "logs-dmap.txt" "logs-back.txt"; do
            echo "（无远程日志输出）" > "$d/$_x" 2>/dev/null
        done
        return 1
    fi
    p=
    while IFS= read -r line; do
        case "$line" in
        __DM_INST_BEGIN__)  p=inst  ;;
        __DM_INST_END__)  p= ;;
        __DM_DMAP_BEGIN__)  p=dmap  ;;
        __DM_DMAP_END__)  p= ;;
        __DM_BAK_BEGIN__)  p=bak  ;;
        __DM_BAK_END__)  p= ;;
        __DM_*)  ;;
        *)
            if [ -n "$p" ]; then
                case "$p" in
                inst)  printf "%s\n" "$line" >> "$d/logs-instance.txt"  ;;
                dmap)  printf "%s\n" "$line" >> "$d/logs-dmap.txt"  ;;
                bak)  printf "%s\n" "$line" >> "$d/logs-back.txt"  ;;
                esac
            fi
        ;;
        esac
    done < "$in"
    return 0
}

# 与 _dm_dmlog_level_policy_from_file 等效，在远端输出三段，用标记分隔
_dm_remote_log_script_heredoc() {
    cat << 'DMSH'
#!/bin/bash
set +e
DLOG_DIR="${DLOG_DIR:?}"
D_ICM="${D_ICM:?}"
D_IPM="${D_IPM:-}"
D_INAME="${D_INAME:-}"
# 与采集端等效: 近 1 小时非 [INFO]；去重后每文件≤50 行
_dm_tail50_dedupe() {
  if command -v tac >/dev/null 2>&1; then
    tac | awk '!seen[$0]++' | tac | tail -n 50
  else
    tail -n 50
  fi
}
_dm_r_one() {
  local f=$1 _ag _f _n
  _f="/tmp/._dmo_$$.out"
  _ag=$(date -d "1 hour ago" +%s 2>/dev/null || date -v-1H +%s 2>/dev/null)
  [ -n "$_ag" ] || _ag=$(($(date +%s) - 3600))
  if command -v gawk >/dev/null 2>&1; then
    { gawk -v ag="$_ag" -f- "$f" 2>/dev/null <<'EAWK' || true
function tparse(s,  a) {
  if (match(s, /^([0-9]{4})-([0-9]{2})-([0-9]{2})[ T]([0-9]{2}):([0-9]{2}):([0-9]{2})([.][0-9]+)?/, a))
    return mktime(a[1] " " a[2] " " a[3] " " a[4] " " a[5] " " a[6] " 0")
  return -1
}
BEGIN { IGNORECASE=1 }
{ t = tparse($0)
  if (t < 0) { if (c) print; next }
  w = (t >= ag)
  isinfo = ($0 ~ /\[INFO\]/)
  c = 0
  if (w && !isinfo) { print; c = 1 }
}
EAWK
} | head -n 20000 | _dm_tail50_dedupe >"$_f" 2>/dev/null
  else
    : >"$_f"
  fi
  if [ ! -s "$_f" ] && ! command -v gawk >/dev/null 2>&1; then
    tail -n 8000 "$f" 2>/dev/null | grep -Eiv '\[INFO\]' 2>/dev/null | _dm_tail50_dedupe >"$_f" || : >"$_f"
  fi
  _n=0; [ -s "$_f" ] && _n=$(wc -l <"$_f" | tr -d " ")
  if [ "${_n:-0}" -gt 0 ] 2>/dev/null; then
    { cat "$_f" 2>/dev/null; echo "---------- (本文件最后 10 行) ----------"; tail -n 10 "$f" 2>/dev/null; } | _dm_tail50_dedupe
  else
    if grep -qEi '\[INFO\]' "$f" 2>/dev/null; then
      tail -n 4000 "$f" 2>/dev/null | grep -Ei '\[INFO\]' 2>/dev/null | _dm_tail50_dedupe
    else
      echo "（无非 [INFO]；取末段去重后最多 50 行）"
      tail -n 2000 "$f" 2>/dev/null | _dm_tail50_dedupe || true
    fi
  fi
  rm -f "$_f" 2>/dev/null
}
DLOG_PAT() {
  local m="$1"
  [ -d "$DLOG_DIR" ] || { echo "LOG目录不存在: $DLOG_DIR"; return; }
  shopt -s nullglob 2>/dev/null
  inst_cand=()
  for mm in $m $D_IPM; do
    [ -n "$mm" ] || continue
    for f in "$DLOG_DIR"/dm_*_"$mm".log; do
      [ -f "$f" ] && inst_cand+=("$f")
    done
  done
  if [ ${#inst_cand[@]} -eq 0 ]; then
    for f in "$DLOG_DIR"/dm_*.log; do
      [ -f "$f" ] || continue
      b=$(basename "$f")
      [[ "$b" =~ DMAP|dmap|BakRes|BAKRES|Bak|ARCH|arch ]] && continue
      [[ "$b" =~ _${m}\.log$ ]] && inst_cand+=("$f")
      [ -n "$D_IPM" ] && [[ "$b" =~ _${D_IPM}\.log$ ]] && inst_cand+=("$f")
    done
  fi
  if [ -n "$D_INAME" ] && [ -f "$DLOG_DIR/dm_${D_INAME}_${m}.log" ]; then
    inst_cand+=("$DLOG_DIR/dm_${D_INAME}_${m}.log")
  fi
  printf '%s\n' "${inst_cand[@]}" 2>/dev/null | sort -u | while IFS= read -r f; do
    [ -f "$f" ] || continue
    echo "---------- 文件: $f ----------"
    _dm_r_one "$f"
  done
  [ ${#inst_cand[@]} -eq 0 ] && echo "未找到实例类 dm_*_YYYYMM.log(月份=$m)于 $DLOG_DIR"
}
echo "__DM_INST_BEGIN__"
DLOG_PAT "$D_ICM" 
echo "__DM_INST_END__"
echo "__DM_DMAP_BEGIN__"
dmapf=0
for f in "$DLOG_DIR"/dm_[Dd]map*"$D_ICM"*.log "$DLOG_DIR"/dm_[Dd]map*.log; do
  [ -f "$f" ] || continue
  b=$(basename "$f" | tr '[:lower:]' '[:upper:]')
  [[ "$b" =~ DMAP ]] || continue
  [[ "$b" =~ $D_ICM ]] || { [ -n "$D_IPM" ] && [[ "$b" =~ $D_IPM ]]; } || continue
  dmapf=1
  echo "---------- DMAP: $f ----------"
  _dm_r_one "$f"
done
[ "$dmapf" -eq 0 ] && echo "未找到 DMAP 月日志于 $DLOG_DIR"
echo "__DM_DMAP_END__"
echo "__DM_BAK_BEGIN__"
bakf=0
for f in "$DLOG_DIR"/dm_BAKRES*"$D_ICM"*.log "$DLOG_DIR"/dm_*bak*"$D_ICM"*.log; do
  [ -f "$f" ] || continue
  b=$(basename "$f" | tr '[:lower:]' '[:upper:]')
  { [[ "$b" =~ BAKRES ]] || [[ "$b" =~ BAKRE ]]; } || continue
  bakf=1
  echo "---------- BAK/归档: $f ----------"
  _dm_r_one "$f"
done
[ "$bakf" -eq 0 ] && for f in "$DLOG_DIR"/dm_*.log; do
  [ -f "$f" ] || continue
  b=$(basename "$f" | tr '[:lower:]' '[:upper:]')
  [[ "$b" =~ BAKRES ]] && [[ "$b" =~ $D_ICM ]] && { bakf=1; echo "---------- BAK/归档: $f ----------"; _dm_r_one "$f"; }
done
[ "$bakf" -eq 0 ] && echo "未找到 BAKRES 月日志于 $DLOG_DIR"
echo "__DM_BAK_END__"
DMSH
}

# 采集数据库日志（$DM_HOME/log，宽匹配 dm_DMSERVER_202604.log 等）
collect_db_logs() {
    log INFO "采集达梦数据库日志(目录: \$DM_HOME/log，放寬檔名匹配)..."
    local sql_instance="SELECT INSTANCE_NAME FROM V\$INSTANCE;"
    local inst_name=""
    # 关闭 pipefail：SQL 输出经 grep 过滤后可能「无行」，grep 退出 1 会导致 set -e 下整段采集被中断、终包永不生成
    set +o pipefail
    inst_name=$(execute_sql "$sql_instance" 2>/dev/null | grep -v "^$" | grep -v "INSTANCE_NAME" | grep -v "^-" | head -n 1 | awk '{print $1}')
    set -o pipefail
    if [ -n "$inst_name" ]; then
        INSTANCE_NAME="$inst_name"
    fi
    if [ -z "$inst_name" ]; then
        log WARNING "未从 V\$INSTANCE 取到实例名; 将仅用日志文件名模式匹配(如 dm_*_YYYYMM.log)。"
    else
        log INFO "V\$INSTANCE 名称(参考): $inst_name"
    fi
    local current_month
    current_month=$(date +%Y%m)
    local prev_month=""
    prev_month=$(date -d "1 month ago" +%Y%m 2>/dev/null || date -v-1m +%Y%m 2>/dev/null || echo "")

    local dm_home_path=""
    if [ -n "$DM_HOME" ]; then
        dm_home_path="$DM_HOME"
    else
        local disql_path
        disql_path=$(command -v disql 2>/dev/null || true)
        if [ -n "$disql_path" ]; then
            dm_home_path=$(dirname "$(dirname "$disql_path")")
        fi
    fi
    if [ -z "$dm_home_path" ]; then
        {
            echo "（无法确定 DM_HOME，未采集 $DM_HOME/log 下文件；请设环境变量 DM_HOME 或把 disql 加入 PATH。）" > "$FRAG_DIR/logs-instance.txt"
            echo "同上" > "$FRAG_DIR/logs-dmap.txt"
            echo "同上" > "$FRAG_DIR/logs-back.txt"
        } 2>/dev/null
        log WARNING "无法确定 DM_HOME，已写入占位"
        return
    fi
    local log_dir="${dm_home_path}/log"
    log INFO "达梦 log 目录(路径): $log_dir"

    if [ "$LOCAL_MODE" = "true" ]; then
        _dm_write_dm_logs_three_files "$log_dir" "$current_month" "$prev_month" "${inst_name:-}"
        return
    fi
    if [ -z "$OS_HOST" ] || [ -z "$OS_PORT" ] || { [ -z "$OS_SSH_KEY_PATH" ] && [ -z "$OS_PASSWORD" ]; }; then
        echo "（远程采集需配置 OS/SSH 以读数据库主机上的 $log_dir）" | tee "$FRAG_DIR/logs-instance.txt" "$FRAG_DIR/logs-dmap.txt" "$FRAG_DIR/logs-back.txt" 2>/dev/null
        log WARNING "远程未配置有效 SSH/主机，达梦 log 需在本机有权限路径或对 OS_HOST 用 -f/凭证"
        return
    fi
    _dm_remote_log_script_heredoc > "${TMP_DIR}/dm_log_remote.sh"
    {
        echo "export DLOG_DIR=$(printf %q "$log_dir")"
        echo "export D_ICM=$(printf %q "$current_month")"
        echo "export D_IPM=$(printf %q "$prev_month")"
        echo "export D_INAME=$(printf %q "${inst_name:-}")"
        cat "${TMP_DIR}/dm_log_remote.sh"
    } > "${TMP_DIR}/_dm_remote_combined.sh"
    log INFO "正在通过 SSH 拉取远端达梦 log（若长时间无下一条日志，请检查网络/主机/ConnectTimeout=10）..."
    if [ -n "$OS_SSH_KEY_PATH" ] && [ -f "$OS_SSH_KEY_PATH" ]; then
        ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 -i "$OS_SSH_KEY_PATH" -p "$OS_PORT" \
            "${OS_USERNAME}@${OS_HOST}" "bash -s" < "${TMP_DIR}/_dm_remote_combined.sh" > "${TMP_DIR}/_dm_log_remote.out" 2>&1 || {
            log ERROR "SSH 执行远端日志采集失败(退出码 $?): ${OS_USERNAME}@${OS_HOST}:$OS_PORT"
            return 0
        }
    else
        sshpass -p "$OS_PASSWORD" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 -p "$OS_PORT" \
            "${OS_USERNAME}@${OS_HOST}" "bash -s" < "${TMP_DIR}/_dm_remote_combined.sh" > "${TMP_DIR}/_dm_log_remote.out" 2>&1 || {
            log ERROR "SSH/sshpass 执行远端日志采集失败(退出码 $?): ${OS_USERNAME}@${OS_HOST}:$OS_PORT"
            return 0
        }
    fi
    _dm_split_remote_log_markers "${TMP_DIR}/_dm_log_remote.out" || true
    log INFO "达梦日志远程采集结束，已拆分写入 FRAG_DIR（实例/DMAP/备份）"
}

# ==================== 操作系统采集函数（完全复制自Oracle工具）====================

# 采集CPU信息
collect_cpu_info() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集CPU信息..."
    
    # 执行命令的函数（本地或远程）
    local exec_cmd
    if [ "$LOCAL_MODE" = "true" ]; then
        exec_cmd="execute_local"
    else
        exec_cmd="execute_ssh"
    fi
    
    # 使用 sar 获取 CPU 使用率（避免依赖固定文案如 Average/平均时间）
    local cmd_cpu="sar -u 1 3 2>/dev/null | awk 'NF>=8{last=\$0} END{if(last!=\"\"){n=split(last,a,/ +/); if(n>0) printf \"%.2f\\n\", 100-a[n]}}'"
    local cpu_result
    if [ "$LOCAL_MODE" = "true" ]; then
        cpu_result=$(execute_local "$cmd_cpu" || true)
    else
        cpu_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_cpu" || true)
    fi
    
    if [ -n "$cpu_result" ]; then
        local cleaned_cpu_usage=$(echo "$cpu_result" | grep -oE '[0-9]+\.?[0-9]*' | head -1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        local cpu_usage=0
        if [[ "$cleaned_cpu_usage" =~ ^[0-9]+\.?[0-9]*$ ]]; then
            cpu_usage="$cleaned_cpu_usage"
            MAX_CPU_USAGE_PCT="$(_update_peak_pct "$cpu_usage" "$MAX_CPU_USAGE_PCT")"
        else
            log WARNING "无法解析CPU使用率，使用默认值0"
        fi
        
        # 获取CPU详细信息
        local cmd_cpu_detail="sar -u 1 3 2>/dev/null | awk 'NF>=8{last=\$0} END{if(last!=\"\"){n=split(last,a,/ +/); if(n>=8) print a[3],a[4],a[5],a[6],a[8]}}'"
        local cpu_detail
        if [ "$LOCAL_MODE" = "true" ]; then
            cpu_detail=$(execute_local "$cmd_cpu_detail" || true)
        else
            cpu_detail=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_cpu_detail" || true)
        fi
        
        {
            echo "CPU使用率(%): $cpu_usage"
            if [ -n "$cpu_detail" ]; then
                local cpu_user=$(echo "$cpu_detail" | awk '{print $1}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                local cpu_system=$(echo "$cpu_detail" | awk '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                local cpu_idle=$(echo "$cpu_detail" | awk '{print $3}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                local cpu_iowait=$(echo "$cpu_detail" | awk '{print $4}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                if [[ "$cpu_user" =~ ^[0-9]+\.?[0-9]*$ ]]; then
                    echo "user_time: $cpu_user"
                fi
                if [[ "$cpu_system" =~ ^[0-9]+\.?[0-9]*$ ]]; then
                    echo "system_time: $cpu_system"
                fi
                if [[ "$cpu_idle" =~ ^[0-9]+\.?[0-9]*$ ]]; then
                    echo "idle_time: $cpu_idle"
                fi
                if [[ "$cpu_iowait" =~ ^[0-9]+\.?[0-9]*$ ]]; then
                    echo "wait_time(iowait): $cpu_iowait"
                fi
            fi
        } > "${TMP_DIR}/cpu_info.txt"
        log INFO "CPU使用率: $cpu_usage%"
    else
        echo "CPU使用率(%): 无法采集（sar 不可用或无输出）" > "${TMP_DIR}/cpu_info.txt"
        log WARNING "CPU信息采集为空，已写占位内容"
    fi
}

# 采集内存信息
collect_memory_info_os() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集操作系统内存信息..."
    
    local cmd_mem="free -m"
    local mem_result
    if [ "$LOCAL_MODE" = "true" ]; then
        mem_result=$(execute_local "$cmd_mem" || true)
    else
        mem_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_mem" || true)
    fi
    
    if [ -n "$mem_result" ]; then
        local mem_total=$(echo "$mem_result" | awk '/^Mem:/{print $2; exit}')
        local mem_used=$(echo "$mem_result" | awk '/^Mem:/{print $3; exit}')
        local mem_available=$(echo "$mem_result" | awk '/^Mem:/{print $7; exit}')
        
        if [ -n "$mem_total" ] && [ -n "$mem_available" ]; then
            local mem_usage=$(awk "BEGIN {printf \"%.2f\", ($mem_total - $mem_available) / $mem_total * 100}")
            MAX_MEM_USAGE_PCT="$(_update_peak_pct "$mem_usage" "$MAX_MEM_USAGE_PCT")"
            echo "内存使用率(%): $mem_usage" > "${TMP_DIR}/mem_info.txt"
            log INFO "内存使用率: $mem_usage%"
        fi
    else
        echo "内存使用率(%): 无法采集（free 无输出）" > "${TMP_DIR}/mem_info.txt"
        log WARNING "内存信息采集为空，已写占位内容"
    fi
}

# 采集运行队列和阻塞队列信息
collect_runqueue_info() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集运行队列和阻塞队列信息..."
    
    # 采集5次取最后一次，避免第一次数据不准（系统启动以来的平均值）
    local cmd_runqueue="vmstat 1 5 | tail -1 | awk '{print \$1, \$2}'"
    local runqueue_result
    if [ "$LOCAL_MODE" = "true" ]; then
        runqueue_result=$(execute_local "$cmd_runqueue")
    else
        runqueue_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_runqueue")
    fi
    
    if [ -n "$runqueue_result" ]; then
        local runqueue_usage=$(echo "$runqueue_result" | awk '{print $1}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        local blocked_queue_usage=$(echo "$runqueue_result" | awk '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        
        if [[ "$runqueue_usage" =~ ^[0-9]+$ ]] && [[ "$blocked_queue_usage" =~ ^[0-9]+$ ]]; then
            {
                echo "running_process: $runqueue_usage"
                echo "blocked_process: $blocked_queue_usage"
            } > "${TMP_DIR}/runqueue_info.txt"
            log INFO "运行队列: $runqueue_usage, 阻塞队列: $blocked_queue_usage"
        fi
    fi
}

# 采集Swap信息
collect_swap_info() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集Swap信息..."
    
    local cmd_swap="free -m | grep Swap"
    local swap_result
    if [ "$LOCAL_MODE" = "true" ]; then
        swap_result=$(execute_local "$cmd_swap")
    else
        swap_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_swap")
    fi
    
    if [ -n "$swap_result" ]; then
        local swap_total=$(echo "$swap_result" | awk '{print $2}')
        local swap_used=$(echo "$swap_result" | awk '{print $3}')
        
        if [ -n "$swap_total" ] && [ "$swap_total" -gt 0 ]; then
            local swap_usage=$(awk "BEGIN {printf \"%.2f\", $swap_used / $swap_total * 100}")
            echo "Swap使用率(%): $swap_usage" > "${TMP_DIR}/swap_info.txt"
            log INFO "Swap使用率: $swap_usage%"
        fi
    fi
}

# 采集IO统计信息
collect_io_stats() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集IO统计信息..."
    
    # 采集5次取平均值，避免第一次数据不准（系统启动以来的平均值）
    local cmd_iostat="iostat -x 1 5 2>/dev/null | grep -A 100 'Device' | tail -n +2"
    local iostat_result
    if [ "$LOCAL_MODE" = "true" ]; then
        iostat_result=$(execute_local "$cmd_iostat")
    else
        iostat_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_iostat")
    fi
    
    if [ -n "$iostat_result" ]; then
        local total_iops=0
        local total_iokbps=0
        local count=0
        
        while IFS= read -r line; do
            if [ -n "$line" ] && ! echo "$line" | grep -qE '^(Device|avg-cpu)'; then
                local r_iops=$(echo "$line" | awk '{print $4}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                local w_iops=$(echo "$line" | awk '{print $5}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                local r_kbps=$(echo "$line" | awk '{print $6}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                local w_kbps=$(echo "$line" | awk '{print $7}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                
                if [[ "$r_iops" =~ ^[0-9]+\.?[0-9]*$ ]] && [[ "$w_iops" =~ ^[0-9]+\.?[0-9]*$ ]] && \
                   [[ "$r_kbps" =~ ^[0-9]+\.?[0-9]*$ ]] && [[ "$w_kbps" =~ ^[0-9]+\.?[0-9]*$ ]]; then
                    total_iops=$(awk -v total="$total_iops" -v r="$r_iops" -v w="$w_iops" 'BEGIN {print total + r + w}')
                    total_iokbps=$(awk -v total="$total_iokbps" -v r="$r_kbps" -v w="$w_kbps" 'BEGIN {print total + r + w}')
                    count=$((count + 1))
                fi
            fi
        done <<< "$iostat_result"
        
        if [ "$count" -gt 0 ]; then
            local avg_iops=$(awk -v total="$total_iops" -v cnt="$count" 'BEGIN {printf "%.2f", total / cnt}')
            local avg_iokbps=$(awk -v total="$total_iokbps" -v cnt="$count" 'BEGIN {printf "%.2f", total / cnt}')
            {
                echo "IOPS(平均): $avg_iops"
                echo "IOKBPS(平均): $avg_iokbps"
            } > "${TMP_DIR}/io_stats.txt"
            log INFO "平均IOPS: $avg_iops, 平均IOKBPS: $avg_iokbps"
        fi
    fi
}

# 采集IO响应时间（await）
collect_io_await() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集IO响应时间（await）..."
    
    # 采集5次取平均值，避免第一次数据不准（系统启动以来的平均值）
    local cmd_io_await="iostat -x 1 5 2>/dev/null | grep -A 100 'Device' | tail -n +2 | awk '{sum_await+=\$10; count++} END {if(count>0) print sum_await/count; else print 0}'"
    local io_await_result
    if [ "$LOCAL_MODE" = "true" ]; then
        io_await_result=$(execute_local "$cmd_io_await")
    else
        io_await_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_io_await")
    fi
    
    if [ -n "$io_await_result" ]; then
        local cleaned_io_await=$(echo "$io_await_result" | grep -oE '[0-9]+\.?[0-9]*' | head -1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        local io_await_val=0
        
        if [[ "$cleaned_io_await" =~ ^[0-9]+\.?[0-9]*$ ]]; then
            io_await_val=$(awk "BEGIN {printf \"%.2f\", $cleaned_io_await}")
        fi
        echo "IO_Latency(ms): $io_await_val" > "${TMP_DIR}/io_await_info.txt"
        log INFO "平均IO响应时间: ${io_await_val}ms"
    fi
}

# 采集 iostat 明细（原始输出）
collect_os_iostat() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6

    log INFO "采集iostat明细..."

    local cmd_iostat_raw="iostat -x 1 5 2>/dev/null"
    local iostat_raw_result
    if [ "$LOCAL_MODE" = "true" ]; then
        iostat_raw_result=$(execute_local "$cmd_iostat_raw" || true)
    else
        iostat_raw_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_iostat_raw" || true)
    fi

    if [ -n "$iostat_raw_result" ]; then
        echo "$iostat_raw_result" > "${TMP_DIR}/os_iostat.txt"
        log INFO "iostat明细采集完成"
    else
        echo "无法采集iostat明细（可能未安装sysstat）" > "${TMP_DIR}/os_iostat.txt"
        log WARNING "iostat明细采集失败"
    fi
}

# 采集 vmstat 明细（vmstat 1 6）；剔除首条数值行（自启动以来累计均值，易误导区间分析）
collect_os_vmstat() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6

    log INFO "采集 vmstat 明细（vmstat 1 6，已去除首条自启动均值采样行）..."

    # 首条以数字开头的数据行为「自启动以来」均值；保留表头与其余区间采样行
    local cmd_vmstat='vmstat 1 6 2>/dev/null | awk '\''/^[[:space:]]*[0-9]/{d++; if(d>1)print; next}1'\'''
    local vmstat_raw_result
    if [ "$LOCAL_MODE" = "true" ]; then
        vmstat_raw_result=$(execute_local "$cmd_vmstat" || true)
    else
        vmstat_raw_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_vmstat" || true)
    fi

    if [ -n "$vmstat_raw_result" ]; then
        echo "$vmstat_raw_result" > "${TMP_DIR}/os_vmstat.txt"
        log INFO "vmstat 明细采集完成"
    else
        echo "无法采集 vmstat 明细（可能未安装 procps/util-linux 或无权限）" > "${TMP_DIR}/os_vmstat.txt"
        log WARNING "vmstat 明细采集失败"
    fi
}

# 采集磁盘使用信息
collect_disk_usage() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集磁盘使用信息..."
    
    local cmd_df="df -h"
    local df_result
    if [ "$LOCAL_MODE" = "true" ]; then
        df_result=$(execute_local "$cmd_df")
    else
        df_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_df")
    fi
    
    if [ -n "$df_result" ]; then
        echo "$df_result" > "${TMP_DIR}/disk_usage.txt"
        log INFO "磁盘使用信息采集完成"
    fi
}

# 采集进程状态统计（进程和线程）
collect_process_stats() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集进程状态统计..."
    
    # 采集进程状态和线程状态的命令
    local cmd_process_stats='
echo "=== 进程状态统计（Process State Statistics）==="
echo ""
echo "进程状态分布："
ps -eo stat 2>/dev/null | tail -n +2 | sort | uniq -c | sort -rn || echo "无法采集进程状态"
echo ""
echo "=== 线程状态统计（Thread State Statistics）==="
echo ""
echo "线程状态分布："
ps -eLo stat 2>/dev/null | tail -n +2 | sort | uniq -c | sort -rn || echo "无法采集线程状态"
echo ""
echo "总进程数："
ps -eo pid 2>/dev/null | tail -n +2 | wc -l || echo "0"
echo "总线程数："
ps -eLo lwp 2>/dev/null | tail -n +2 | wc -l || echo "0"
'
    
    local stats_result
    if [ "$LOCAL_MODE" = "true" ]; then
        stats_result=$(execute_local "$cmd_process_stats" || true)
    else
        stats_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_process_stats" || true)
    fi
    
    if [ -n "$stats_result" ]; then
        echo "$stats_result" > "${TMP_DIR}/process_stats.txt"
        log INFO "进程状态统计采集完成"
    else
        echo "无法采集进程状态统计" > "${TMP_DIR}/process_stats.txt"
        log WARNING "进程状态统计采集失败"
    fi
}

# 采集 CPU 使用率 TOP 10 进程（单次采集）
collect_top_cpu_processes() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6

    log INFO "采集 TOP 10 CPU 使用进程..."

    local cmd_top_cpu='ps -eo pid,user,comm,%cpu,%mem --sort=-%cpu 2>/dev/null | head -n 11'
    local top_cpu_result
    if [ "$LOCAL_MODE" = "true" ]; then
        top_cpu_result=$(execute_local "$cmd_top_cpu" || true)
    else
        top_cpu_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_top_cpu" || true)
    fi

    if [ -n "$top_cpu_result" ]; then
        {
            echo "TOP 10 CPU 使用进程（pid user comm %cpu %mem）"
            echo "$top_cpu_result"
        } > "${TMP_DIR}/top_cpu_processes.txt"
        log INFO "TOP 10 CPU 使用进程采集完成"
    else
        echo "无法采集 TOP 10 CPU 使用进程" > "${TMP_DIR}/top_cpu_processes.txt"
        log WARNING "TOP 10 CPU 使用进程采集失败"
    fi
}

# 采集内存使用率 TOP 10 进程（单次采集）
collect_top_mem_processes() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6

    log INFO "采集 TOP 10 内存使用进程..."

    local cmd_top_mem='ps -eo pid,user,comm,%cpu,%mem --sort=-%mem 2>/dev/null | head -n 11'
    local top_mem_result
    if [ "$LOCAL_MODE" = "true" ]; then
        top_mem_result=$(execute_local "$cmd_top_mem" || true)
    else
        top_mem_result=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_top_mem" || true)
    fi

    if [ -n "$top_mem_result" ]; then
        {
            echo "TOP 10 内存使用进程（pid user comm %cpu %mem）"
            echo "$top_mem_result"
        } > "${TMP_DIR}/top_mem_processes.txt"
        log INFO "TOP 10 内存使用进程采集完成"
    else
        echo "无法采集 TOP 10 内存使用进程" > "${TMP_DIR}/top_mem_processes.txt"
        log WARNING "TOP 10 内存使用进程采集失败"
    fi
}

# 基于 ifconfig -a 计数，计算网卡每秒错包/丢包速率（仅用于多次采集）
collect_net_errdrop_rate() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local interval_secs=$6

    log INFO "采集网卡错包/丢包速率（每秒）..."

    local cmd_ifcfg='
if ! command -v ifconfig >/dev/null 2>&1; then
    echo "IFCONFIG_NOT_FOUND"
    exit 0
fi
ifconfig -a 2>/dev/null | awk '"'"'
/^[^ \t]/ {
    iface=$1
    sub(":", "", iface)
}
/RX errors/ {
    rxe[iface]=$3
    rxd[iface]=$5
}
/TX errors/ {
    txe[iface]=$3
    txd[iface]=$5
}
END {
    for (i in rxe) {
        if (i == "lo") continue
        printf "%s %s %s %s %s\n", i, rxe[i]+0, rxd[i]+0, txe[i]+0, txd[i]+0
    }
}
'"'"'
'

    local net_raw
    if [ "$LOCAL_MODE" = "true" ]; then
        net_raw=$(execute_local "$cmd_ifcfg" || true)
    else
        net_raw=$(execute_ssh "$host" "$port" "$username" "$password" "$ssh_key_path" "$cmd_ifcfg" || true)
    fi

    if [ -z "$net_raw" ]; then
        echo "无法采集网卡统计信息" > "${TMP_DIR}/net_errdrop_rate.txt"
        return
    fi
    if [ "$net_raw" = "IFCONFIG_NOT_FOUND" ]; then
        echo "未安装 ifconfig 命令，无法采集网卡统计信息" > "${TMP_DIR}/net_errdrop_rate.txt"
        return
    fi

    local prev_file="${TMP_DIR}/net_errdrop_prev.txt"
    local out_file="${TMP_DIR}/net_errdrop_rate.txt"
    : > "$out_file"

    # 当前快照
    declare -A cur_rxe cur_rxd cur_txe cur_txd
    while IFS= read -r line; do
        [ -n "$line" ] || continue
        local iface rxe rxd txe txd
        iface=$(echo "$line" | awk '{print $1}')
        rxe=$(echo "$line" | awk '{print $2}')
        rxd=$(echo "$line" | awk '{print $3}')
        txe=$(echo "$line" | awk '{print $4}')
        txd=$(echo "$line" | awk '{print $5}')
        [ -n "$iface" ] || continue
        cur_rxe["$iface"]=${rxe:-0}
        cur_rxd["$iface"]=${rxd:-0}
        cur_txe["$iface"]=${txe:-0}
        cur_txd["$iface"]=${txd:-0}
    done <<< "$net_raw"

    if [ "${#cur_rxe[@]}" -eq 0 ]; then
        echo "未采集到网卡统计信息" > "$out_file"
        return
    fi

    echo "网卡错包/丢包速率(每秒):" > "$out_file"
    echo "iface rx_err/s rx_drop/s tx_err/s tx_drop/s total/s" >> "$out_file"

    # 读取上一快照并做差分
    declare -A pre_rxe pre_rxd pre_txe pre_txd
    local has_prev=0
    if [ -f "$prev_file" ] && [ -s "$prev_file" ]; then
        has_prev=1
        while IFS= read -r pline; do
            [ -n "$pline" ] || continue
            local piface prxe prxd ptxe ptxd
            piface=$(echo "$pline" | awk '{print $1}')
            prxe=$(echo "$pline" | awk '{print $2}')
            prxd=$(echo "$pline" | awk '{print $3}')
            ptxe=$(echo "$pline" | awk '{print $4}')
            ptxd=$(echo "$pline" | awk '{print $5}')
            [ -n "$piface" ] || continue
            pre_rxe["$piface"]=${prxe:-0}
            pre_rxd["$piface"]=${prxd:-0}
            pre_txe["$piface"]=${ptxe:-0}
            pre_txd["$piface"]=${ptxd:-0}
        done < "$prev_file"
    fi

    local iface
    for iface in "${!cur_rxe[@]}"; do
        local drxe drxd dtxe dtxd
        local rxeps rxdps txeps txdps totalps
        if [ "$has_prev" -eq 1 ]; then
            drxe=$(( ${cur_rxe[$iface]:-0} - ${pre_rxe[$iface]:-0} ))
            drxd=$(( ${cur_rxd[$iface]:-0} - ${pre_rxd[$iface]:-0} ))
            dtxe=$(( ${cur_txe[$iface]:-0} - ${pre_txe[$iface]:-0} ))
            dtxd=$(( ${cur_txd[$iface]:-0} - ${pre_txd[$iface]:-0} ))
            [ "$drxe" -lt 0 ] && drxe=0
            [ "$drxd" -lt 0 ] && drxd=0
            [ "$dtxe" -lt 0 ] && dtxe=0
            [ "$dtxd" -lt 0 ] && dtxd=0
            rxeps=$(awk -v v="$drxe" -v t="$interval_secs" 'BEGIN{ if(t<=0)t=1; printf "%.2f", v/t }')
            rxdps=$(awk -v v="$drxd" -v t="$interval_secs" 'BEGIN{ if(t<=0)t=1; printf "%.2f", v/t }')
            txeps=$(awk -v v="$dtxe" -v t="$interval_secs" 'BEGIN{ if(t<=0)t=1; printf "%.2f", v/t }')
            txdps=$(awk -v v="$dtxd" -v t="$interval_secs" 'BEGIN{ if(t<=0)t=1; printf "%.2f", v/t }')
            totalps=$(awk -v a="$rxeps" -v b="$rxdps" -v c="$txeps" -v d="$txdps" 'BEGIN{ printf "%.2f", a+b+c+d }')
        else
            rxeps="N/A"; rxdps="N/A"; txeps="N/A"; txdps="N/A"; totalps="N/A"
        fi
        printf "%s %s %s %s %s %s\n" "$iface" "$rxeps" "$rxdps" "$txeps" "$txdps" "$totalps" >> "$out_file"
    done

    # 保存当前快照供下一次差分
    : > "$prev_file"
    for iface in "${!cur_rxe[@]}"; do
        printf "%s %s %s %s %s\n" \
            "$iface" \
            "${cur_rxe[$iface]:-0}" \
            "${cur_rxd[$iface]:-0}" \
            "${cur_txe[$iface]:-0}" \
            "${cur_txd[$iface]:-0}" >> "$prev_file"
    done
}


# 采集操作系统参数（内核参数）
collect_os_parameters() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集操作系统内核参数..."
    
    # 采集常用的内核参数：写入临时脚本后执行，避免多行字符串/括号配对问题
    { printf '%s\n' \
      '#!/bin/bash' \
      'set +e' \
      'echo "=== 操作系统内核参数 ==="' \
      'echo ""' \
      'echo "--- 内存管理参数 ---"' \
      'echo -n "vm.swappiness = "' \
      'sysctl -n vm.swappiness 2>/dev/null || cat /proc/sys/vm/swappiness 2>/dev/null || echo "N/A"' \
      'echo -n "vm.max_map_count = "' \
      'sysctl -n vm.max_map_count 2>/dev/null || cat /proc/sys/vm/max_map_count 2>/dev/null || echo "N/A"' \
      'echo -n "vm.min_free_kbytes = "' \
      'sysctl -n vm.min_free_kbytes 2>/dev/null || cat /proc/sys/vm/min_free_kbytes 2>/dev/null || echo "N/A"' \
      'echo -n "vm.dirty_ratio = "' \
      'sysctl -n vm.dirty_ratio 2>/dev/null || cat /proc/sys/vm/dirty_ratio 2>/dev/null || echo "N/A"' \
      'echo -n "vm.dirty_background_ratio = "' \
      'sysctl -n vm.dirty_background_ratio 2>/dev/null || cat /proc/sys/vm/dirty_background_ratio 2>/dev/null || echo "N/A"' \
      'echo -n "vm.dirty_expire_centisecs = "' \
      'sysctl -n vm.dirty_expire_centisecs 2>/dev/null || cat /proc/sys/vm/dirty_expire_centisecs 2>/dev/null || echo "N/A"' \
      'echo -n "vm.dirty_writeback_centisecs = "' \
      'sysctl -n vm.dirty_writeback_centisecs 2>/dev/null || cat /proc/sys/vm/dirty_writeback_centisecs 2>/dev/null || echo "N/A"' \
      'echo -n "vm.dirty_bytes = "' \
      'sysctl -n vm.dirty_bytes 2>/dev/null || cat /proc/sys/vm/dirty_bytes 2>/dev/null || echo "N/A"' \
      'echo -n "vm.dirty_background_bytes = "' \
      'sysctl -n vm.dirty_background_bytes 2>/dev/null || cat /proc/sys/vm/dirty_background_bytes 2>/dev/null || echo "N/A"' \
      'echo -n "vm.overcommit_memory = "' \
      'sysctl -n vm.overcommit_memory 2>/dev/null || cat /proc/sys/vm/overcommit_memory 2>/dev/null || echo "N/A"' \
      'echo ""' \
      'echo "--- 网络参数 ---"' \
      'echo -n "net.core.somaxconn = "' \
      'sysctl -n net.core.somaxconn 2>/dev/null || cat /proc/sys/net/core/somaxconn 2>/dev/null || echo "N/A"' \
      'echo -n "net.ipv4.tcp_max_syn_backlog = "' \
      'sysctl -n net.ipv4.tcp_max_syn_backlog 2>/dev/null || cat /proc/sys/net/ipv4/tcp_max_syn_backlog 2>/dev/null || echo "N/A"' \
      'echo -n "net.ipv4.ip_local_port_range = "' \
      'sysctl -n net.ipv4.ip_local_port_range 2>/dev/null || cat /proc/sys/net/ipv4/ip_local_port_range 2>/dev/null || echo "N/A"' \
      'echo ""' \
      'echo "--- 文件系统参数 ---"' \
      'echo -n "fs.file-max = "' \
      'sysctl -n fs.file-max 2>/dev/null || cat /proc/sys/fs/file-max 2>/dev/null || echo "N/A"' \
      'echo -n "fs.aio-max-nr = "' \
      'sysctl -n fs.aio-max-nr 2>/dev/null || cat /proc/sys/fs/aio-max-nr 2>/dev/null || echo "N/A"' \
      'echo ""' \
      'echo "--- 内核参数 ---"' \
      'echo -n "kernel.shmmax = "' \
      'sysctl -n kernel.shmmax 2>/dev/null || cat /proc/sys/kernel/shmmax 2>/dev/null || echo "N/A"' \
      'echo -n "kernel.shmall = "' \
      'sysctl -n kernel.shmall 2>/dev/null || cat /proc/sys/kernel/shmall 2>/dev/null || echo "N/A"' \
      'echo -n "kernel.shmmni = "' \
      'sysctl -n kernel.shmmni 2>/dev/null || cat /proc/sys/kernel/shmmni 2>/dev/null || echo "N/A"' \
      'echo -n "kernel.sem = "' \
      'sysctl -n kernel.sem 2>/dev/null || cat /proc/sys/kernel/sem 2>/dev/null || echo "N/A"' \
      'echo ""' \
      'echo "--- 其他重要参数 ---"' \
      'echo -n "透明大页（Transparent Huge Pages）= "' \
      'cat /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null || echo "N/A"' \
      'echo ""' \
      'echo "--- 资源限制（ulimit）---"' \
      'ulimit -a 2>/dev/null || echo "无法获取ulimit信息"' \
; } > "${TMP_DIR}/os_params_collect.sh"
    
    local params_result
    if [ "$LOCAL_MODE" = "true" ]; then
        params_result=$(execute_local "bash \"${TMP_DIR}/os_params_collect.sh\"" || true)
    else
        params_result=$(run_os_script_file_on_target "${TMP_DIR}/os_params_collect.sh" || true)
    fi
    
    if [ -n "$params_result" ]; then
        echo "$params_result" > "${TMP_DIR}/os_parameters.txt"
        log INFO "操作系统内核参数采集完成"
    else
        echo "无法采集操作系统参数" > "${TMP_DIR}/os_parameters.txt"
        log WARNING "操作系统内核参数采集失败（可能需要root权限）"
    fi
}

# 采集 /proc/meminfo（完整内容）
collect_os_meminfo() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6

    log INFO "采集/proc/meminfo..."

    { printf '%s\n' \
      '#!/bin/bash' \
      'set +e' \
      'if [ -r /proc/meminfo ]; then' \
      '    cat /proc/meminfo' \
      'else' \
      '    echo "无权限访问"' \
      'fi' \
; } > "${TMP_DIR}/os_meminfo_collect.sh"

    local meminfo_result
    if [ "$LOCAL_MODE" = "true" ]; then
        meminfo_result=$(execute_local "bash \"${TMP_DIR}/os_meminfo_collect.sh\"" || true)
    else
        meminfo_result=$(run_os_script_file_on_target "${TMP_DIR}/os_meminfo_collect.sh" || true)
    fi

    if [ -n "$meminfo_result" ]; then
        echo "$meminfo_result" > "${TMP_DIR}/os_meminfo.txt"
        log INFO "/proc/meminfo 采集完成"
    else
        echo "无权限访问" > "${TMP_DIR}/os_meminfo.txt"
        log WARNING "/proc/meminfo 采集失败或返回空内容"
    fi
}

# 采集操作系统日志
collect_os_log() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6
    
    log INFO "采集操作系统日志..."
    
    # 仅采集 messages/syslog：
    # - 可访问：若发现 error/warn 输出风险日志；否则输出最近10条日志
    # - 不可访问或不存在：输出“无权限访问”
    { printf '%s\n' \
      '#!/bin/bash' \
      'set +e' \
      'log_file=""' \
      'if [ -r /var/log/messages ]; then' \
      '    log_file="/var/log/messages"' \
      'elif [ -r /var/log/syslog ]; then' \
      '    log_file="/var/log/syslog"' \
      'fi' \
      'if [ -n "$log_file" ]; then' \
      '    RISK=$(tail -n 3000 "$log_file" 2>/dev/null | grep -iE "(error|warn|critical|failed|fail|fatal|panic)" 2>/dev/null | tail -n 100)' \
      '    if [ -n "$RISK" ]; then' \
      '        echo "$RISK"' \
      '    else' \
      '        echo "未发现错误日志，输出最近10条系统日志："' \
      '        tail -n 10 "$log_file" 2>/dev/null || echo "无权限访问"' \
      '    fi' \
      'else' \
      '    echo "无权限访问"' \
      'fi' \
; } > "${TMP_DIR}/os_log_collect.sh"
    
    local os_log_result
    if [ "$LOCAL_MODE" = "true" ]; then
        os_log_result=$(execute_local "bash \"${TMP_DIR}/os_log_collect.sh\"" || true)
    else
        os_log_result=$(run_os_script_file_on_target "${TMP_DIR}/os_log_collect.sh" || true)
    fi
    
    if [ "$os_log_result" = "无权限访问" ]; then
        echo "无权限访问" > "${TMP_DIR}/os_log.txt"
        log WARNING "系统日志不可访问或不存在"
    elif [ -n "$os_log_result" ] && [ "$os_log_result" != "" ]; then
        echo "$os_log_result" > "${TMP_DIR}/os_log.txt"
        log INFO "操作系统日志采集完成"
    else
        echo "无权限访问" > "${TMP_DIR}/os_log.txt"
        log WARNING "系统日志采集返回空内容"
    fi
}

# 采集磁盘 SMART 并做初步风险分析（SATA/SAS/NVMe）
collect_disk_smart() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6

    log INFO "采集磁盘 SMART 并进行初步风险分析..."

    { printf '%s\n' \
      '#!/bin/bash' \
      'set +e' \
      'if ! command -v smartctl >/dev/null 2>&1; then' \
      '    echo "SMART 采集结果：未安装 smartctl，无法采集 SMART 数据"' \
      '    exit 0' \
      'fi' \
      'if ! command -v lsblk >/dev/null 2>&1; then' \
      '    echo "SMART 采集结果：未安装 lsblk，无法枚举磁盘设备，无法采集 SMART 数据"' \
      '    exit 0' \
      'fi' \
      'disk_list=$(lsblk -dn -o NAME,TYPE 2>/dev/null | awk '\''$2=="disk"{print "/dev/"$1}'\'')' \
      'if [ -z "$disk_list" ]; then' \
      '    echo "SMART 采集结果：未发现可采集磁盘设备"' \
      '    exit 0' \
      'fi' \
      'risk_found=0' \
      'checked_count=0' \
      'echo "SMART 采集时间: $(date '\''+%Y-%m-%d %H:%M:%S'\'')"' \
      'echo ""' \
      'for dev in $disk_list; do' \
      '    checked_count=$((checked_count + 1))' \
      '    info_out=$(smartctl -i "$dev" 2>/dev/null)' \
      '    health_out=$(smartctl -H "$dev" 2>/dev/null)' \
      '    attrs_out=$(smartctl -A "$dev" 2>/dev/null)' \
      '    all_out=$(smartctl -a "$dev" 2>/dev/null)' \
      '    model=$(echo "$info_out" | awk -F: '\''/Device Model|Model Number|Product/{sub(/^[ \t]+/,"",$2);print $2;exit}'\'')' \
      '    [ -z "$model" ] && model="unknown"' \
      '    proto=$(echo "$info_out" | awk -F: '\''/Transport protocol/{sub(/^[ \t]+/,"",$2);print $2;exit}'\'')' \
      '    [ -z "$proto" ] && proto=$(echo "$info_out" | awk -F: '\''/SATA Version is|NVMe Version/{sub(/^[ \t]+/,"",$2);print $2;exit}'\'')' \
      '    [ -z "$proto" ] && proto="unknown"' \
      '    echo "========== 设备: $dev =========="' \
      '    echo "model: $model"' \
      '    echo "protocol: $proto"' \
      '    overall_line=$(echo "$health_out" | grep -Ei '\''SMART overall-health|SMART Health Status|SMART overall-health self-assessment test result'\'' | head -n1)' \
      '    if [ -n "$overall_line" ]; then' \
      '        echo "overall_health: $overall_line"' \
      '        if ! echo "$overall_line" | grep -Eiq '\''PASSED|OK'\''; then' \
      '            risk_found=1' \
      '            echo "RISK: SMART 总体健康状态异常 -> $overall_line"' \
      '        fi' \
      '    fi' \
      '    realloc=$(echo "$attrs_out" | awk '\''$1==5{print $10; exit}'\'')' \
      '    pending=$(echo "$attrs_out" | awk '\''$1==197{print $10; exit}'\'')' \
      '    offline_unc=$(echo "$attrs_out" | awk '\''$1==198{print $10; exit}'\'')' \
      '    crc_err=$(echo "$attrs_out" | awk '\''$1==199{print $10; exit}'\'')' \
      '    [ -z "$realloc" ] && realloc=0' \
      '    [ -z "$pending" ] && pending=0' \
      '    [ -z "$offline_unc" ] && offline_unc=0' \
      '    [ -z "$crc_err" ] && crc_err=0' \
      '    echo "reallocated_sector_ct: $realloc"' \
      '    echo "current_pending_sector: $pending"' \
      '    echo "offline_uncorrectable: $offline_unc"' \
      '    echo "udma_crc_error_count: $crc_err"' \
      '    if [ "$realloc" -gt 0 ] 2>/dev/null; then risk_found=1; echo "RISK: Reallocated_Sector_Ct > 0 -> $realloc"; fi' \
      '    if [ "$pending" -gt 0 ] 2>/dev/null; then risk_found=1; echo "RISK: Current_Pending_Sector > 0 -> $pending"; fi' \
      '    if [ "$offline_unc" -gt 0 ] 2>/dev/null; then risk_found=1; echo "RISK: Offline_Uncorrectable > 0 -> $offline_unc"; fi' \
      '    critical_warning=$(echo "$all_out" | awk -F: '\''/Critical Warning/{sub(/^[ \t]+/,"",$2);print $2;exit}'\'')' \
      '    media_errors=$(echo "$all_out" | awk -F: '\''/Media and Data Integrity Errors|Media Errors/{sub(/^[ \t]+/,"",$2);print $2;exit}'\'')' \
      '    err_log_entries=$(echo "$all_out" | awk -F: '\''/Error Information Log Entries|num_err_log_entries/{sub(/^[ \t]+/,"",$2);print $2;exit}'\'')' \
      '    [ -n "$critical_warning" ] && echo "nvme_critical_warning: $critical_warning"' \
      '    [ -n "$media_errors" ] && echo "nvme_media_errors: $media_errors"' \
      '    [ -n "$err_log_entries" ] && echo "nvme_error_log_entries: $err_log_entries"' \
      '    if [ -n "$critical_warning" ] && [ "$critical_warning" != "0x00" ] && [ "$critical_warning" != "0" ]; then risk_found=1; echo "RISK: NVMe Critical Warning 非 0 -> $critical_warning"; fi' \
      '    if [ -n "$media_errors" ] && [ "$media_errors" -gt 0 ] 2>/dev/null; then risk_found=1; echo "RISK: NVMe Media Errors > 0 -> $media_errors"; fi' \
      '    echo ""' \
      'done' \
      'if [ "$checked_count" -gt 0 ] && [ "$risk_found" -eq 0 ]; then' \
      '    echo "当前SMART数据不存在任何风险"' \
      'fi' \
    ; } > "${TMP_DIR}/os_smart_collect.sh"

    local smart_result
    if [ "$LOCAL_MODE" = "true" ]; then
        smart_result=$(execute_local "bash \"${TMP_DIR}/os_smart_collect.sh\"" || true)
    else
        smart_result=$(run_os_script_file_on_target "${TMP_DIR}/os_smart_collect.sh" || true)
    fi
    if [ -n "$smart_result" ]; then
        echo "$smart_result" > "${TMP_DIR}/os_smart.txt"
        log INFO "SMART 采集与分析完成"
    else
        echo "SMART 采集结果为空（可能权限不足或设备不支持）" > "${TMP_DIR}/os_smart.txt"
        log WARNING "SMART 采集返回空结果"
    fi
}

# 采集 OS 基础摘要信息（发行版/内核参数/最近重启/clocksource），用于写入 os_info_summary
collect_os_basic_summary_info() {
    local host=$1
    local port=$2
    local username=$3
    local password=$4
    local ssh_key_path=$5
    local data_file=$6

    log INFO "采集 OS 基础摘要信息..."

    { printf '%s\n' \
      '#!/bin/bash' \
      'set +e' \
      'get_os_pretty_name() {' \
      '    local os_name=""' \
      '    if [ -r /etc/os-release ]; then' \
      '        . /etc/os-release 2>/dev/null' \
      '        os_name="${PRETTY_NAME:-}"' \
      '        if [ -z "$os_name" ]; then' \
      '            os_name="${NAME:-}"' \
      '            [ -n "${VERSION:-}" ] && os_name="${os_name} ${VERSION}"' \
      '        fi' \
      '    fi' \
      '    [ -z "$os_name" ] && [ -r /etc/redhat-release ] && os_name="$(cat /etc/redhat-release 2>/dev/null)"' \
      '    [ -z "$os_name" ] && [ -r /etc/centos-release ] && os_name="$(cat /etc/centos-release 2>/dev/null)"' \
      '    [ -z "$os_name" ] && [ -r /etc/kylin-release ] && os_name="$(cat /etc/kylin-release 2>/dev/null)"' \
      '    [ -z "$os_name" ] && [ -r /etc/openEuler-release ] && os_name="$(cat /etc/openEuler-release 2>/dev/null)"' \
      '    [ -z "$os_name" ] && command -v lsb_release >/dev/null 2>&1 && os_name="$(lsb_release -ds 2>/dev/null | sed '\''s/^"//;s/"$//'\'' )"' \
      '    [ -z "$os_name" ] && os_name="$(uname -srm 2>/dev/null)"' \
      '    echo "${os_name:-unknown}"' \
      '}' \
      'get_last_boot_time() {' \
      '    local bt=""' \
      '    bt="$(who -b 2>/dev/null | sed -E '\''s/.*system boot[[:space:]]+//'\'' )"' \
      '    [ -z "$bt" ] && bt="$(uptime -s 2>/dev/null)"' \
      '    [ -z "$bt" ] && bt="unknown"' \
      '    echo "$bt"' \
      '}' \
      'get_clocksource_current() {' \
      '    if [ -r /sys/devices/system/clocksource/clocksource0/current_clocksource ]; then' \
      '        cat /sys/devices/system/clocksource/clocksource0/current_clocksource 2>/dev/null' \
      '    else' \
      '        echo "unknown"' \
      '    fi' \
      '}' \
      'get_clocksource_available() {' \
      '    if [ -r /sys/devices/system/clocksource/clocksource0/available_clocksource ]; then' \
      '        cat /sys/devices/system/clocksource/clocksource0/available_clocksource 2>/dev/null' \
      '    else' \
      '        echo "unknown"' \
      '    fi' \
      '}' \
      'get_cpu_cores() {' \
      '    local c=""' \
      '    c="$(nproc 2>/dev/null)"' \
      '    [ -z "$c" ] && c="$(getconf _NPROCESSORS_ONLN 2>/dev/null)"' \
      '    [ -z "$c" ] && c="$(grep -c '\''^processor'\'' /proc/cpuinfo 2>/dev/null)"' \
      '    [ -z "$c" ] && c="unknown"' \
      '    echo "$c"' \
      '}' \
      'get_mem_total() {' \
      '    local m=""' \
      '    if [ -r /proc/meminfo ]; then' \
      '        m="$(awk '\''/^MemTotal:/{print $2 " kB"; exit}'\'' /proc/meminfo 2>/dev/null)"' \
      '    fi' \
      '    if [ -z "$m" ] && command -v free >/dev/null 2>&1; then' \
      '        m="$(free -h 2>/dev/null | awk '\''/^Mem:/{print $2; exit}'\'')"' \
      '    fi' \
      '    [ -z "$m" ] && m="unknown"' \
      '    echo "$m"' \
      '}' \
      'os_pretty="$(get_os_pretty_name)"' \
      'kernel_cmdline="$(cat /proc/cmdline 2>/dev/null)"' \
      '[ -z "$kernel_cmdline" ] && kernel_cmdline="unknown"' \
      'last_boot_time="$(get_last_boot_time)"' \
      'clocksource_current="$(get_clocksource_current)"' \
      'clocksource_available="$(get_clocksource_available)"' \
      'cpu_cores="$(get_cpu_cores)"' \
      'mem_total="$(get_mem_total)"' \
      'echo "os_version: ${os_pretty}"' \
      'echo "kernel_cmdline: ${kernel_cmdline}"' \
      'echo "last_boot_time: ${last_boot_time}"' \
      'echo "clocksource_current: ${clocksource_current}"' \
      'echo "clocksource_available: ${clocksource_available}"' \
      'echo "cpu_cores: ${cpu_cores}"' \
      'echo "mem_total: ${mem_total}"' \
    ; } > "${TMP_DIR}/os_basic_summary.sh"

    local basic_result
    if [ "$LOCAL_MODE" = "true" ]; then
        basic_result=$(execute_local "bash \"${TMP_DIR}/os_basic_summary.sh\"" || true)
    else
        basic_result=$(run_os_script_file_on_target "${TMP_DIR}/os_basic_summary.sh" || true)
    fi
    if [ -n "$basic_result" ]; then
        echo "$basic_result" > "${TMP_DIR}/os_basic_summary.txt"
        log INFO "OS 基础摘要信息采集完成"
    else
        {
            echo "os_version: unknown"
            echo "kernel_cmdline: unknown"
            echo "last_boot_time: unknown"
            echo "clocksource_current: unknown"
            echo "clocksource_available: unknown"
            echo "cpu_cores: unknown"
            echo "mem_total: unknown"
        } > "${TMP_DIR}/os_basic_summary.txt"
        log WARNING "OS 基础摘要信息采集为空，已写入占位值"
    fi
}

# 汇总操作系统采集信息
collect_os_info() {
    log INFO "开始采集操作系统信息..."
    
    # 确保在远程模式下有OS连接信息
    if [ "$LOCAL_MODE" != "true" ] && [ -z "$OS_HOST" ]; then
        log WARNING "远程模式下未配置操作系统连接信息，跳过OS采集"
        return
    fi
    
    local os_output="$FRAG_DIR/os_info_summary.txt"
    
    # 创建汇总文件头部
    {
        echo "采集时间: $(date '+%Y-%m-%d %H:%M:%S')  采集策略: 单次采集"
    } > "$os_output"

    collect_os_basic_summary_info "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    if [ -f "${TMP_DIR}/os_basic_summary.txt" ] && [ -s "${TMP_DIR}/os_basic_summary.txt" ]; then
        {
            echo ""
            cat "${TMP_DIR}/os_basic_summary.txt"
        } >> "$os_output"
    fi
    
    # 调用各个采集函数
    collect_cpu_info "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_memory_info_os "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_runqueue_info "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_swap_info "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_io_stats "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_io_await "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_iostat "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_vmstat "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_disk_usage "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_parameters "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_meminfo "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_disk_smart "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_top_cpu_processes "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_top_mem_processes "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_log "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_host_dmesg_and_alerts
    
    # 将各个采集结果单独保存
    if [ -f "${TMP_DIR}/cpu_info.txt" ]; then
        cp "${TMP_DIR}/cpu_info.txt" "$FRAG_DIR/os_cpu.txt"
    fi
    if [ -f "${TMP_DIR}/mem_info.txt" ]; then
        cp "${TMP_DIR}/mem_info.txt" "$FRAG_DIR/os_memory.txt"
    fi
    if [ -f "${TMP_DIR}/runqueue_info.txt" ]; then
        cp "${TMP_DIR}/runqueue_info.txt" "$FRAG_DIR/os_runqueue.txt"
    fi
    if [ -f "${TMP_DIR}/swap_info.txt" ]; then
        cp "${TMP_DIR}/swap_info.txt" "$FRAG_DIR/os_swap.txt"
    fi
    if [ -f "${TMP_DIR}/io_stats.txt" ]; then
        cp "${TMP_DIR}/io_stats.txt" "$FRAG_DIR/os_io_stats.txt"
    fi
    if [ -f "${TMP_DIR}/io_await_info.txt" ]; then
        cp "${TMP_DIR}/io_await_info.txt" "$FRAG_DIR/os_io_latency.txt"
    fi
    if [ -f "${TMP_DIR}/os_iostat.txt" ]; then
        cp "${TMP_DIR}/os_iostat.txt" "$FRAG_DIR/os_iostat.txt"
    fi
    if [ -f "${TMP_DIR}/os_vmstat.txt" ]; then
        cp "${TMP_DIR}/os_vmstat.txt" "$FRAG_DIR/os_vmstat.txt"
    fi
    if [ -f "${TMP_DIR}/disk_usage.txt" ]; then
        cp "${TMP_DIR}/disk_usage.txt" "$FRAG_DIR/os_disk_usage.txt"
    fi
    if [ -f "${TMP_DIR}/os_parameters.txt" ]; then
        cp "${TMP_DIR}/os_parameters.txt" "$FRAG_DIR/os_parameters.txt"
    fi
    if [ -f "${TMP_DIR}/os_meminfo.txt" ]; then
        cp "${TMP_DIR}/os_meminfo.txt" "$FRAG_DIR/os_meminfo.txt"
    fi
    if [ -f "${TMP_DIR}/os_smart.txt" ]; then
        cp "${TMP_DIR}/os_smart.txt" "$FRAG_DIR/os_smart.txt"
    fi
    if [ -f "${TMP_DIR}/top_cpu_processes.txt" ]; then
        cp "${TMP_DIR}/top_cpu_processes.txt" "$FRAG_DIR/os_top_cpu_processes.txt"
    fi
    if [ -f "${TMP_DIR}/top_mem_processes.txt" ]; then
        cp "${TMP_DIR}/top_mem_processes.txt" "$FRAG_DIR/os_top_mem_processes.txt"
    fi
    if [ -f "${TMP_DIR}/os_log.txt" ]; then
        cp "${TMP_DIR}/os_log.txt" "$FRAG_DIR/os_system_log.txt"
    fi
    
    log INFO "操作系统信息采集完成: $os_output"
    log INFO "OS 章节碎片（仅用于合并终包，进程结束删除）: $FRAG_DIR/os_*.txt"
}

# ==================== OS多次采集功能 ====================

# OS多次采集（支持--os-collect-interval和--os-collect-count）
collect_os_multiple_times() {
    if [ "$OS_COLLECT_INTERVAL" -eq 0 ] || [ "$OS_COLLECT_COUNT" -eq 0 ]; then
        log INFO "跳过OS多次采集（interval或count为0）"
        return
    fi
    
    log INFO "开始OS多次采集: 间隔${OS_COLLECT_INTERVAL}秒, 共${OS_COLLECT_COUNT}次"
    log INFO "多次采集指标: CPU、内存、运行队列、Swap、IO、进程状态、网卡错包/丢包"
    log INFO "单次采集指标: 磁盘、OS 参数、OS 泛匹配日志、dmesg 与近1h journal/ messages 健康告警（仅一次）"
    
    # 先采集单次数据（磁盘使用、OS参数、OS日志）
    log INFO "采集单次OS数据..."
    collect_disk_usage "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_parameters "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_meminfo "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_iostat "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_vmstat "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_disk_smart "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    collect_os_log "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    
    # 保存单次采集的数据到文件
    if [ -f "${TMP_DIR}/disk_usage.txt" ]; then
        cp "${TMP_DIR}/disk_usage.txt" "$FRAG_DIR/os_disk_usage.txt"
    fi
    if [ -f "${TMP_DIR}/os_parameters.txt" ]; then
        cp "${TMP_DIR}/os_parameters.txt" "$FRAG_DIR/os_parameters.txt"
    fi
    if [ -f "${TMP_DIR}/os_meminfo.txt" ]; then
        cp "${TMP_DIR}/os_meminfo.txt" "$FRAG_DIR/os_meminfo.txt"
    fi
    if [ -f "${TMP_DIR}/os_smart.txt" ]; then
        cp "${TMP_DIR}/os_smart.txt" "$FRAG_DIR/os_smart.txt"
    fi
    if [ -f "${TMP_DIR}/os_iostat.txt" ]; then
        cp "${TMP_DIR}/os_iostat.txt" "$FRAG_DIR/os_iostat.txt"
    fi
    if [ -f "${TMP_DIR}/os_vmstat.txt" ]; then
        cp "${TMP_DIR}/os_vmstat.txt" "$FRAG_DIR/os_vmstat.txt"
    fi
    if [ -f "${TMP_DIR}/os_log.txt" ]; then
        cp "${TMP_DIR}/os_log.txt" "$FRAG_DIR/os_system_log.txt"
    fi
    collect_host_dmesg_and_alerts
    
    mkdir -p "${TMP_DIR}/os_mts"
    rm -f "${TMP_DIR}/net_errdrop_prev.txt" 2>/dev/null || true
    {
        echo "=== 操作系统多次采集时间序列（纯文本）==="
        echo "间隔（秒）: ${OS_COLLECT_INTERVAL}  次数: ${OS_COLLECT_COUNT}"
        echo ""
    } > "$FRAG_DIR/os_time_series.txt"
    
    # 开始多次采集（性能指标，明细均为文本，写入 os_time_series.txt）
    for ((i=1; i<=$OS_COLLECT_COUNT; i++)); do
        log INFO "第${i}/${OS_COLLECT_COUNT}次采集..."
        local collect_time=$(date '+%Y-%m-%d %H:%M:%S')
        
        collect_cpu_info "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
        collect_memory_info_os "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
        collect_runqueue_info "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
        collect_swap_info "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
        collect_io_stats "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
        collect_io_await "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
        collect_process_stats "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
        collect_net_errdrop_rate "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$OS_COLLECT_INTERVAL"
        
        local mts_path="${TMP_DIR}/os_mts/snap_$(printf '%03d' $i).txt"
        {
            echo "========== 第 ${i} / ${OS_COLLECT_COUNT} 次  采集时间: ${collect_time} =========="
            echo ""
            echo "---------- CPU ----------"
            if [ -f "${TMP_DIR}/cpu_info.txt" ] && [ -s "${TMP_DIR}/cpu_info.txt" ]; then
                cat "${TMP_DIR}/cpu_info.txt"
            else
                echo "无"
            fi
            echo ""
            echo "---------- 内存 ----------"
            if [ -f "${TMP_DIR}/mem_info.txt" ] && [ -s "${TMP_DIR}/mem_info.txt" ]; then
                cat "${TMP_DIR}/mem_info.txt"
            else
                echo "无"
            fi
            echo ""
            echo "---------- 运行队列/阻塞队列 ----------"
            if [ -f "${TMP_DIR}/runqueue_info.txt" ] && [ -s "${TMP_DIR}/runqueue_info.txt" ]; then
                cat "${TMP_DIR}/runqueue_info.txt"
            else
                echo "无"
            fi
            echo ""
            echo "---------- Swap ----------"
            if [ -f "${TMP_DIR}/swap_info.txt" ] && [ -s "${TMP_DIR}/swap_info.txt" ]; then
                cat "${TMP_DIR}/swap_info.txt"
            else
                echo "无"
            fi
            echo ""
            echo "---------- IO 统计 ----------"
            if [ -f "${TMP_DIR}/io_stats.txt" ] && [ -s "${TMP_DIR}/io_stats.txt" ]; then
                cat "${TMP_DIR}/io_stats.txt"
            else
                echo "无"
            fi
            echo ""
            echo "---------- IO 延迟( await ) ----------"
            if [ -f "${TMP_DIR}/io_await_info.txt" ] && [ -s "${TMP_DIR}/io_await_info.txt" ]; then
                cat "${TMP_DIR}/io_await_info.txt"
            else
                echo "无"
            fi
            echo ""
            echo "---------- 进程/线程状态 ----------"
            if [ -f "${TMP_DIR}/process_stats.txt" ] && [ -s "${TMP_DIR}/process_stats.txt" ]; then
                cat "${TMP_DIR}/process_stats.txt"
            else
                echo "无"
            fi
            echo ""
            echo "---------- 网卡错包/丢包(每秒) ----------"
            if [ -f "${TMP_DIR}/net_errdrop_rate.txt" ] && [ -s "${TMP_DIR}/net_errdrop_rate.txt" ]; then
                cat "${TMP_DIR}/net_errdrop_rate.txt"
            else
                echo "无"
            fi
        } > "$mts_path"
        cat "$mts_path" >> "$FRAG_DIR/os_time_series.txt"
        echo "" >> "$FRAG_DIR/os_time_series.txt"
        
        if [ $i -lt $OS_COLLECT_COUNT ]; then
            log INFO "等待${OS_COLLECT_INTERVAL}秒..."
            sleep $OS_COLLECT_INTERVAL
        fi
    done
    
    # 多次采集循环内指标写在 TMP_DIR；合并终包读 FRAG_DIR/os_*.txt，需同步最后一次快照
    if [ -f "${TMP_DIR}/cpu_info.txt" ]; then
        cp "${TMP_DIR}/cpu_info.txt" "$FRAG_DIR/os_cpu.txt"
    fi
    if [ -f "${TMP_DIR}/mem_info.txt" ]; then
        cp "${TMP_DIR}/mem_info.txt" "$FRAG_DIR/os_memory.txt"
    fi
    if [ -f "${TMP_DIR}/runqueue_info.txt" ]; then
        cp "${TMP_DIR}/runqueue_info.txt" "$FRAG_DIR/os_runqueue.txt"
    fi
    if [ -f "${TMP_DIR}/swap_info.txt" ]; then
        cp "${TMP_DIR}/swap_info.txt" "$FRAG_DIR/os_swap.txt"
    fi
    if [ -f "${TMP_DIR}/io_stats.txt" ]; then
        cp "${TMP_DIR}/io_stats.txt" "$FRAG_DIR/os_io_stats.txt"
    fi
    if [ -f "${TMP_DIR}/io_await_info.txt" ]; then
        cp "${TMP_DIR}/io_await_info.txt" "$FRAG_DIR/os_io_latency.txt"
    fi
    # 生成汇总文件
    local os_output="$FRAG_DIR/os_info_summary.txt"
    {
        echo "采集时间: $(date '+%Y-%m-%d %H:%M:%S')  采集策略: 多次采集（${OS_COLLECT_COUNT}次，间隔${OS_COLLECT_INTERVAL}秒）"
    } > "$os_output"
    collect_os_basic_summary_info "$OS_HOST" "$OS_PORT" "$OS_USERNAME" "$OS_PASSWORD" "$OS_SSH_KEY_PATH" "$FRAG_DIR"
    if [ -f "${TMP_DIR}/os_basic_summary.txt" ] && [ -s "${TMP_DIR}/os_basic_summary.txt" ]; then
        {
            echo ""
            cat "${TMP_DIR}/os_basic_summary.txt"
        } >> "$os_output"
    fi
    
    log INFO "OS多次采集完成"
    log INFO "OS 章节碎片（仅用于合并终包，进程结束删除）: $FRAG_DIR/os_*.txt"
}

# ==================== BIC-QA 平台格式采集数据（.txt，UTF-8）====================
# 规范见《BIC-QA诊断工具开发标准文档》：首段 metadata（一行 JSON）；
# 其余各 SECTION body 均为可读纯文本，不嵌入 JSON。

# 生成一行合法 JSON 元数据（含 db_type=2103 达梦、tool_code、起止时间、debug 布尔）
# 调用前需已设置 COLLECT_END_TIME（一般在 generate_bic_qa_package 开头）
build_bic_qa_metadata_line() {
    if [ -z "$COLLECT_END_TIME" ]; then
        COLLECT_END_TIME=$(date '+%Y-%m-%d %H:%M:%S')
    fi
    local host_val="${DB_HOST:-}"
    if [ -z "$host_val" ]; then
        host_val=$(hostname 2>/dev/null || echo "localhost")
    fi
    local dbname="${INSTANCE_NAME:-UNKNOWN}"
    local port_n="${DB_PORT:-5236}"
    if command -v python3 >/dev/null 2>&1; then
        BIC_DEBUG="$BIC_DEBUG" \
        TOOL_CODE="$TOOL_CODE" \
        COLLECT_START_TIME="$COLLECT_START_TIME" \
        COLLECT_END_TIME="$COLLECT_END_TIME" \
        DB_PORT="$port_n" \
        INSTANCE_NAME="$dbname" \
        BIC_HOST="$host_val" \
        python3 -c "
import json, os
d = {
    'db_type': '2103',
    'tool_code': os.environ.get('TOOL_CODE', 'dm_db_health_check'),
    'start_time': os.environ.get('COLLECT_START_TIME', ''),
    'end_time': os.environ.get('COLLECT_END_TIME', ''),
    'debug': os.environ.get('BIC_DEBUG', 'false').lower() == 'true',
    'host': os.environ.get('BIC_HOST', ''),
    'port': int(float(os.environ.get('DB_PORT', '5236'))),
    'database_name': os.environ.get('INSTANCE_NAME', 'UNKNOWN') or 'UNKNOWN',
}
print(json.dumps(d, ensure_ascii=False, separators=(',', ':')))
"
    else
        # 无 python3 时仅保证 ASCII/常用字符场景可用；含特殊字符时请安装 python3
        local dbool="false"
        if [ "$BIC_DEBUG" = "true" ]; then dbool="true"; fi
        printf '%s' "{\"db_type\":\"2103\",\"tool_code\":\"$TOOL_CODE\",\"start_time\":\"$COLLECT_START_TIME\",\"end_time\":\"$COLLECT_END_TIME\",\"debug\":$dbool,\"host\":\"$host_val\",\"port\":$port_n,\"database_name\":\"$dbname\"}"
        echo ""
    fi
}

# 向 BIC-QA 文件追加一个数据区块
bic_append_file_section() {
    local out_file=$1
    local section_name=$2
    local data_file=$3
    {
        echo "===SECTION:$section_name==="
        if [ -f "$data_file" ] && [ -s "$data_file" ]; then
            cat "$data_file"
        else
            echo "No data collected"
        fi
        echo "===END_SECTION:$section_name==="
        echo ""
    } >> "$out_file"
}

# 将多个文件用标题合并为一个区块（供 performance / memory 等）
bic_append_merged_section() {
    local out_file=$1
    local section_name=$2
    shift 2
    {
        echo "===SECTION:$section_name==="
        while [ $# -ge 2 ]; do
            local stitle=$1
            local spath=$2
            shift 2
            echo ""
            echo "~~~~~~~~~~ ${stitle} ~~~~~~~~~~"
            if [ -f "$spath" ] && [ -s "$spath" ]; then
                cat "$spath"
            else
                echo "No data collected"
            fi
        done
        echo "===END_SECTION:$section_name==="
        echo ""
    } >> "$out_file"
}

# 生成 BIC-QA 上传用单文件 .txt
generate_bic_qa_package() {
    log INFO "开始生成 BIC-QA 格式采集包（.txt，SECTION + metadata，db_type=2103）..."
    COLLECT_END_TIME=$(date '+%Y-%m-%d %H:%M:%S')
    if [ -z "${BIC_QA_OUT_FILE:-}" ]; then
        log ERROR "未设置 BIC-QA 输出路径（内部错误）"
        return 1
    fi
    local out_file="$BIC_QA_OUT_FILE"
    local out_dir
    out_dir=$(dirname "$out_file")
    log INFO "终包目标路径: $out_file"
    if command -v realpath >/dev/null 2>&1; then
        log INFO "终包目录(realpath): $(realpath "$out_dir" 2>/dev/null || echo "$out_dir")"
    else
        log INFO "终包目录: $out_dir"
    fi
    if [ ! -d "$out_dir" ]; then
        log INFO "创建终包目录: $out_dir"
        mkdir -p "$out_dir" || {
            log ERROR "无法创建终包目录: $out_dir"
            return 1
        }
    fi
    if [ ! -w "$out_dir" ]; then
        log ERROR "终包目录不可写: $out_dir（请检查权限或改用 -o 指定可写路径）"
        return 1
    fi
    if [ -z "$COLLECT_START_TIME" ]; then
        COLLECT_START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
    fi
    log INFO "正在写入 metadata 段到终包（首段 SECTION:metadata）..."
    {
        echo "===SECTION:metadata==="
        build_bic_qa_metadata_line
        echo "===END_SECTION:metadata==="
        echo ""
    } > "$out_file" || {
        log ERROR "写入终包失败（metadata 段）: $out_file"
        return 1
    }
    log INFO "metadata 已写入，开始追加各 SECTION（数据源目录: $FRAG_DIR）..."
    # 与规范中的区块命名建议对齐，便于平台 args.section_map 使用
    bic_append_file_section "$out_file" "instance_info" "$FRAG_DIR/instance_info.txt"
    bic_append_file_section "$out_file" "db_param" "$FRAG_DIR/param.txt"
    bic_append_file_section "$out_file" "archive" "$FRAG_DIR/archive.txt"
    bic_append_merged_section "$out_file" "performance" \
        "SYSSTAT" "$FRAG_DIR/sysstat.txt" \
        "WAIT_EVENT" "$FRAG_DIR/waitevent.txt" \
        "TIME_MODEL" "$FRAG_DIR/time_model.txt"
    bic_append_merged_section "$out_file" "storage_stats" \
        "Tablespace" "$FRAG_DIR/tbs.txt" \
        "Datafiles" "$FRAG_DIR/dbfile.txt" \
        "ASM Disk Group" "$FRAG_DIR/asm_group.txt" \
        "REDO" "$FRAG_DIR/redo.txt" \
        "Rollback/Transaction" "$FRAG_DIR/rbs.txt"
    bic_append_merged_section "$out_file" "topsql" \
        "topsql::sql_by_exec_time" "$FRAG_DIR/topsql_by_exec_time.txt" \
        "topsql::long_exec_sql" "$FRAG_DIR/topsql_long_exec_sql.txt" \
        "topsql::sql_by_mem" "$FRAG_DIR/topsql_sql_by_mem.txt" \
        "topsql::sql_exec_count" "$FRAG_DIR/topsql_sql_exec_count.txt" \
        "topsql::sqltext" "$FRAG_DIR/topsql_sqltext.txt"
    bic_append_merged_section "$out_file" "lock_info" \
        "Deadlock" "$FRAG_DIR/deadlock.txt" \
        "Blocking" "$FRAG_DIR/blocked.txt" \
        "Uncommitted SQL" "$FRAG_DIR/uncommittd.txt" \
        "Uncommitted Objects" "$FRAG_DIR/uncommitted_obj.txt"
    bic_append_merged_section "$out_file" "memory" \
        "V\$DB_CACHE" "$FRAG_DIR/vmem-db_cache.txt" \
        "V\$BUFFERPOOL" "$FRAG_DIR/vmem-buffer_pool.txt" \
        "V\$MEM_POOL" "$FRAG_DIR/vmem-mem_pool.txt" \
        "Total Memory" "$FRAG_DIR/vmem-memusage.txt" \
        "Bufferpool" "$FRAG_DIR/vmem-bufferpool_stat.txt" \
        "SCP_CACHE" "$FRAG_DIR/vmem-sqlcache.txt" \
        "CACHEITEM" "$FRAG_DIR/vmem-sqlcache_size.txt" \
        "Buffer Hit Rate" "$FRAG_DIR/vmem-bufferhit.txt"
    bic_append_merged_section "$out_file" "session" \
        "session::session_info" "$FRAG_DIR/session_info.txt" \
        "session::session_phy_read" "$FRAG_DIR/session_phy_read.txt" \
        "session::session_logic" "$FRAG_DIR/session_logic.txt" \
        "session::session_parse" "$FRAG_DIR/session_parse.txt"
    bic_append_merged_section "$out_file" "security" \
        "Security-Users" "$FRAG_DIR/secure-user.txt" \
        "Security-Policy" "$FRAG_DIR/secure-pwd.txt"
    bic_append_merged_section "$out_file" "instance_log" \
        "Instance Logs" "$FRAG_DIR/logs-instance.txt"
    bic_append_merged_section "$out_file" "backup" \
        "Backup Path" "$FRAG_DIR/backup.txt" \
        "backup_jobs" "$FRAG_DIR/backup_jobs.txt"
    bic_append_merged_section "$out_file" "os" \
        "os_info_summary" "$FRAG_DIR/os_info_summary.txt" \
        "os_iostat" "$FRAG_DIR/os_iostat.txt" \
        "os_vmstat" "$FRAG_DIR/os_vmstat.txt" \
        "file_system_usage" "$FRAG_DIR/os_disk_usage.txt" \
        "os_parameter" "$FRAG_DIR/os_parameters.txt" \
        "meminfo" "$FRAG_DIR/os_meminfo.txt" \
        "os_smart" "$FRAG_DIR/os_smart.txt" \
        "os_top_cpu_processes" "$FRAG_DIR/os_top_cpu_processes.txt" \
        "os_top_mem_processes" "$FRAG_DIR/os_top_mem_processes.txt" \
        "os_system_log" "$FRAG_DIR/os_system_log.txt" \
        "os_dmesg_log" "$FRAG_DIR/os_host_alerts.txt"
    if [ -f "$FRAG_DIR/os_time_series.txt" ] && [ -s "$FRAG_DIR/os_time_series.txt" ]; then
        bic_append_file_section "$out_file" "os-time_series" "$FRAG_DIR/os_time_series.txt"
    else
        {
            echo "===SECTION:os-time_series==="
            echo "OS time series is not generated (configure --os-collect-interval and --os-collect-count)."
            echo "===END_SECTION:os-time_series==="
            echo ""
        } >> "$out_file"
    fi
    if [ -f "$out_file" ] && [ -s "$out_file" ]; then
        log INFO "BIC-QA 采集包已生成: $out_file"
        if command -v du >/dev/null 2>&1; then
            log INFO "终包大小: $(du -h "$out_file" 2>/dev/null | awk '{print $1}')"
        fi
        if command -v wc >/dev/null 2>&1; then
            log INFO "终包行数: $(wc -l < "$out_file" 2>/dev/null || echo "?")"
        fi
        echo ""
        echo "=========================================="
        echo "BIC-QA 采集数据文件(请上传此 .txt): $out_file"
        echo "=========================================="
    else
        log ERROR "BIC-QA 采集包生成失败（文件不存在或为空）: $out_file"
        return 1
    fi
}

# ==================== 主采集流程 ====================

# 执行所有采集任务
run_collection() {
    log INFO "开始数据采集..."
    log INFO "BIC-QA 终包输出: $BIC_QA_OUT_FILE"
    COLLECT_START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
    local db_snap_count=5
    local db_snap_gap_count=$((db_snap_count - 1))
    local db_total_seconds=$((db_snap_gap_count * DB_COLLECT_INTERVAL))
    
    # 采集SYSSTAT、WAITEVENT和TIME MODEL数据
    log INFO "========================================"
    log INFO "开始采集SYSSTAT、等待事件和TIME MODEL数据"
    log INFO "SYSSTAT策略: ${db_snap_count}次快照，每次间隔${DB_COLLECT_INTERVAL}秒"
    log INFO "WAITEVENT策略: 2次快照（第1次和SYSSTAT同时，第2次在SYSSTAT全部完成后）"
    log INFO "TIME MODEL策略: 2次快照（第1次和SYSSTAT同时，第2次在SYSSTAT全部完成后）"
    log INFO "总耗时: 约${db_total_seconds}秒（${db_snap_gap_count}个间隔×${DB_COLLECT_INTERVAL}秒）"
    log INFO "========================================"
    
    # 第一步：采集WAITEVENT和TIME MODEL第一次快照（和SYSSTAT第一次同时）
    collect_wait_event_snapshot1
    collect_time_model_snapshot1
    
    # 第二步：采集SYSSTAT（5次快照，计算4个增量）
    collect_sysstat_multiple
    
    # 第三步：采集WAITEVENT和TIME MODEL第二次快照并计算增量
    collect_wait_event_snapshot2
    collect_time_model_snapshot2
    
    # 数据库采集（其他项目）
    collect_instance_info
    collect_db_params
    collect_archive_path
    collect_redo
    collect_tablespace
    collect_asm_group
    collect_datafiles
    collect_rollback
    collect_topsql
    collect_uncommitted_sql
    collect_uncommitted_objects
    collect_deadlock
    collect_blocked
    collect_memory_info
    collect_session_info
    collect_backup_info
    collect_security_info
    log INFO "【阶段】达梦数据库日志采集（完成后进入 OS 采集，再合并 BIC-QA 终包）"
    collect_db_logs
    log INFO "【阶段】达梦数据库日志采集已返回，继续 OS 采集与终包合并"
    
    # 操作系统采集
    if [ "$LOCAL_MODE" = "true" ] || [ -n "$OS_HOST" ]; then
        # 判断是否需要进行单次采集
        if [ "$OS_COLLECT_INTERVAL" -gt 0 ] && [ "$OS_COLLECT_COUNT" -gt 0 ]; then
            # 如果设置了多次采集，直接执行多次采集，跳过单次采集
            log INFO "检测到OS多次采集参数，跳过单次采集，直接执行多次采集"
            collect_os_multiple_times
        else
            # 没有设置多次采集，执行单次采集
            log INFO "执行OS单次采集"
            collect_os_info
        fi
    else
        log WARNING "未配置操作系统连接信息，跳过OS采集"
    fi

    log INFO "========== 开始合并 BIC-QA 终包（此前数据库/OS 采集步骤已全部结束）=========="
    if ! generate_bic_qa_package; then
        log ERROR "终包 generate_bic_qa_package 失败，未生成有效输出文件"
        return 1
    fi
    bic_qa_apply_filenamefix_metrics

    log INFO "所有数据采集完成！"
    if [ -n "$BIC_QA_OUT_FILE" ] && [ -f "$BIC_QA_OUT_FILE" ]; then
        log INFO "BIC-QA 采集终包: $BIC_QA_OUT_FILE"
    fi
}

# ==================== 参数解析 ====================

# 显示帮助信息
show_usage() {
    cat << EOF
达梦数据库健康检查采集工具 v1.0

用法: $0 [选项]

必需参数（达梦模式，远程采集）:
  -H, --db-host HOST           数据库主机地址
  -P, --db-port PORT           数据库端口（默认: 5236）
  -u, --db-username USER       数据库用户名（默认: SYSDBA）
  -p, --db-password PASS       数据库密码

可选参数:
  --dm-home PATH               达梦安装目录（可选，脚本会自动查找disql）
  --ld-library-path PATH       显式设置LD_LIBRARY_PATH（解决libdisql_dll.so缺失等动态库加载问题）
  --os-host HOST               操作系统主机地址（默认与数据库主机相同，本地模式不需要）
  --os-port PORT               SSH端口（默认: 22，本地模式不需要）
  --os-username USER           SSH用户名（默认与数据库用户名相同，本地模式不需要）
  --os-password PASS           SSH密码（默认与数据库密码相同，本地模式不需要）
  --os-ssh-key-path PATH       SSH密钥路径（本地模式不需要）
  --os-ssh-key-user USER       SSH密钥用户（默认: root，本地模式不需要）
  --local                      本地采集模式，不需要SSH连接（本地模式不需要输入IP和SSH参数）
  --log-path PATH              日志文件路径（默认: ./logs）
  --quiet-log                  关闭控制台日志输出
  --no-log-file                不生成日志文件
  -o, --output PATH            BIC-QA 终包 .txt 路径。绝对路径按原样写入；仅文件名或相对路径则相对**运行命令时的当前目录**
                               省略时默认: <当前目录>/DM_bic_qa_data_<YYYYMMDD_HHMMSS>.txt
  --tool-code CODE             元数据 tool_code（默认: dm_db_health_check），须与平台分析脚本一致
  --debug                      开启调试：metadata.debug=true，且保留 $TMP_DIR 临时文件用于定位
  -f                           强制模式：若输出文件已存在则允许覆盖（不影响任何采集项执行）
  --log-level LEVEL            日志级别: DEBUG|INFO|WARNING|ERROR（默认: INFO）
  --os-collect-interval SEC    操作系统多次采集的间隔时间（单位：秒，默认: 0表示不进行多次采集）
                               仅对OS数据有效，不影响数据库数据采集
  --os-collect-count COUNT     操作系统采集的次数（必须>0，不支持无限采集）
                               仅对OS数据有效，每次间隔SEC秒采集一次OS性能数据
  --db-collect-interval SEC    数据库性能快照间隔（单位：秒，默认: 30）
                              影响 SYSSTAT 多次快照采集间隔
  --sql-timeout SEC            SQL执行超时时间（秒，默认: 180，0=不设置超时）
  --sqllen N                  topsql::sqltext 中 SQL_TEXT 截断长度（字符）；0 表示不截断
  --filenamefix               文件名改为：yyyy-dd-mm-hh24-mi-ss-CxxMxx-原文件名（C/M为采集时段CPU/内存峰值）
  -h, --help                   显示此帮助信息

说明：
  1. BIC-QA 上传文件为单文件 .txt：首段 ===SECTION:metadata===（一行 JSON，含 db_type=2103、tool_code、
     start_time、end_time、debug），其后各数据段；分析脚本用 args.section_map 读取各区块。
  2. metadata 后会先输出一次性区块 instance_info，随后是 db_param、archive、performance、
     topsql、lock_info、storage_stats、memory、session、security、instance_log、backup、os 等。
  3. OS 多次采集：--os-collect-interval 与 --os-collect-count 时，时序在 os_time_series 区块（纯文本）。
  4. 作 OS 采集时，默认会检查能否读 /var/log/messages|syslog 或可用 journalctl；不可读时对应小节写入
     「无权限采集，无采集数据」，不中断终包生成。

示例:
  # 1. 交互式运行（无参数）
  $0

  # 2. 基本采集，终包写入当前目录下默认文件名 DM_bic_qa_data_<时间>.txt
  $0 -H 192.168.1.100 -P 5236 -u SYSDBA -p mypass

  # 2b. 指定终包路径（仅文件名则落在运行时的当前目录）
  $0 -H 192.168.1.100 -P 5236 -u SYSDBA -p mypass -o my_dm_collect.txt
  $0 -u SYSDBA -p mypass --local -o /tmp/dm_report.txt

  # 3. 本地模式采集（脚本运行在数据库主机上）
  $0 -u SYSDBA -p mypass --local

  # 4. 远程采集 + OS多次采集（每1秒采集一次OS数据，共10次）
  #    注意：数据库数据只采集一次，OS数据采集10次
  $0 -H 192.168.1.100 -P 5236 -u SYSDBA -p mypass \\
     --os-host 192.168.1.100 --os-username dmdba --os-password ospass \\
     --os-collect-interval 1 --os-collect-count 10

  # 5. 本地采集 + OS高频采集（每1秒采集一次OS数据，共10次）
  #    适用于捕获短时间内的OS性能波动
  $0 -u SYSDBA -p mypass --local --os-collect-interval 1 --os-collect-count 10

  # 6. 本地采集 + OS低频采集（每60秒采集一次OS数据，共5次）
  #    适用于长时间监控OS性能趋势
  $0 -u SYSDBA -p mypass --local --os-collect-interval 60 --os-collect-count 5

EOF
}

# 交互式输入
interactive_input() {
    log INFO "进入交互式输入模式"
    
    # 采集模式选择
    if [ "$LOCAL_MODE_FROM_ARG" != "true" ]; then
        if [ -z "$DB_HOST" ] && [ -z "$OS_HOST" ]; then
            echo "请选择采集模式："
            echo "  1) 本地采集（脚本运行在数据库所在主机，直接访问数据库和操作系统，无需SSH）"
            echo "  2) 远程采集（通过网络连接数据库，通过SSH访问操作系统）"
            read -p "请选择 [1/2]: " mode_choice
            
            if [ "$mode_choice" = "1" ]; then
                LOCAL_MODE=true
                log INFO "选择本地采集模式"
            else
                LOCAL_MODE=false
                log INFO "选择远程采集模式"
            fi
        fi
    fi
    
    # 数据库连接信息
    if [ "$LOCAL_MODE" != "true" ] && [ -z "$DB_HOST" ]; then
        read -p "请输入数据库主机地址: " DB_HOST
    fi
    
    if [ -z "$DB_PORT" ] || [ "$DB_PORT" = "$DEFAULT_DB_PORT" ]; then
        read -p "请输入数据库端口 [默认: $DEFAULT_DB_PORT]: " input_port
        DB_PORT=${input_port:-$DEFAULT_DB_PORT}
    fi
    
    if [ -z "$DB_USERNAME" ]; then
        read -p "请输入数据库用户名 [默认: SYSDBA]: " input_user
        DB_USERNAME=${input_user:-SYSDBA}
    fi
    
    if [ -z "$DB_PASSWORD" ]; then
        read -sp "请输入数据库密码: " DB_PASSWORD
        echo ""
    fi
    
    # 操作系统连接信息（仅远程模式）
    if [ "$LOCAL_MODE" != "true" ]; then
        if [ -z "$OS_HOST" ]; then
            read -p "请输入操作系统主机地址 [默认: $DB_HOST]: " input_os_host
            OS_HOST=${input_os_host:-$DB_HOST}
        fi
        
        if [ -z "$OS_USERNAME" ]; then
            read -p "请输入SSH用户名 [默认: $DB_USERNAME]: " input_os_user
            OS_USERNAME=${input_os_user:-$DB_USERNAME}
        fi
        
        if [ -z "$OS_PASSWORD" ] && [ -z "$OS_SSH_KEY_PATH" ]; then
            read -sp "请输入SSH密码（如使用密钥请留空）: " OS_PASSWORD
            echo ""
            
            if [ -z "$OS_PASSWORD" ]; then
                read -p "请输入SSH密钥路径: " OS_SSH_KEY_PATH
            fi
        fi
    fi
    
    log INFO "交互式输入完成"
}

# 解析命令行参数
parse_args() {
    while [ $# -gt 0 ]; do
        case $1 in
            -h|--help)
                show_usage
                exit 0
                ;;
            -H|--db-host)
                DB_HOST="$2"
                shift 2
                ;;
            -P|--db-port)
                DB_PORT="$2"
                shift 2
                ;;
            -u|--db-username)
                DB_USERNAME="$2"
                shift 2
                ;;
            -p|--db-password)
                DB_PASSWORD="$2"
                shift 2
                ;;
            -o|--output)
                OUTPUT_ARG="$2"
                shift 2
                ;;
            --dm-home)
                DM_HOME="$2"
                shift 2
                ;;
            --ld-library-path)
                LD_LIBRARY_PATH_OVERRIDE="$2"
                shift 2
                ;;
            --os-host)
                OS_HOST="$2"
                shift 2
                ;;
            --os-port)
                OS_PORT="$2"
                shift 2
                ;;
            --os-username)
                OS_USERNAME="$2"
                shift 2
                ;;
            --os-password)
                OS_PASSWORD="$2"
                shift 2
                ;;
            --os-ssh-key-path)
                OS_SSH_KEY_PATH="$2"
                shift 2
                ;;
            --os-ssh-key-user)
                OS_SSH_KEY_USER="$2"
                shift 2
                ;;
            --local)
                LOCAL_MODE=true
                LOCAL_MODE_FROM_ARG=true
                shift
                ;;
            --log-path)
                LOG_DIR="$2"
                shift 2
                ;;
            --quiet-log)
                QUIET_LOG=true
                shift
                ;;
            --no-log-file)
                NO_LOG_FILE=true
                shift
                ;;
            --log-level)
                LOG_LEVEL="$2"
                shift 2
                ;;
            --os-collect-interval)
                OS_COLLECT_INTERVAL="$2"
                shift 2
                ;;
            --os-collect-count)
                OS_COLLECT_COUNT="$2"
                shift 2
                ;;
            --db-collect-interval)
                DB_COLLECT_INTERVAL="$2"
                shift 2
                ;;
            --sql-timeout)
                SQL_TIMEOUT="$2"
                shift 2
                ;;
            --sqllen)
                SQLTEXT_MAX_LEN="$2"
                shift 2
                ;;
            --filenamefix)
                FILENAME_FIX=true
                shift
                ;;
            --tool-code)
                TOOL_CODE="$2"
                shift 2
                ;;
            --debug)
                BIC_DEBUG=true
                KEEP_TMP_ON_EXIT=true
                shift
                ;;
            -f)
                PERMISSIVE_HOST_LOGS=true
                shift
                ;;
            *)
                log ERROR "未知参数: $1"
                show_usage
                exit 1
                ;;
        esac
    done
}

# ==================== 主程序 ====================

main() {
    # 解析命令行参数
    parse_args "$@"
    
    # 初始化日志
    init_logger "$LOG_DIR" "$LOG_LEVEL"

    if ! [[ "$SQLTEXT_MAX_LEN" =~ ^[0-9]+$ ]]; then
        log ERROR "--sqllen 必须是非负整数，当前值: $SQLTEXT_MAX_LEN"
        exit 1
    fi
    
    # 如果没有提供必需参数，进入交互模式
    if [ -z "$DB_PASSWORD" ] || ([ "$LOCAL_MODE" != "true" ] && [ -z "$DB_HOST" ]); then
        interactive_input
    fi
    
    # 检查必需的命令
    if ! check_required_commands; then
        log ERROR "缺少必需的命令，请安装后重试"
        exit 1
    fi
    
    # 设置默认值
    if [ "$LOCAL_MODE" != "true" ] && [ -z "$OS_HOST" ]; then
        OS_HOST="$DB_HOST"
    fi
    
    if [ -z "$OS_USERNAME" ]; then
        OS_USERNAME="$DB_USERNAME"
    fi
    
    if [ -z "$OS_PASSWORD" ] && [ -z "$OS_SSH_KEY_PATH" ] && [ "$LOCAL_MODE" != "true" ]; then
        OS_PASSWORD="$DB_PASSWORD"
    fi

    bic_qa_set_output_path "$OUTPUT_ARG"
    if [ -f "$BIC_QA_OUT_FILE" ]; then
        if [ "$PERMISSIVE_HOST_LOGS" = "true" ]; then
            log WARNING "输出文件已存在，因 -f 参数启用覆盖: $BIC_QA_OUT_FILE"
        else
            log ERROR "输出文件已存在: $BIC_QA_OUT_FILE"
            log ERROR "如需覆盖，请添加 -f 参数后重试"
            exit 1
        fi
    fi
    
    # 显示配置信息
    log INFO "配置信息:"
    log INFO "  采集模式: $([ "$LOCAL_MODE" = "true" ] && echo "本地采集" || echo "远程采集")"
    if [ "$LOCAL_MODE" != "true" ]; then
        log INFO "  数据库主机: $DB_HOST:$DB_PORT"
        log INFO "  操作系统主机: $OS_HOST:$OS_PORT"
    fi
    log INFO "  数据库用户: $DB_USERNAME"
    log INFO "  BIC-QA 输出文件: $BIC_QA_OUT_FILE"
    log INFO "  SQLTEXT 截断长度(--sqllen): $SQLTEXT_MAX_LEN"
    log INFO "  文件名规则(--filenamefix): $FILENAME_FIX（yyyy-dd-mm-hh24-mi-ss-CxxMxx-原文件名）"
    log INFO "  日志级别: $LOG_LEVEL"
    log INFO "  DB 性能采集间隔: ${DB_COLLECT_INTERVAL}秒"
    if [ "$KEEP_TMP_ON_EXIT" = "true" ]; then
        log INFO "  DEBUG 临时目录(将保留): $TMP_DIR"
    fi
    
    # 执行采集
    if ! run_collection; then
        log ERROR "采集流程失败，未生成有效终包: $BIC_QA_OUT_FILE"
        exit 1
    fi
    if [ ! -f "$BIC_QA_OUT_FILE" ] || [ ! -s "$BIC_QA_OUT_FILE" ]; then
        log ERROR "采集流程结束但终包不存在或为空: $BIC_QA_OUT_FILE"
        exit 1
    fi
    
    log INFO "程序执行完成"
}

# 运行主程序
main "$@"

