# dm_db_collector.sh 使用手册

## 1. 工具说明
`dm_db_collector.sh` 是达梦数据库健康检查采集工具。  
工具会采集数据库与操作系统关键指标，最终生成一个 SECTION 格式的单文件文本，便于上传分析。

## 2. 运行环境
- Linux 主机（建议数据库所在主机或可访问数据库的采集机）
- 需要命令：`disql`、`awk`、`sed`、`ssh/sshpass`（远程 OS 采集时）
- 脚本：`dm_db_collector.sh`

## 3. 基本用法
```bash
./dm_db_collector.sh [选项]
```

### 3.1 远程采集示例
```bash
./dm_db_collector.sh \
  -H 192.168.1.100 -P 5236 -u SYSDBA -p 'YourPassword' \
  --os-host 192.168.1.100 --os-username dmdba --os-password 'OsPass' \
  -o /tmp/dm_report.txt
```

### 3.2 本地采集示例
```bash
./dm_db_collector.sh -u SYSDBA -p 'YourPassword' --local -o /tmp/dm_report.txt
```

### 3.3 启用 SQLTEXT 截断 + 文件名追加时间戳
```bash
./dm_db_collector.sh \
  -u SYSDBA -p 'YourPassword' --local \
  --sqllen 2000 --filenamefix \
  -o /tmp/dm_report.txt
```

输出文件示例：
`/tmp/dm_report_2026-04-26-12-39-10.txt`

## 4. 主要参数
- `-H, --db-host`：数据库主机
- `-P, --db-port`：数据库端口（默认 5236）
- `-u, --db-username`：数据库用户名（默认 SYSDBA）
- `-p, --db-password`：数据库密码
- `--local`：本地采集模式（不走 SSH）
- `-o, --output`：输出文件路径
- `--filenamefix`：输出文件名后追加启动时间戳
- `--sqllen N`：`topsql::sqltext` 中 SQL 文本截断长度；`0` 表示不截断
- `--db-collect-interval SEC`：数据库快照间隔（影响 SYSSTAT）
- `--os-collect-interval SEC`：OS 多次采集间隔
- `--os-collect-count N`：OS 多次采集次数
- `--sql-timeout SEC`：SQL 超时秒数
- `--tool-code CODE`：元数据 tool_code
- `--debug`：调试模式，保留临时目录
- `-f`：强制模式（允许覆盖输出文件，并跳过部分主机日志检查）
- `-h, --help`：查看帮助

## 5. 输出结构
当前输出 section 顺序：
1. `metadata`
2. `instance_info`
3. `db_param`
4. `archive`
5. `performance`
6. `storage_stats`
7. `topsql`
8. `lock_info`
9. `memory`
10. `session`
11. `security`
12. `instance_log`
13. `backup`
14. `os`
15. `os_time_series`（可选）

## 6. 重点采集说明

### 6.1 TopSQL
包含：
- `topsql::sql_by_exec_time`
- `topsql::long_exec_sql`
- `topsql::sql_by_mem`
- `topsql::sqltext`

`sqltext` 会根据前 3 类 SQL_ID 汇总查询 `V$SQLTEXT`。  
如设置 `--sqllen`，会对 `SQL_TEXT` 做长度截断。

### 6.2 Backup
包含：
- `Backup Path`
- `backup_jobs`

若最近两天没有备份记录，`backup_jobs` 小节输出：
`未发现最近2天里执行过备份操作，请关注备份任务是否正常启动`

### 6.3 Session
包含：
- `session::session_info`
- `session::session_phy_read`
- `session::session_logic`
- `session::session_parse`

## 7. 常见问题

### Q1：`topsql::sqltext` 为空怎么办？
- 先确认前置子项是否有 SQL_ID（`sql_by_exec_time/long_exec_sql/sql_by_mem`）
- 再确认目标实例中 `V$SQLTEXT` 是否可见对应 SQL_ID
- 可加 `--debug` 检查中间文件

### Q2：中文显示乱码怎么办？
- 已在脚本中尽量统一 UTF-8 环境并对已知乱码表头做标准化
- 建议终端与查看工具统一 UTF-8 编码

### Q3：输出文件已存在怎么办？
- 默认会报错退出
- 如需覆盖，请加 `-f`

## 8. 建议操作流程
1. 先本地试跑一次（小范围验证）
2. 检查关键 section（`topsql`、`backup`、`session`）是否有数据
3. 再进行正式采集并上传结果
4. 升级脚本后同步查看需求文档，确认 section 变更

## 9. 附录：章节与子章节清单

### 9.1 `metadata`
- **子章节**：无
- **数据内容**：采集元信息（`db_type`、`tool_code`、开始/结束时间、连接信息、debug 标志等）

### 9.2 `instance_info`
- **子章节**：无
- **数据内容**：实例基本信息（实例名、实例号、主机、版本、启动时间、状态、角色等）

### 9.3 `db_param`
- **子章节**：无
- **数据内容**：数据库参数（`V$PARAMETER`）

### 9.4 `archive`
- **子章节**：无
- **数据内容**：归档/系统路径参数（`V$DM_INI` 中 `SYSTEM_PATH`）

### 9.5 `performance`
- **子章节**：
  - `SYSSTAT`
  - `WAIT_EVENT`
  - `TIME_MODEL`
- **数据内容**：
  - `SYSSTAT`：5 次快照增量的每秒平均值（过滤 `time(ms)` 指标）
  - `WAIT_EVENT`：两次快照增量（等待次数、等待时长、每秒等待时长、平均等待时长）
  - `TIME_MODEL`：`time(ms)` 相关指标两次快照增量

### 9.6 `storage_stats`
- **子章节**：
  - `Tablespace`
  - `Datafiles`
  - `ASM Disk Group`
  - `REDO`
  - `Rollback/Transaction`
- **数据内容**：表空间容量/使用率、数据文件信息、ASM 组空间、redo 信息、事务回滚信息

### 9.7 `topsql`
- **子章节**：
  - `topsql::sql_by_exec_time`
  - `topsql::long_exec_sql`
  - `topsql::sql_by_mem`
  - `topsql::sqltext`
- **数据内容**：
  - 执行耗时 Top SQL
  - 长执行 SQL 统计
  - 内存占用 Top SQL
  - SQL_ID 对应 SQL 文本（受 `--sqllen` 控制是否截断）

### 9.8 `lock_info`
- **子章节**：
  - `Deadlock`
  - `Blocking`
  - `Uncommitted SQL`
  - `Uncommitted Objects`
- **数据内容**：死锁历史与详情、阻塞链路、未提交事务 SQL、未提交对象

### 9.9 `memory`
- **子章节**：
  - `V$DB_CACHE`
  - `V$BUFFERPOOL`
  - `V$MEM_POOL`
  - `Total Memory`
  - `Bufferpool`
  - `SCP_CACHE`
  - `CACHEITEM`
  - `Buffer Hit Rate`
- **数据内容**：缓存、缓冲池、内存池、总内存、缓存池统计、SQL 缓存、命中率

### 9.10 `session`
- **子章节**：
  - `session::session_info`
  - `session::session_phy_read`
  - `session::session_logic`
  - `session::session_parse`
- **数据内容**：会话分布、会话物理读、逻辑读、解析开销与相关 SQL 计数统计

### 9.11 `security`
- **子章节**：
  - `Security-Users`
  - `Security-Policy`
- **数据内容**：用户信息、密码策略参数

### 9.12 `instance_log`
- **子章节**：
  - `Instance Logs`
- **数据内容**：实例日志关键内容（近时段异常优先、去重截断）

### 9.13 `backup`
- **子章节**：
  - `Backup Path`
  - `backup_jobs`
- **数据内容**：
  - 备份路径与目录可访问性/大小
  - 最近 2 天备份任务历史（路径、开始/结束时间、状态、类型、错误信息）
  - 若无数据，输出固定提示语

### 9.14 `os`
- **子章节**：
  - `os_info_summary`
  - `os_cpu`
  - `os_memory`
  - `os_runqueue`
  - `os_swap`
  - `os_io_stats`
  - `os_io_latency`
  - `os_disk`
  - `os_parameters`
  - `os_process_stats`
  - `os_system_log`
  - `dmesg + last1h + messages health alerts`
- **数据内容**：操作系统摘要、CPU/内存/队列/Swap/IO/磁盘/参数/进程/系统日志与主机告警

### 9.15 `os_time_series`（可选）
- **子章节**：无
- **数据内容**：启用 OS 多次采集参数时输出时序数据；未启用则输出说明文字
