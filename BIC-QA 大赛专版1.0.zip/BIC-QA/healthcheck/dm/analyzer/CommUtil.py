"""
BIC-QA 统一工具模块
整合所有接口：大模型对话、知识图谱查询、HTML 报告生成
配置通过 bic-qa.conf 文件统一管理
"""

import os
import json
import logging
from typing import Optional, Generator, Any
from http.client import HTTPConnection, HTTPSConnection, HTTPResponse
from http.client import HTTPException
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from socket import timeout as SocketTimeout

# ----------------------------------------------------------------
# 配置加载
# ----------------------------------------------------------------
_DEFAULT_CONF_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bic-qa.conf")

DEFAULT_BASE_URL = "https://api.bic-qa.com/ia_knowledgeGraph"
DEFAULT_X_API_KEY = ""
DEFAULT_TIMEOUT_SEC = 120


def _load_conf(path: str = _DEFAULT_CONF_PATH) -> dict:
    """读取 bic-qa.conf（INI 格式）"""
    conf: dict = {}
    if not os.path.exists(path):
        return conf
    try:
        import configparser
        cp = configparser.ConfigParser()
        cp.read(path, encoding="utf-8")
        if cp.has_section("default"):
            for k, v in cp.items("default"):
                conf[k.strip()] = v.strip()
    except Exception:
        pass
    return conf


_conf = _load_conf()
DEFAULT_BASE_URL = _conf.get("base_url", DEFAULT_BASE_URL).rstrip("/")
DEFAULT_X_API_KEY = _conf.get("api_key", DEFAULT_X_API_KEY)
try:
    DEFAULT_TIMEOUT_SEC = int(_conf.get("timeout_sec", str(DEFAULT_TIMEOUT_SEC)))
except ValueError:
    pass
DEFAULT_LLM_MODEL = _conf.get("llm_model", "qwen-plus")

# ----------------------------------------------------------------
# 日志
# ----------------------------------------------------------------
logger = logging.getLogger(__name__)

# ----------------------------------------------------------------
# 异常
# ----------------------------------------------------------------
class APIError(Exception):
    def __init__(self, status_code: int, message: str, detail: str = ""):
        self.status_code = status_code
        self.message = message
        self.detail = detail
        super().__init__(f"[{message}] {detail}".strip())


# ----------------------------------------------------------------
# 内部辅助
# ----------------------------------------------------------------
def _require_list(name: str, val: Any) -> list:
    if not val or not isinstance(val, (list, tuple)):
        raise ValueError(f"{name} 必须是非空列表")
    return list(val)


def _require_str(name: str, val: Any) -> str:
    if not val or not isinstance(val, str) or not val.strip():
        raise ValueError(f"{name} 必须是非空字符串")
    return val.strip()


# ----------------------------------------------------------------
# HTTP 客户端
# ----------------------------------------------------------------
class IAGraphHttpClient:
    """
    IA Graph HTTP 客户端。
    提供 parameters / metrics / wait_events / wait_events_info / chat 等接口。
    """

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        timeout_sec: int = DEFAULT_TIMEOUT_SEC,
        x_api_key: str = DEFAULT_X_API_KEY,
    ):
        self.base_url = _require_str("base_url", base_url)
        if timeout_sec is None or timeout_sec <= 0:
            raise ValueError("timeout_sec 必须是正整数")
        self.timeout_sec = int(timeout_sec)
        self.x_api_key = x_api_key or ""

    # --------------------------------------------------------
    # 内部请求方法
    # --------------------------------------------------------
    def _get_json(self, path: str, params: Optional[dict] = None) -> dict | list:
        url = self.base_url.rstrip("/") + path
        if params:
            from urllib.parse import urlencode
            query = urlencode(params, doseq=True)
            url += "?" + query
        headers: dict = {"Accept": "application/json"}
        if self.x_api_key:
            headers["X-API-KEY"] = self.x_api_key
        req = Request(url, headers=headers, method="GET")
        try:
            resp = urlopen(req, timeout=self.timeout_sec)
        except HTTPError as e:
            return self._handle_http_error(e, url)
        except SocketTimeout:
            raise APIError(
                status_code=0, message="请求超时",
                detail=f"请求超过 {self.timeout_sec} 秒未收到响应"
            ) from None
        except URLError as e:
            raise APIError(
                status_code=0, message="网络连接失败",
                detail=f"无法连接到 {url}: {e.reason}"
            ) from None
        with resp:
            raw = resp.read().decode("utf-8", errors="ignore")
            return json.loads(raw)

    def _post_json(self, path: str, body: dict) -> dict | list:
        url = self.base_url.rstrip("/") + path
        headers: dict = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.x_api_key:
            headers["X-API-KEY"] = self.x_api_key
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = Request(url, data=payload, headers=headers, method="POST")
        try:
            resp = urlopen(req, timeout=self.timeout_sec)
        except HTTPError as e:
            return self._handle_http_error(e, url)
        except SocketTimeout:
            raise APIError(
                status_code=0, message="请求超时",
                detail=f"请求超过 {self.timeout_sec} 秒未收到响应"
            ) from None
        except URLError as e:
            raise APIError(
                status_code=0, message="网络连接失败",
                detail=f"无法连接到 {url}: {e.reason}"
            ) from None
        with resp:
            raw = resp.read().decode("utf-8", errors="ignore")
            return json.loads(raw)

    def _post_stream(self, path: str, body: dict) -> Generator[str, None, None]:
        """发送 JSON POST 请求并以 SSE 流式方式逐 chunk 返回内容文本"""
        url = self.base_url.rstrip("/") + path
        headers: dict = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        if self.x_api_key:
            headers["X-API-KEY"] = self.x_api_key
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = Request(url, data=payload, headers=headers, method="POST")
        try:
            resp = urlopen(req, timeout=self.timeout_sec)
        except HTTPError as e:
            error_body = ""
            try:
                error_body = e.read().decode("utf-8", errors="ignore")
            except Exception:
                pass
            detail = ""
            if error_body:
                try:
                    error_obj = json.loads(error_body)
                    detail = error_obj.get("detail", error_body)
                except Exception:
                    detail = error_body
            logger.warning(f"HTTP {e.code} from {url}: {detail}")
            raise APIError(
                status_code=e.code,
                message=f"HTTP {e.code} 错误",
                detail=detail or self._http_error_meaning(e.code)
            ) from None
        except SocketTimeout:
            raise APIError(
                status_code=0,
                message="请求超时",
                detail=f"请求超过 {self.timeout_sec} 秒未收到响应，请检查网络或服务端状态"
            ) from None
        except URLError as e:
            raise APIError(
                status_code=0,
                message="网络连接失败",
                detail=f"无法连接到 {url}: {e.reason}"
            ) from None
        except Exception as e:
            raise APIError(
                status_code=0,
                message="请求失败",
                detail=f"{type(e).__name__}: {e}"
            ) from None
        with resp:
            buffer = ""
            while True:
                try:
                    chunk = resp.read(4096)
                except Exception as read_err:
                    err_msg = str(read_err)
                    if "IncompleteRead" in type(read_err).__name__ or "Connection" in err_msg or "reset" in err_msg.lower() or "timeout" in err_msg.lower():
                        logger.warning(f"[SSE] 流读取中断: {type(read_err).__name__}: {err_msg}")
                        if buffer.strip():
                            for line in buffer.split("\n"):
                                line = line.strip()
                                if line.startswith("data: "):
                                    data_str = line[6:]
                                    if data_str.strip() == "[DONE]":
                                        break
                                    try:
                                        data_obj = json.loads(data_str)
                                        choices = data_obj.get("choices", [])
                                        if choices:
                                            delta = choices[0].get("delta", {})
                                            content = delta.get("content", "")
                                            if content:
                                                yield content
                                    except json.JSONDecodeError:
                                        pass
                            logger.info(f"[SSE] 已处理缓冲区中剩余内容")
                        else:
                            logger.warning(f"[SSE] 流中断，未收到完整响应")
                        raise APIError(
                            status_code=0,
                            message="流响应中断",
                            detail=f"服务端连接中断（可能是代理超时），请检查网络或联系管理员。错误: {type(read_err).__name__}"
                        ) from read_err
                    else:
                        raise

                if not chunk:
                    break
                buffer += chunk.decode("utf-8", errors="ignore")
                while "\n\n" in buffer:
                    event, buffer = buffer.split("\n\n", 1)
                    for line in event.split("\n"):
                        if line.startswith("data: "):
                            data_str = line[6:]
                            if data_str.strip() == "[DONE]":
                                return
                            try:
                                data_obj = json.loads(data_str)
                                choices = data_obj.get("choices", [])
                                if choices:
                                    delta = choices[0].get("delta", {})
                                    content = delta.get("content", "")
                                    if content:
                                        yield content
                            except json.JSONDecodeError:
                                pass

    @staticmethod
    def _http_error_meaning(code: int) -> str:
        return {
            400: "请求参数错误",
            401: "认证失败，请检查 API Key",
            403: "权限不足",
            404: "接口不存在",
            429: "请求过于频繁，请稍后重试",
            500: "服务端内部错误",
            502: "大模型服务异常",
            503: "服务暂时不可用",
        }.get(code, f"HTTP {code} 错误")

    @staticmethod
    def _handle_http_error(e: HTTPError, url: str) -> dict:
        error_body = ""
        try:
            error_body = e.read().decode("utf-8", errors="ignore")
        except Exception:
            pass
        detail = ""
        if error_body:
            try:
                error_obj = json.loads(error_body)
                detail = error_obj.get("detail", error_body)
            except Exception:
                detail = error_body
        logger.warning(f"HTTP {e.code} from {url}: {detail}")
        raise APIError(
            status_code=e.code,
            message=f"HTTP {e.code} 错误",
            detail=detail or IAGraphHttpClient._http_error_meaning(e.code)
        ) from None

    # --------------------------------------------------------
    # 公开接口
    # --------------------------------------------------------
    def parameters(self, *, names: list[str], db_type: str = "2104") -> str:
        names = _require_list("names", names)
        resp = self._get_json("/api/parameters", {"names": names, "db_type": db_type})
        if isinstance(resp, dict) and isinstance(resp.get("md_table"), str):
            return resp["md_table"]
        raise APIError(
            status_code=0, message="服务端返回格式异常",
            detail="缺少 md_table 字段，响应: " + json.dumps(resp, ensure_ascii=False)[:200]
        )

    def metrics(self, *, index_ids: list[str], db_type: str = "2104") -> str:
        index_ids = _require_list("index_ids", index_ids)
        resp = self._get_json("/api/metrics", {"index_ids": index_ids, "db_type": db_type})
        if isinstance(resp, dict) and isinstance(resp.get("md_table"), str):
            return resp["md_table"]
        raise APIError(
            status_code=0, message="服务端返回格式异常",
            detail="缺少 md_table 字段，响应: " + json.dumps(resp, ensure_ascii=False)[:200]
        )

    def wait_events(self, *, names: list[str], db_type: str = "2104") -> str:
        names = _require_list("names", names)
        resp = self._get_json("/api/wait-events", {"names": names, "db_type": db_type})
        if isinstance(resp, dict) and isinstance(resp.get("md_table"), str):
            return resp["md_table"]
        raise APIError(
            status_code=0, message="服务端返回格式异常",
            detail="缺少 md_table 字段，响应: " + json.dumps(resp, ensure_ascii=False)[:200]
        )

    def wait_events_info(self, *, names: list[str], db_type: str = "2104") -> str:
        names = _require_list("names", names)
        resp = self._get_json("/api/wait-events-info", {"names": names, "db_type": db_type})
        if isinstance(resp, dict) and isinstance(resp.get("md_table"), str):
            return resp["md_table"]
        raise APIError(
            status_code=0, message="服务端返回格式异常",
            detail="缺少 md_table 字段，响应: " + json.dumps(resp, ensure_ascii=False)[:200]
        )

    def chat(
        self,
        message: str,
        model: str = DEFAULT_LLM_MODEL,
        temperature: float = 0.8,
        stream: bool = True,
        system_prompt: Optional[str] = None,
        max_tokens: Optional[int] = None,
    ) -> str | Generator[str, None, None]:
        """
        调用大模型 RESTful 接口，返回模型生成的文本。

        Args:
            message: 发给大模型的用户消息（字符串）。
            model: 模型名称，默认从配置文件读取。
            temperature: 采样温度，默认 0.8。
            stream: 是否流式输出。默认 True（底层始终走流式，避免代理超时）。
                    stream=False 时自动拼接成完整文本返回。
            system_prompt: 可选的系统提示词（role=system）。
            max_tokens: 最大输出 token 数，默认不限。

        Returns:
            stream=False: 返回完整文本（str）。
            stream=True:  返回生成器，逐片段 yield 文本。
        """
        if not message or not isinstance(message, str):
            raise ValueError("message 必须是非空字符串")

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": message})

        body: dict = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": True,  # 底层始终走流式，避免代理超时
        }
        if max_tokens is not None:
            body["max_tokens"] = max_tokens

        if stream:
            return self._post_stream("/api/v1/chat/completions", body)
        else:
            full_text: list[str] = []
            for chunk in self._post_stream("/api/v1/chat/completions", body):
                full_text.append(chunk)
            return "".join(full_text)


# ----------------------------------------------------------------
# 便捷函数（模块级别）
# ----------------------------------------------------------------
def _get_client(
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
    timeout_sec: Optional[int] = None
) -> IAGraphHttpClient:
    return IAGraphHttpClient(
        base_url=base_url or DEFAULT_BASE_URL,
        timeout_sec=timeout_sec or DEFAULT_TIMEOUT_SEC,
        x_api_key=api_key or DEFAULT_X_API_KEY
    )


def get_parameters(
    names: list[str],
    db_type: str = "2104",
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
    timeout_sec: Optional[int] = None
) -> str:
    """查询数据库参数信息"""
    if not names:
        raise ValueError("names 不能为空")
    cli = _get_client(base_url=base_url, api_key=api_key, timeout_sec=timeout_sec)
    return cli.parameters(names=names, db_type=db_type)


def get_metrics(
    index_ids: list[str],
    db_type: str = "2104",
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
    timeout_sec: Optional[int] = None
) -> str:
    """查询数据库指标信息"""
    if not index_ids:
        raise ValueError("index_ids 不能为空")
    cli = _get_client(base_url=base_url, api_key=api_key, timeout_sec=timeout_sec)
    return cli.metrics(index_ids=index_ids, db_type=db_type)


def get_wait_events(
    names: list[str],
    db_type: str = "2104",
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
    timeout_sec: Optional[int] = None
) -> str:
    """查询数据库等待事件信息"""
    if not names:
        raise ValueError("names 不能为空")
    cli = _get_client(base_url=base_url, api_key=api_key, timeout_sec=timeout_sec)
    return cli.wait_events(names=names, db_type=db_type)


def get_wait_events_info(
    wait_event_names: list[str],
    db_type: str = "2104",
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
    timeout_sec: Optional[int] = None
) -> str:
    """批量查询等待事件详细信息（包含名称、类别、描述）"""
    if not wait_event_names:
        raise ValueError("wait_event_names 不能为空")
    cli = _get_client(base_url=base_url, api_key=api_key, timeout_sec=timeout_sec)
    return cli.wait_events_info(names=wait_event_names, db_type=db_type)


def chat(
    message: str,
    model: str = DEFAULT_LLM_MODEL,
    temperature: float = 0.8,
    stream: bool = True,
    system_prompt: Optional[str] = None,
    max_tokens: Optional[int] = None,
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
    timeout_sec: int = DEFAULT_TIMEOUT_SEC,
) -> str | Generator[str, None, None]:
    """
    便捷函数：一行代码调用大模型 RESTful 接口。

    Args:
        message: 发给大模型的用户消息（字符串）。
        model: 模型名称，默认从配置文件读取。
        temperature: 采样温度，默认 0.8。
        stream: 是否流式输出。默认 True（底层走流式，避免代理超时）。
        system_prompt: 可选的系统提示词。
        max_tokens: 最大输出 token 数。
        base_url: 服务地址，不传则从配置文件读取。
        api_key: API Key，不传则从配置文件读取。
        timeout_sec: 超时秒数，默认 120。

    Returns:
        stream=False: 返回完整文本（str）。
        stream=True:  返回生成器，逐片段 yield 文本。
        发生错误时: 抛出 APIError。

    Example:
        # 非流式调用
        from CommUtil import chat
        text = chat("请分析数据库性能问题", stream=False)

        # 流式调用
        for chunk in chat("请分析...", stream=True):
            print(chunk, end="", flush=True)
    """
    client = _get_client(
        base_url=base_url,
        api_key=api_key,
        timeout_sec=timeout_sec,
    )
    return client.chat(
        message=message,
        model=model,
        temperature=temperature,
        stream=stream,
        system_prompt=system_prompt,
        max_tokens=max_tokens,
    )


# ----------------------------------------------------------------
# 从环境变量创建客户端（兼容旧接口）
# ----------------------------------------------------------------
def make_http_client_from_env(
    ia_key: Optional[str] = None,
    **kwargs
) -> IAGraphHttpClient:
    """
    从环境变量创建 IAGraphHttpClient 实例。

    环境变量:
        IA_GRAPH_BASE_URL: 服务地址。
        IA_GRAPH_TIMEOUT_SEC: 超时秒数。
        IA_KEY: API Key。
    """
    return IAGraphHttpClient(
        base_url=os.getenv("IA_GRAPH_BASE_URL", DEFAULT_BASE_URL),
        timeout_sec=int(os.getenv("IA_GRAPH_TIMEOUT_SEC", str(DEFAULT_TIMEOUT_SEC))),
        x_api_key=ia_key or os.getenv("IA_KEY", DEFAULT_X_API_KEY),
        **kwargs
    )
