import html as html_module
import re

def _extract_problem_list(md_text: str):
    """
    从Markdown文本中提取问题清单表格作为概要，剩余部分作为详细报告
    
    Args:
        md_text: 完整的Markdown文本
    
    Returns:
        tuple: (summary_md, detail_md) 如果找到问题清单，返回(问题清单部分, 完整报告)；
               否则返回(None, md_text)
    """
    if not md_text or not md_text.strip():
        return None, md_text
    
    # 匹配多种可能的问题清单标题格式（支持中英文，包括加粗标记）
    # 注意：支持任意章节号，如 "## **第二节 问题发现清单**"、"## 第三节 问题发现清单"、"## 第五节 问题发现清单" 等
    # 编号小节标题，如 "### 2. 问题发现清单"、"## 1、问题发现清单"
    _num_prefix = r'(?:\d+[.、．）)]\s*)'
    problem_list_patterns = [
        r'##+\s*\*{0,2}\s*' + _num_prefix + r'?问题发现清单\*{0,2}',
        r'##+\s*\*{0,2}\s*' + _num_prefix + r'?发现清单\*{0,2}',
        r'##+\s*' + _num_prefix + r'?问题发现清单',
        r'##+\s*' + _num_prefix + r'?发现清单',
        r'##+\s*\*{0,2}\s*第[一二三四五六七八九十\d]+.*?节\s+问题发现清单\*{0,2}',  # 匹配任意章节号 + "问题发现清单"
        r'##+\s*\*{0,2}\s*第[一二三四五六七八九十\d]+.*?节\s+发现清单\*{0,2}',      # 匹配任意章节号 + "发现清单"
        r'##+\s*\*{0,2}\s*问题发现清单\*{0,2}',                 # 匹配 "## **问题发现清单**"（无章节号）
        r'##+\s*\*{0,2}\s*发现清单\*{0,2}',                     # 匹配 "## **发现清单**"（无章节号）
        r'##+\s*第[一二三四五六七八九十\d]+.*?节.*?问题发现清单',                  # 匹配无加粗格式（任意章节号）
        r'##+\s*第[一二三四五六七八九十\d]+.*?节.*?发现清单',                      # 匹配无加粗格式（任意章节号）
        r'##+\s*问题发现清单',                                  # 匹配简单格式
        r'##+\s*发现清单',                                      # 匹配简单格式
        r'##+\s*Section\s*\d+.*?Problem\s*Discovery\s*List',   # 英文格式（任意Section号）
        r'##+\s*Problem\s*Discovery\s*List',                   # 英文格式
    ]
    
    problem_list_start = None
    problem_list_end = None
    
    for pattern in problem_list_patterns:
        match = re.search(pattern, md_text, re.IGNORECASE | re.MULTILINE)
        if match:
            problem_list_start = match.start()
            # 调试：输出匹配到的标题
            matched_title = md_text[problem_list_start:problem_list_start+100].split('\n')[0]
            print(f"找到问题清单标题: {matched_title}")
            break
    
    if problem_list_start is not None:
        # 找到问题清单开始位置，查找表格结束位置
        # 先尝试提取当前章节号，然后查找下一个章节（比当前章节号更大的章节）
        # 提取匹配到的标题，尝试识别章节号
        matched_title_line = md_text[problem_list_start:problem_list_start+200].split('\n')[0]
        
        # 尝试提取章节号（支持中文数字和阿拉伯数字）
        section_number = None
        # 先尝试匹配中文数字
        chinese_number_map = {
            '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
            '六': 6, '七': 7, '八': 8, '九': 9, '十': 10
        }
        section_match = re.search(r'第([一二三四五六七八九十])', matched_title_line)
        if section_match:
            section_char = section_match.group(1)
            section_number = chinese_number_map.get(section_char)
        else:
            # 尝试匹配阿拉伯数字
            section_match = re.search(r'第(\d+)', matched_title_line)
            if section_match:
                section_number = int(section_match.group(1))
        
        # 查找下一个主要章节作为问题清单的结束（支持加粗标记）
        # 使用通用的匹配模式，匹配任意章节号，然后验证章节号是否大于当前章节号
        # 这样可以支持任意章节号（第二节、第三节、第五节等）
        next_section_patterns = [
            r'\n##+\s*\*{0,2}\s*第([一二三四五六七八九十\d]+).*?节\*{0,2}',  # 匹配任意章节号（带捕获组）
            r'\n##+\s*第([一二三四五六七八九十\d]+).*?节',  # 匹配无加粗格式（带捕获组）
        ]
        
        next_section_match = None
        remaining_after_heading = md_text[problem_list_start:]

        # 如果识别到了当前章节号，需要验证匹配到的章节号是否大于当前章节号
        if section_number is not None and section_number >= 1:
            for pattern in next_section_patterns:
                matches = list(re.finditer(pattern, remaining_after_heading, re.IGNORECASE | re.MULTILINE))
                for match in matches:
                    section_str = match.group(1)
                    matched_section_number = None
                    chinese_number_map = {
                        '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
                        '六': 6, '七': 7, '八': 8, '九': 9, '十': 10
                    }
                    if section_str in chinese_number_map:
                        matched_section_number = chinese_number_map[section_str]
                    elif section_str.isdigit():
                        matched_section_number = int(section_str)

                    if matched_section_number is not None and matched_section_number > section_number:
                        next_section_match = match
                        break

                if next_section_match:
                    break
        else:
            # 未识别「第X节」：优先匹配下一个「编号小节」如 ### 3. 标题
            numbered_heading = re.search(
                r'\n##+\s*\d+[.、．）)]\s*\S',
                remaining_after_heading,
                re.MULTILINE,
            )
            chinese_section = None
            for pattern in next_section_patterns:
                simple_pattern = pattern.replace(r'([一二三四五六七八九十\d]+)', r'[一二三四五六七八九十\d]+')
                chinese_section = re.search(simple_pattern, remaining_after_heading, re.IGNORECASE | re.MULTILINE)
                if chinese_section:
                    break
            candidates = [m for m in (numbered_heading, chinese_section) if m]
            if candidates:
                next_section_match = min(candidates, key=lambda m: m.start())
        
        if next_section_match:
            # 找到下一个章节，问题清单到此结束
            problem_list_end = problem_list_start + next_section_match.start()
        else:
            # 如果没有找到下一个章节，查找表格结束位置
            remaining_text = md_text[problem_list_start:]
            # 查找表格后的分隔线（---）或空行，然后查找下一个章节标题
            # 先查找分隔线后的下一个章节
            separator_pattern = r'\n---+\s*\n'
            separator_match = re.search(separator_pattern, remaining_text, re.MULTILINE)
            if separator_match:
                # 问题清单到分隔线之前结束（不包括分隔线）
                problem_list_end = problem_list_start + separator_match.start()
            else:
                # 没有找到分隔线，查找表格后的空行
                table_end_match = re.search(r'\n\s*\n(?!\|)', remaining_text, re.MULTILINE)
                if table_end_match:
                    # 找到空行，检查空行后是否有新的章节标题
                    after_blank = remaining_text[table_end_match.end():]
                    # 查找任意章节作为结束
                    next_heading_patterns = [
                        r'\n##+\s*\*{0,2}\s*第[一二三四五六七八九十\d]+.*?节\*{0,2}',
                        r'\n##+\s*第[一二三四五六七八九十\d]+.*?节',
                        r'\n##+\s*\*{0,2}\s*[一二三四五六七八九十\d]+.*?\*{0,2}',
                        r'\n##+\s*[一二三四五六七八九十\d]+',
                    ]
                    found_next = False
                    for pattern in next_heading_patterns:
                        next_heading = re.search(pattern, after_blank, re.IGNORECASE | re.MULTILINE)
                        if next_heading:
                            problem_list_end = problem_list_start + table_end_match.end() + next_heading.start()
                            found_next = True
                            break
                    if not found_next:
                        # 空行后没有新章节，问题清单到空行结束
                        problem_list_end = problem_list_start + table_end_match.end()
                else:
                    # 如果都没找到，问题清单到报告末尾
                    problem_list_end = len(md_text)
        
        # 提取概要部分：只保留问题清单表格
        # 问题清单部分（包含标题和表格）
        problem_list_section = md_text[problem_list_start:problem_list_end].strip()
        # 移除标题中的"第X节"前缀，保持干净的标题显示
        problem_list_section = re.sub(
            r'(##+\s*\*{0,2}\s*)第[一二三四五六七八九十\d]+[^节章]*节?\s*',
            r'\1',
            problem_list_section,
            count=1,
            flags=re.IGNORECASE
        )
        # 概要 = 问题清单（不再包含执行摘要，避免概要标签页内容过多）
        summary_md = problem_list_section
        
        # 调试：输出提取的内容长度
        print(f"问题清单部分长度: {len(problem_list_section)}, 概要总长度: {len(summary_md)}")
        print(f"问题清单内容预览（前200字符）: {problem_list_section[:200]}...")
        
        # 详细报告：完整的报告内容（包括所有章节）
        detail_md = md_text
        return summary_md, detail_md
    else:
        # 如果没有找到问题清单，将整个报告作为详细报告
        print("未找到问题发现清单，使用传统模式（单页面报告）")
        return None, md_text


def render_markdown_to_html(md_text: str = '', enable_code_highlight: bool = True, include_styles: bool = True, show_footer: bool = True, show_toc: bool = True, show_cover: bool = True, lang: str = 'zh', cover_title: str = None, tool_name: str = None, summary_md: str = None, detail_md: str = None) -> str:
    """
    将 Markdown 文本渲染为 HTML，支持多种降级策略
    
    Args:
        md_text: Markdown 格式的文本（如果提供了summary_md和detail_md，此参数将被忽略；否则会自动检测并解析问题清单）
        enable_code_highlight: 是否启用代码高亮（需要 pygments 库）
        include_styles: 是否包含完整的 HTML 文档结构和样式
        show_footer: 是否显示页脚（包含生成时间和版权信息）
        show_toc: 是否显示目录导航栏
        show_cover: 是否显示封面页
        lang: 语言设置，'zh' 表示中文（默认），'en' 表示英文
        cover_title: 报告封面标题名称（如果为None，将根据语言自动设置）
        tool_name: 工具名称（如果为None，将根据语言自动设置）
        summary_md: 报告概要部分的Markdown文本（可选，如果提供则与detail_md一起显示为标签页；如果不提供且md_text中包含问题清单，会自动解析）
        detail_md: 报告详细部分的Markdown文本（可选，如果提供则与summary_md一起显示为标签页；如果不提供且md_text中包含问题清单，会自动解析）
    
    Returns:
        str: 渲染后的 HTML 字符串
    
    特性：
    - 优先使用 python-markdown（功能最全）
    - 降级到 mistune（性能更好）
    - 降级到 markdown2（兼容性好）
    - 最后使用内置基础渲染（确保可用性）
    - 支持表格、代码块、链接、列表、标题等常见语法
    - 支持概要和详细报告的标签页切换
    - 自动检测并解析报告中的问题清单，生成标签页模式
    """
    # 用于解析「问题发现清单」的正文：优先 md_text，否则可用 detail_md（避免只传 detail 时跳过解析）
    body_for_parse = (md_text or '').strip()
    if not body_for_parse and detail_md:
        body_for_parse = (detail_md or '').strip()

    # 如果提供了 summary_md 与 detail_md，视为标签页模式；概要为空时仍从正文尝试解析清单
    has_tabs = summary_md is not None and detail_md is not None

    if has_tabs and detail_md and detail_md.strip() and not (summary_md or '').strip():
        parsed_summary, parsed_detail = _extract_problem_list(detail_md)
        if parsed_summary:
            summary_md = parsed_summary
            if parsed_detail and parsed_detail.strip():
                detail_md = parsed_detail

    # 未显式指定双标签参数时，从正文自动解析问题清单
    if not has_tabs and body_for_parse:
        parsed_summary, parsed_detail = _extract_problem_list(body_for_parse)
        if parsed_summary is not None:
            summary_md = parsed_summary
            detail_md = parsed_detail
            has_tabs = True
    
    if has_tabs:
        # 使用概要和详细报告
        if not detail_md or not detail_md.strip():
            return ""
        # summary_md可以为空，但detail_md必须有内容
        summary_md = summary_md or ""
    else:
        # 使用原始md_text
        if not md_text or not md_text.strip():
            return ""
    
    # 定义内部函数来渲染单个markdown文本
    def _render_single_md(text: str) -> str:
        """渲染单个markdown文本为HTML"""
        if not text or not text.strip():
            return ""
        
        # 先反解 HTML 实体，避免报告中出现的 &lt;strong&gt; 等被当作文本展示
        try:
            text = html_module.unescape(text)
        except Exception:
            pass

        # 预处理：将独立一行的分割线（--- / *** / ___，至少 3 个同字符）转为 <hr>
        text = re.sub(
            r'^[ \t]*(-{3,}|\*{3,}|_{3,})[ \t]*$',
            '<hr class="markdown-hr"/>',
            text,
            flags=re.MULTILINE,
        )
        
        # 策略1: 使用 python-markdown（推荐，功能最全）
        try:
            import markdown
            # 检查是否是真正的 python-markdown 库（通过检查是否有 markdown 方法）
            if not hasattr(markdown, 'markdown'):
                raise AttributeError("module 'markdown' has no attribute 'markdown'")
            
            extensions = [
                'extra',           # 支持表格、缩写、属性列表等
                'fenced_code',     # 支持围栏代码块
                'tables',          # 表格支持
                'sane_lists',      # 更智能的列表处理
                'nl2br',           # 换行转 <br>
                'codehilite' if enable_code_highlight else None,  # 代码高亮（需要 pygments）
                'toc',             # 目录生成
            ]
            # 过滤 None 值
            extensions = [ext for ext in extensions if ext is not None]
            
            # 尝试导入 codehilite，如果失败则移除
            if 'codehilite' in extensions:
                try:
                    import pygments
                except ImportError:
                    extensions.remove('codehilite')
            
            # 构建扩展配置
            extension_configs = {}
            if 'codehilite' in extensions:
                extension_configs['codehilite'] = {
                    'css_class': 'highlight',
                    'use_pygments': True,
                    'noclasses': False,
                }
            if 'toc' in extensions:
                extension_configs['toc'] = {
                    'permalink': True,
                    'baselevel': 1,
                }
            
            html_output = markdown.markdown(
                text,
                extensions=extensions,
                extension_configs=extension_configs if extension_configs else None
            )
            return html_output
        except (ImportError, AttributeError, Exception) as e:
            # 静默失败，继续尝试下一个策略
            pass
        
        # 策略2: 使用 mistune（性能更好，但功能较少）
        try:
            import mistune
            # 创建 markdown 渲染器，启用常用插件
            plugins = ['strikethrough', 'table', 'url', 'task_lists', 'def_list']
            renderer = mistune.create_markdown(plugins=plugins)
            html_output = renderer(text)
            return html_output
        except (ImportError, AttributeError, Exception):
            # 静默失败，继续尝试下一个策略
            pass
        
        # 策略3: 使用 markdown2（兼容性好）
        try:
            import markdown2
            extras = [
                'tables',              # 表格支持
                'fenced-code-blocks',  # 围栏代码块
                'code-friendly',       # 代码友好模式
                'toc',                 # 目录
                'break-on-newline',    # 换行转 <br>
                'wiki-tables',         # Wiki 风格表格
            ]
            html_output = markdown2.markdown(text, extras=extras)
            return html_output
        except (ImportError, AttributeError, Exception):
            # 静默失败，继续尝试下一个策略
            pass
        
        # 策略4: 内置基础渲染（降级方案，确保可用性）
        return _basic_markdown_render(text)
    
    # 根据是否有标签页来决定渲染逻辑
    if has_tabs:
        # 渲染概要和详细报告
        summary_html = _render_single_md(summary_md)
        detail_html = _render_single_md(detail_md)
        
        # 如果需要样式，添加完整的 HTML 文档结构（包含标签页）
        if include_styles:
            return _wrap_with_styles(
                detail_html, 
                show_footer=show_footer, 
                show_toc=show_toc, 
                show_cover=show_cover, 
                lang=lang, 
                cover_title=cover_title, 
                tool_name=tool_name,
                summary_html=summary_html,
                detail_html=detail_html
            )
        # 如果不包含样式，直接返回详细报告（因为标签页需要样式支持）
        return detail_html
    else:
        # 使用原始逻辑，渲染单个markdown文本
        html_output = _render_single_md(md_text)
        
        # 如果需要样式，添加完整的 HTML 文档结构
        if include_styles:
            return _wrap_with_styles(html_output, show_footer=show_footer, show_toc=show_toc, show_cover=show_cover, lang=lang, cover_title=cover_title, tool_name=tool_name)
        return html_output


def _basic_markdown_render(md_text: str) -> str:
    """
    基础 Markdown 渲染器（降级方案）
    使用正则表达式实现基本的 Markdown 语法支持
    """
    text = md_text
    
    # 代码块 ```language\ncode\n```
    def code_block_repl(match):
        lang = match.group(1) or ''
        code = html_module.escape(match.group(2))
        lang_class = f' class="language-{lang}"' if lang else ''
        return f'<pre><code{lang_class}>{code}</code></pre>'
    text = re.sub(r'```(\w+)?\n([\s\S]*?)```', code_block_repl, text, flags=re.MULTILINE)
    
    # 行内代码 `code`
    text = re.sub(r'`([^`]+)`', lambda m: f'<code>{html_module.escape(m.group(1))}</code>', text)
    
    # 标题 H1-H6（从大到小处理，避免 H1 匹配 H2）
    for level in range(6, 0, -1):
        text = re.sub(
            rf'^{"#" * level}\s+(.+)$',
            rf'<h{level}>\1</h{level}>',
            text,
            flags=re.MULTILINE
        )
    
    # 粗体 **text** 或 __text__
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'__(.+?)__', r'<strong>\1</strong>', text)
    
    # 斜体 *text* 或 _text_
    # 注意：只匹配被空格或标点包围的斜体标记，避免匹配参数名中的下划线（如 session_cached_cursors）
    text = re.sub(r'(?<!\*)\*([^*]+?)\*(?!\*)', r'<em>\1</em>', text)
    # 改进：只匹配被单词边界或空格包围的 _text_，避免匹配单词中间的下划线
    # 使用 \b 或空格来确保下划线是真正的斜体标记，而不是标识符的一部分
    text = re.sub(r'(?<![a-zA-Z0-9_])_([^_\n]+?)_(?![a-zA-Z0-9_])', r'<em>\1</em>', text)
    
    # 链接 [text](url) 或 [text](url "title")
    def link_repl(match):
        text_content = match.group(1)
        url = match.group(2)
        title = match.group(3) if match.lastindex >= 3 and match.group(3) else ''
        title_attr = f' title="{html_module.escape(title)}"' if title else ''
        return f'<a href="{html_module.escape(url)}"{title_attr}>{text_content}</a>'
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)(?:\s+"([^"]+)")?\)', link_repl, text)
    
    # 图片 ![alt](url) 或 ![alt](url "title") - 必须在链接之前处理
    def image_repl(match):
        alt = match.group(1)
        url = match.group(2)
        title = match.group(3) if match.lastindex >= 3 and match.group(3) else ''
        title_attr = f' title="{html_module.escape(title)}"' if title else ''
        return f'<img src="{html_module.escape(url)}" alt="{html_module.escape(alt)}"{title_attr} />'
    # 先处理图片（必须在链接之前，因为图片语法包含链接语法）
    text = re.sub(r'!\[([^\]]*)\]\(([^)]+)(?:\s+"([^"]+)")?\)', image_repl, text)
    
    # 表格处理
    def parse_table_block(match):
        table_lines = match.group(0).strip().split('\n')
        if len(table_lines) < 2:
            return match.group(0)
        
        # 解析表头
        header_line = table_lines[0]
        headers = [h.strip() for h in header_line.strip().strip('|').split('|')]
        
        # 跳过分隔行（第二行）
        body_lines = []
        for line in table_lines[2:]:
            if not line.strip() or '|' not in line:
                break
            cells = [c.strip() for c in line.strip().strip('|').split('|')]
            # 确保单元格数量匹配
            while len(cells) < len(headers):
                cells.append('')
            cells = cells[:len(headers)]
            # 处理单元格内容，允许基础 HTML 标签
            cell_html = ''.join(f'<td>{_allow_basic_tags(c)}</td>' for c in cells)
            body_lines.append(f'<tr>{cell_html}</tr>')
        
        header_html = ''.join(f'<th>{_allow_basic_tags(h)}</th>' for h in headers)
        return f'<table class="markdown-table"><thead><tr>{header_html}</tr></thead><tbody>{"".join(body_lines)}</tbody></table>'
    
    # 匹配表格（至少3行：表头、分隔线、至少一行数据）
    text = re.sub(
        r'(?:^\|.+\|\s*\n\|[-:\s|]+\|\s*\n(?:\|.+\|\s*\n?)+)',
        parse_table_block,
        text,
        flags=re.MULTILINE
    )
    
    # 无序列表 - 或 *
    def unordered_list_repl(match):
        items = []
        for line in match.group(0).split('\n'):
            m = re.match(r'^\s*[-*]\s+(.+)$', line)
            if m:
                items.append(f'<li>{m.group(1)}</li>')
        return f'<ul>{"".join(items)}</ul>'
    text = re.sub(r'(?:^\s*[-*]\s+.+(?:\n|$))+', unordered_list_repl, text, flags=re.MULTILINE)
    
    # 有序列表 1. 或 1)
    def ordered_list_repl(match):
        items = []
        for line in match.group(0).split('\n'):
            m = re.match(r'^\s*\d+[.)]\s+(.+)$', line)
            if m:
                items.append(f'<li>{m.group(1)}</li>')
        return f'<ol>{"".join(items)}</ol>'
    text = re.sub(r'(?:^\s*\d+[.)]\s+.+(?:\n|$))+', ordered_list_repl, text, flags=re.MULTILINE)
    
    # 水平分割线（独立一行，同字符至少重复 3 次）
    text = re.sub(
        r'^[ \t]*(-{3,}|\*{3,}|_{3,})[ \t]*$',
        '<hr class="markdown-hr"/>',
        text,
        flags=re.MULTILINE,
    )
    
    # 换行处理：两个连续换行转为段落，单个换行转为 <br>
    paragraphs = []
    for para in text.split('\n\n'):
        para = para.strip()
        if para:
            # 如果已经是 HTML 标签，不处理
            if re.match(r'^<[^>]+>', para):
                paragraphs.append(para)
            else:
                # 单个换行转 <br>
                para = para.replace('\n', '<br/>')
                paragraphs.append(f'<p>{para}</p>')
    
    return '\n'.join(paragraphs)


def _generate_toc(html_body: str, lang: str = 'zh') -> str:
    """
    从HTML内容中提取标题，生成目录导航栏
    
    Args:
        html_body: HTML正文内容
        lang: 语言设置，'zh' 表示中文（默认），'en' 表示英文
    
    Returns:
        str: 目录导航栏的HTML代码
    """
    import re
    from html import escape
    
    # 语言文本映射
    text_map = {
        'zh': '目录',
        'en': 'Table of Contents'
    }
    
    # 默认使用中文
    if lang not in text_map:
        lang = 'zh'
    
    toc_title = text_map[lang]
    
    # 提取所有标题及其层级
    headings = []
    heading_pattern = re.compile(r'<h([1-6])[^>]*>(.*?)</h[1-6]>', re.IGNORECASE | re.DOTALL)
    
    for match in heading_pattern.finditer(html_body):
        level = int(match.group(1))
        text = re.sub(r'<[^>]+>', '', match.group(2)).strip()  # 移除HTML标签，只保留文本
        if text:
            # 生成锚点ID（基于标题文本）
            anchor_id = re.sub(r'[^\w\u4e00-\u9fa5]+', '-', text.lower())
            anchor_id = re.sub(r'-+', '-', anchor_id).strip('-')
            # 如果锚点ID为空，使用序号
            if not anchor_id:
                anchor_id = f'heading-{len(headings) + 1}'
            headings.append({
                'level': level,
                'text': text,
                'anchor': anchor_id
            })
    
    if not headings:
        return ""
    
    # 生成目录HTML
    toc_items = []
    for heading in headings:
        indent = (heading['level'] - 1) * 20  # 每级缩进20px
        toc_items.append(
            f'<li style="margin-left: {indent}px;">'
            f'<a href="#{heading["anchor"]}" class="toc-link">{escape(heading["text"])}</a>'
            f'</li>'
        )
    
    return f"""
    <button class="toc-toggle-btn" id="toc-toggle-btn" onclick="toggleToc()" title="隐藏/显示目录">☰</button>
    <div class="toc-container" id="toc-container">
        <div class="toc-title">{toc_title}</div>
        <ul class="toc-list">
            {''.join(toc_items)}
        </ul>
    </div>
    <div class="toc-resizer" id="toc-resizer"></div>"""


def _add_anchor_ids(html_body: str) -> str:
    """
    为HTML中的标题添加锚点ID
    
    Args:
        html_body: HTML正文内容
    
    Returns:
        str: 添加了锚点ID的HTML内容
    """
    import re
    
    def add_id(match):
        level = match.group(1)
        content = match.group(2)
        # 提取标题文本
        text = re.sub(r'<[^>]+>', '', content).strip()
        # 生成锚点ID
        anchor_id = re.sub(r'[^\w\u4e00-\u9fa5]+', '-', text.lower())
        anchor_id = re.sub(r'-+', '-', anchor_id).strip('-')
        # 如果锚点ID为空，使用序号
        if not anchor_id:
            anchor_id = f'heading-{len(re.findall(r"<h[1-6]", html_body[:match.start()])) + 1}'
        
        return f'<h{level} id="{anchor_id}">{content}</h{level}>'
    
    # 为所有标题添加ID
    html_with_anchors = re.sub(
        r'<h([1-6])[^>]*>(.*?)</h\1>',
        add_id,
        html_body,
        flags=re.IGNORECASE | re.DOTALL
    )
    
    return html_with_anchors


def _add_section_buttons(html_body: str, lang: str = 'zh') -> str:
    """
    在每个章节正文末尾添加返回按钮
    
    Args:
        html_body: HTML正文内容
        lang: 语言设置，'zh' 表示中文（默认），'en' 表示英文
    
    Returns:
        str: 添加了章节按钮的HTML内容
    """
    import re
    
    # 语言文本映射
    text_map = {
        'zh': {
            'back_to_top': '返回顶部',
            'back_to_parent': '返回父章节'
        },
        'en': {
            'back_to_top': 'Back to Top',
            'back_to_parent': 'Back to Parent'
        }
    }
    
    # 默认使用中文
    if lang not in text_map:
        lang = 'zh'
    
    texts = text_map[lang]
    
    # 查找所有标题及其位置（支持有id和没有id的情况）
    heading_pattern = re.compile(r'<h([1-6])[^>]*>(.*?)</h\1>', re.IGNORECASE | re.DOTALL)
    headings = []
    
    for match in heading_pattern.finditer(html_body):
        # 提取id（如果有）
        id_match = re.search(r'id="([^"]+)"', match.group(0))
        heading_id = id_match.group(1) if id_match else None
        
        headings.append({
            'level': int(match.group(1)),
            'id': heading_id,
            'start': match.start(),
            'end': match.end(),
            'full_match': match.group(0)
        })
    
    if not headings:
        return html_body
    
    # 从后往前处理，避免位置偏移问题
    result = list(html_body)  # 转换为列表以便插入
    insertions = []  # 记录所有需要插入的位置和内容
    inserted_positions = set()  # 记录已经插入按钮的位置，避免重复
    
    for i in range(len(headings) - 1, -1, -1):
        heading = headings[i]
        level = heading['level']
        
        # 确定章节结束位置（下一个同级或更高级标题之前）
        section_end = len(html_body)
        next_sibling_idx = None
        if i < len(headings) - 1:
            # 查找下一个同级或更高级标题
            for j in range(i + 1, len(headings)):
                next_heading = headings[j]
                if next_heading['level'] <= level:
                    section_end = next_heading['start']
                    next_sibling_idx = j
                    break
        
        # 检查是否有任何子章节（任何更低级别的标题）
        has_children = False
        if i < len(headings) - 1:
            next_heading = headings[i + 1]
            if next_heading['level'] > level:
                has_children = True
        
        # 如果这个章节的内容延伸到文档末尾附近，检查是否已经有其他章节在相同位置添加了按钮
        # 这通常发生在文档末尾，多个级别的章节都结束在页脚之前
        is_near_end = section_end >= len(html_body) - 500  # 在文档末尾500字符内
        
        # 获取章节内容
        section_start = heading['end']
        section_content = html_body[section_start:section_end]
        
        # 检查是否已经有按钮（避免重复添加）
        # 同时检查插入位置是否已经使用过
        if 'section-buttons' not in section_content:
            # 查找章节内容的真正末尾（跳过末尾空白）
            # 查找最后一个非空白字符的位置
            content_end = len(section_content)
            for pos in range(len(section_content) - 1, -1, -1):
                if not section_content[pos].isspace():
                    content_end = pos + 1
                    break
            
            # 查找最后一个闭合标签的位置，确保按钮插入在合适的位置
            # 尝试找到最后一个 </p>, </div>, </ul>, </ol>, </table> 等标签
            last_tag_match = None
            for tag in ['</p>', '</div>', '</ul>', '</ol>', '</table>', '</blockquote>', '</pre>', '</tbody>']:
                tag_pos = section_content.rfind(tag, 0, content_end)
                if tag_pos != -1:
                    if last_tag_match is None or tag_pos > last_tag_match[1]:
                        last_tag_match = (tag, tag_pos + len(tag))
            
            # 确定插入位置
            if last_tag_match:
                insert_pos = section_start + last_tag_match[1]
            else:
                # 如果没有找到闭合标签，插入在内容末尾
                insert_pos = section_start + content_end
            
            # 检查是否在页脚之前（如果找到了页脚）
            footer_pos = html_body.find('<div class="report-footer">', section_start)
            if footer_pos != -1 and insert_pos > footer_pos:
                # 如果插入位置在页脚之后，调整到页脚之前
                insert_pos = footer_pos
            
            # 避免在相同位置重复插入
            # 如果靠近文档末尾，检查附近是否已经有按钮
            should_insert = True
            if is_near_end:
                # 检查插入位置附近（前后200字符）是否已经有按钮
                check_start = max(0, insert_pos - 200)
                check_end = min(len(html_body), insert_pos + 200)
                nearby_content = html_body[check_start:check_end]
                if 'section-buttons' in nearby_content:
                    should_insert = False
            
            if should_insert and insert_pos not in inserted_positions:
                # 生成按钮HTML
                buttons_html = f'''
<div class="section-buttons">
    <button class="section-button" onclick="scrollToTop()">
        <i>↑</i> {texts['back_to_top']}
    </button>
    <button class="section-button" onclick="scrollToParent({level})">
        <i>↑</i> {texts['back_to_parent']}
    </button>
</div>'''
                
                insertions.append((insert_pos, buttons_html))
                inserted_positions.add(insert_pos)
    
    # 从后往前插入，避免位置偏移
    for pos, html in sorted(insertions, reverse=True):
        result.insert(pos, html)
    
    return ''.join(result)


def _image_to_base64_data_uri(image_path: str) -> str:
    """
    将图片文件转换为Base64编码的data URI，用于嵌入HTML
    
    Args:
        image_path: 图片文件路径（可以是相对路径或绝对路径）
    
    Returns:
        str: Base64编码的data URI字符串，格式为 "data:image/xxx;base64,xxx"
        如果文件不存在，返回空字符串
    """
    import os
    import base64
    
    # 尝试多个可能的路径
    possible_paths = [
        image_path,  # 原始路径
        os.path.join(os.getcwd(), image_path),  # 当前工作目录
        os.path.join(os.path.dirname(__file__), image_path),  # 脚本所在目录
        os.path.join(os.path.dirname(os.path.abspath(__file__)), image_path),  # 脚本绝对路径所在目录
    ]
    
    # 根据文件扩展名确定MIME类型
    mime_types = {
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.gif': 'image/gif',
        '.svg': 'image/svg+xml',
        '.webp': 'image/webp'
    }
    
    file_ext = os.path.splitext(image_path)[1].lower()
    mime_type = mime_types.get(file_ext, 'image/png')  # 默认使用PNG
    
    # 查找文件
    for path in possible_paths:
        if os.path.exists(path) and os.path.isfile(path):
            try:
                with open(path, 'rb') as f:
                    image_data = f.read()
                    base64_data = base64.b64encode(image_data).decode('utf-8')
                    return f"data:{mime_type};base64,{base64_data}"
            except Exception as e:
                # 如果读取失败，尝试下一个路径
                continue
    
    # 如果所有路径都找不到文件，返回空字符串（保持原路径）
    return ""


def _generate_cover_page(report_title: str = None, report_subtitle: str = None, lang: str = 'zh', tool_name: str = None) -> str:
    """
    生成报告封面页
    
    Args:
        report_title: 报告主标题（如果为None，将根据语言自动设置）
        report_subtitle: 报告副标题（如果为None，将根据语言自动设置）
        lang: 语言设置，'zh' 表示中文（默认），'en' 表示英文
        tool_name: 工具名称（如果为None，将根据语言自动设置）
    
    Returns:
        str: 封面页的HTML代码
    """
    from datetime import datetime
    
    # 语言文本映射
    text_map = {
        'zh': {
            'default_title': 'Oracle AWR 分析报告',
            'default_subtitle': 'AWR Report Analysis',
            'report_date': '报告日期：',
            'company': '佰晟智算(深圳)技术有限公司',
            'tool': 'BIC-QA 智能分析工具',
            'date_format': '%Y年%m月%d日',
            'hotline_label': '社区服务热线：',
            'hotline_number': '400 880 0486',
            'address_label': '地址：',
            'address': '深圳市龙华区人民路美丽AAA大厦7层704',
            'wechat_title': '扫码关注DBAIOps社区',
            'wechat_alt': 'DBAIOps社区微信公众号',
            'kes_community_qr_alt': '金仓社区二维码',
            'kes_community_scan_line': '扫码加入金仓社区，尽享多重权益！',
            'kes_footer_wechat_alt': '金仓社区微信公众号'
        },
        'en': {
            'default_title': 'Oracle AWR Analysis Report',
            'default_subtitle': 'AWR Report Analysis',
            'report_date': 'Report Date:',
            'company': 'Baisheng Intelligence (Shenzhen) Technology Co., Ltd.',
            'tool': 'BIC-QA Intelligent Analysis Tool',
            'date_format': '%B %d, %Y',
            'hotline_label': 'Community Service Hotline:',
            'hotline_number': '400 880 0486',
            'address_label': 'Address:',
            'address': 'Room 704, Beautiful AAA Building, Renmin Road, Longhua District, Shenzhen',
            'wechat_title': 'Scan QR Code to Follow DBAIOps Community',
            'wechat_alt': 'DBAIOps Community WeChat Official Account',
            'kes_community_qr_alt': 'Kingbase Community QR code',
            'kes_community_scan_line': 'Scan to join Kingbase Community and enjoy exclusive benefits!',
            'kes_footer_wechat_alt': 'Kingbase Community WeChat Official Account'
        }
    }
    
    # 默认使用中文
    if lang not in text_map:
        lang = 'zh'
    
    texts = text_map[lang]
    
    # 如果没有提供标题，使用默认值
    if report_title is None:
        report_title = texts['default_title']
    # if report_subtitle is None:
    #     report_subtitle = texts['default_subtitle']
    
    # 工具名称：None 用默认文案；显式传空字符串则不展示封面上的工具名行（避免脚本名如 gauss_wdr_analyze）
    if tool_name is None:
        tool_name = texts['tool']
    tool_name_stripped = (tool_name or "").strip()
    cover_tool_html = (
        f'<div class="cover-tool">{tool_name}</div>' if tool_name_stripped else ""
    )
    
    # 格式化日期和时间
    generation_date = datetime.now().strftime(texts['date_format'])
    
    # 将图片转换为Base64编码的data URI，实现离线HTML独立运行
    logo_data_uri = _image_to_base64_data_uri("bic-logo.png")
    wechat_data_uri = _image_to_base64_data_uri("dbaiops_chat.jpg")
    
    # 如果Base64转换失败，使用原始路径（向后兼容）
    logo_src = logo_data_uri if logo_data_uri else "bic-logo.png"
    wechat_src = wechat_data_uri if wechat_data_uri else "dbaiops_chat.jpg"
    
    # KWR / KES 标题报告，或金仓 SQL 优化类报告：顶部金仓社区 logo/链接；二维码与标语仅在页脚展示
    rt = report_title or ""
    is_kingbase_community_cover = bool(
        rt
        and (
            "KWR" in rt
            or "KES" in rt
            or ("金仓" in rt and "SQL优化" in rt)
        )
    )
    partner_logo_top_html = ""
    tech_support_below_title = ""
    kes_qr_data_uri = ""
    # 根据报告类型选择 logo：金仓社区类报告优先金仓社区 logo，否则 BIC
    if is_kingbase_community_cover:
        kingbase_logo_data_uri = _image_to_base64_data_uri("kingbase-community.png")
        kes_qr_data_uri = _image_to_base64_data_uri("kes_comunity.png")
        cover_logo_src = kingbase_logo_data_uri if kingbase_logo_data_uri else logo_data_uri
        cover_logo_alt = "金仓社区 Logo"
        top_inner_parts = []
        if kingbase_logo_data_uri:
            top_inner_parts.append(
                f"""<img src="{kingbase_logo_data_uri}" alt="金仓社区" style="max-width:260px;height:auto;margin-bottom:14px;filter: drop-shadow(0 6px 14px rgba(15, 23, 42, 0.08));" />"""
            )
            top_inner_parts.append(
                f"""<div style="color:#64748b;font-size:13px;line-height:1.65;font-weight:500;letter-spacing:0.02em;">
                    金仓社区 · <a href="https://bbs.kingbase.com.cn" target="_blank" rel="noopener noreferrer" style="color:#5b6ee8;text-decoration:none;font-weight:600;border-bottom:1px solid rgba(91,110,232,0.35);transition:color 0.2s ease,border-color 0.2s ease;" onmouseover="this.style.color='#4338ca';this.style.borderBottomColor='rgba(67,56,202,0.5)'" onmouseout="this.style.color='#5b6ee8';this.style.borderBottomColor='rgba(91,110,232,0.35)'">bbs.kingbase.com.cn</a>
                </div>"""
            )
        if top_inner_parts:
            partner_logo_top_html = f"""
            <div class="cover-partner-logo-top" style="text-align:center;margin-bottom:28px;padding:8px 20px 22px;border-bottom:1px solid rgba(102, 126, 234, 0.12);background:linear-gradient(180deg, rgba(248,250,252,0.9) 0%, rgba(255,255,255,0) 100%);border-radius:12px;">
                {''.join(top_inner_parts)}
            </div>"""
        # 添加佰晟智算技术支持文字（标题下方）
        tech_support_below_title = f"""
            <div class="cover-tech-support-below-title" style="text-align:center;margin-top:15px;margin-bottom:20px;color:#64748b;font-size:13px;font-weight:500;">
                由{texts['company']}提供技术支持
            </div>"""
    else:
        # 非KWR报告使用BIC logo
        cover_logo_src = logo_data_uri
        cover_logo_alt = "BIC Logo"
    
    # 页脚：金仓社区类报告不展示佰晟热线；底部仅一处展示社区二维码 +「扫码加入金仓社区…」标语
    if is_kingbase_community_cover:
        cover_contact_html = ""
        kes_qr_src = kes_qr_data_uri if kes_qr_data_uri else "kes_comunity.png"
        kes_scan = texts['kes_community_scan_line']
        kes_alt = texts['kes_footer_wechat_alt']
        cover_footer_wechat_html = f"""
                <div class="cover-kes-community-cta">
                    <div class="cover-kes-community-cta-inner">
                        <img src="{kes_qr_src}" alt="{kes_alt}" class="cover-kes-community-qr" />
                        <p class="cover-kes-community-slogan">{kes_scan}</p>
                    </div>
                </div>"""
    else:
        cover_contact_html = f"""
                <div class="cover-contact">
                    <div class="contact-hotline">{texts['hotline_label']}{texts['hotline_number']}</div>
                </div>"""
        footer_wechat_title = texts['wechat_title']
        footer_wechat_alt = texts['wechat_alt']
        footer_wechat_src = wechat_src
        cover_footer_wechat_html = f"""
                <div class="cover-wechat">
                    <div class="wechat-title">{footer_wechat_title}</div>
                    <img src="{footer_wechat_src}" alt="{footer_wechat_alt}" class="wechat-qrcode" />
                </div>"""
    
    # 顶部 partner区已含金仓 logo 时，不再输出中间 .cover-logo，避免重复
    if partner_logo_top_html:
        cover_logo_html = ""
    else:
        cover_logo_html = f"""
            <div class="cover-logo">
                <img src="{cover_logo_src}" alt="{cover_logo_alt}" class="logo-image" />
            </div>"""
    
    return f"""
    <div class="cover-page">
        <div class="cover-content">
            {partner_logo_top_html}
            {cover_logo_html}
            <h1 class="cover-title">{report_title}</h1>
            {tech_support_below_title}
            <div class="cover-divider"></div>
            <div class="cover-info">
                <div class="cover-info-item">
                    <span class="info-label">{texts['report_date']}</span>
                    <span class="info-value">{generation_date}</span>
                </div>
            </div>
            <div class="cover-footer">
                {cover_tool_html}
                {cover_contact_html}
                {cover_footer_wechat_html}
            </div>
        </div>
    </div>"""


def _wrap_with_styles(html_body: str, show_footer: bool = True, show_toc: bool = True, show_cover: bool = True, lang: str = 'zh', cover_title: str = None, tool_name: str = None, summary_html: str = None, detail_html: str = None) -> str:
    """
    将 HTML 内容包装成完整的 HTML 文档，添加美观的 CSS 样式
    
    Args:
        html_body: HTML 正文内容（如果提供了summary_html和detail_html，此参数将被忽略）
        show_footer: 是否显示页脚（包含生成时间和版权信息）
        show_toc: 是否显示目录导航栏
        show_cover: 是否显示封面页
        lang: 语言设置，'zh' 表示中文（默认），'en' 表示英文
        cover_title: 报告封面标题名称（如果为None，将根据语言自动设置）
        tool_name: 工具名称（如果为None，将根据语言自动设置）
        summary_html: 报告概要部分的HTML内容（可选，如果提供则与detail_html一起显示为标签页）
        detail_html: 报告详细部分的HTML内容（可选，如果提供则与summary_html一起显示为标签页）
    """
    # 判断是否有标签页
    has_tabs = summary_html is not None and detail_html is not None
    
    # 如果有标签页，使用detail_html作为默认显示内容；否则使用html_body
    if has_tabs:
        html_body = detail_html
    styles = """
<style>
    /* ===================================================
       设计令牌 - Design Tokens
       配色方案：深青蓝 × 暖琥珀金，商务专业感
    =================================================== */
    :root {
        --toc-width: 280px;

        /* 主色 - 深青蓝 */
        --primary-50:  #eef7f7;
        --primary-100: #d0ebec;
        --primary-200: #a3d5d8;
        --primary-300: #6db8bd;
        --primary-400: #3d9ba2;
        --primary-500: #1a7f87;
        --primary-600: #146870;
        --primary-700: #0f5158;
        --primary-800: #0a3c42;
        --primary-900: #062830;

        /* 强调色 - 暖琥珀金 */
        --accent-100: #fef9ec;
        --accent-200: #fdf0c5;
        --accent-300: #fbe08a;
        --accent-400: #f9c94e;
        --accent-500: #f5b120;
        --accent-600: #d9920d;
        --accent-700: #b3730a;

        /* 中性色 */
        --neutral-50:  #f8fafb;
        --neutral-100: #f1f4f6;
        --neutral-200: #e2e8ec;
        --neutral-300: #c8d3da;
        --neutral-400: #9aabb6;
        --neutral-500: #6b8291;
        --neutral-600: #4a6271;
        --neutral-700: #304a57;
        --neutral-800: #1d3340;
        --neutral-900: #0f1f28;

        /* 语义色 */
        --color-success: #1d9e6f;
        --color-warning: #e59a10;
        --color-danger:  #d94040;
        --color-info:    #1a7f87;

        /* 阴影 */
        --shadow-xs: 0 1px 3px rgba(15, 31, 40, 0.06);
        --shadow-sm: 0 2px 6px rgba(15, 31, 40, 0.08);
        --shadow-md: 0 4px 16px rgba(15, 31, 40, 0.10);
        --shadow-lg: 0 8px 32px rgba(15, 31, 40, 0.14);
        --shadow-xl: 0 20px 60px rgba(15, 31, 40, 0.18);

        /* 圆角 */
        --radius-sm:  6px;
        --radius-md: 10px;
        --radius-lg: 16px;
        --radius-xl: 24px;

        /* 过渡 */
        --transition-fast:   150ms cubic-bezier(0.4, 0, 0.2, 1);
        --transition-normal: 250ms cubic-bezier(0.4, 0, 0.2, 1);
        --transition-slow:   400ms cubic-bezier(0.4, 0, 0.2, 1);
    }

    /* ===================================================
       全局基础样式
    =================================================== */
    *, *::before, *::after {
        box-sizing: border-box;
    }

    body {
        font-family: 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', -apple-system,
                     BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        line-height: 1.7;
        color: var(--neutral-800);
        margin: 0;
        padding: 0;
        background-color: var(--neutral-100);
        position: relative;
    }

    /* ===================================================
       布局容器
    =================================================== */
    .main-container {
        width: 100%;
        min-height: 100vh;
    }

    .report-content {
        width: 100%;
        margin: 0;
        padding: 0;
        display: flex;
        position: relative;
    }

    /* 主内容区域 */
    .content-wrapper {
        margin-left: calc(var(--toc-width) + 8px);
        flex: 1;
        min-width: 0;
        padding: 24px;
        width: calc(100% - var(--toc-width) - 8px);
        position: relative;
        z-index: 2;
    }

    /* 容器样式 - 主内容卡片 */
    .markdown-body {
        background-color: #ffffff;
        padding: 48px 52px;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-md);
        border: 1px solid var(--primary-100);
        border-top: 4px solid var(--primary-500);
        min-width: 0;
        overflow-x: auto;
    }

    /* ===================================================
       目录导航栏 - 左侧固定
    =================================================== */
    .toc-container {
        background: linear-gradient(180deg, #ffffff 0%, var(--primary-50) 100%);
        border-right: 1px solid var(--primary-100);
        padding: 28px 18px 28px 20px;
        box-shadow: 3px 0 12px rgba(15, 81, 88, 0.06);
        position: fixed;
        left: 0;
        top: 0;
        width: var(--toc-width);
        min-width: 200px;
        max-width: 600px;
        height: 100vh;
        overflow-y: auto;
        overflow-x: hidden;
        z-index: 100;
        transition: transform var(--transition-slow), width 0.2s ease;
        scrollbar-width: thin;
        scrollbar-color: var(--primary-200) transparent;
    }

    .toc-container::-webkit-scrollbar {
        width: 4px;
    }
    .toc-container::-webkit-scrollbar-track {
        background: transparent;
    }
    .toc-container::-webkit-scrollbar-thumb {
        background: var(--primary-200);
        border-radius: 2px;
    }

    /* 目录隐藏状态 */
    .toc-container.hidden {
        transform: translateX(calc(-100% - 8px));
    }

    /* 目录切换按钮 */
    .toc-toggle-btn {
        position: fixed;
        left: var(--toc-width);
        top: 22px;
        width: 36px;
        height: 36px;
        background: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-700) 100%);
        color: white;
        border: none;
        border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
        cursor: pointer;
        font-size: 18px;
        z-index: 102;
        transition: left var(--transition-slow), background var(--transition-fast);
        box-shadow: var(--shadow-sm);
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .toc-toggle-btn:hover {
        background: linear-gradient(135deg, var(--primary-600) 0%, var(--primary-800) 100%);
        box-shadow: var(--shadow-md);
    }

    body.toc-hidden .toc-toggle-btn { left: 0; }
    body.toc-hidden .toc-container  { transform: translateX(calc(-100% - 8px)); }
    body.toc-hidden .content-wrapper { margin-left: 0; }
    body.toc-hidden .toc-resizer     { display: none; }
    body.toc-hidden .cover-page      { margin-left: 0; width: 100%; }

    /* 目录拖拽分隔条 */
    .toc-resizer {
        position: fixed;
        left: var(--toc-width);
        top: 0;
        width: 7px;
        height: 100vh;
        background-color: var(--primary-100);
        cursor: col-resize;
        z-index: 101;
        transition: background-color var(--transition-fast), width var(--transition-fast);
        user-select: none;
        -webkit-user-select: none;
    }

    .toc-resizer:hover,
    .toc-resizer.active {
        background-color: var(--primary-400);
        width: 9px;
    }

    .toc-resizer::before {
        content: '';
        position: absolute;
        left: -5px;
        top: 0;
        width: 15px;
        height: 100%;
        cursor: col-resize;
    }

    /* 目录标题 */
    .toc-title {
        font-size: 0.85em;
        font-weight: 700;
        color: var(--primary-600);
        margin-bottom: 18px;
        padding-bottom: 12px;
        border-bottom: 2px solid var(--primary-200);
        letter-spacing: 1.5px;
        text-transform: uppercase;
        text-align: center;
    }

    .toc-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .toc-content-wrapper {
        width: 100%;
    }

    .toc-content-wrapper .toc-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .toc-list li {
        margin: 3px 0;
        padding: 0;
    }

    .toc-link {
        color: var(--neutral-600);
        text-decoration: none;
        display: block;
        padding: 8px 12px;
        border-radius: var(--radius-sm);
        transition: all var(--transition-fast);
        font-size: 0.88em;
        line-height: 1.5;
        border-left: 3px solid transparent;
    }

    .toc-link:hover {
        background-color: var(--primary-50);
        color: var(--primary-700);
        padding-left: 16px;
        border-left-color: var(--primary-500);
    }

    /* ===================================================
       标题样式 - 带左侧色块装饰
    =================================================== */
    h1, h2, h3, h4, h5, h6 {
        scroll-margin-top: 80px;
        font-weight: 700;
        line-height: 1.35;
    }

    h1:hover::before, h2:hover::before, h3:hover::before,
    h4:hover::before, h5:hover::before, h6:hover::before {
        content: "§ ";
        opacity: 0.3;
        font-weight: 400;
    }

    h1 {
        color: var(--neutral-900);
        font-size: 2.1em;
        margin-top: 0;
        margin-bottom: 32px;
        padding-bottom: 16px;
        border-bottom: 3px solid var(--primary-200);
        position: relative;
    }

    h1::after {
        content: '';
        position: absolute;
        bottom: -3px;
        left: 0;
        width: 60px;
        height: 3px;
        background: linear-gradient(90deg, var(--primary-500), var(--accent-500));
        border-radius: 2px;
    }

    h2 {
        color: var(--primary-700);
        font-size: 1.65em;
        margin-top: 44px;
        margin-bottom: 22px;
        padding: 10px 16px 10px 16px;
        background: linear-gradient(90deg, var(--primary-50) 0%, transparent 100%);
        border-left: 4px solid var(--primary-500);
        border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
    }

    h3 {
        color: var(--primary-600);
        font-size: 1.35em;
        margin-top: 36px;
        margin-bottom: 16px;
        padding-left: 12px;
        border-left: 3px solid var(--accent-400);
    }

    h4 {
        color: var(--neutral-700);
        font-size: 1.15em;
        margin-top: 28px;
        margin-bottom: 12px;
        padding-left: 10px;
        border-left: 2px solid var(--primary-300);
    }

    h5, h6 {
        color: var(--neutral-600);
        font-size: 1.05em;
        margin-top: 22px;
        margin-bottom: 10px;
        font-weight: 600;
    }

    /* ===================================================
       段落、文本
    =================================================== */
    p {
        margin: 16px 0;
        color: var(--neutral-800);
        line-height: 1.85;
        font-size: 1em;
    }

    strong, b {
        color: var(--neutral-900);
        font-weight: 700;
    }

    em, i {
        color: var(--neutral-700);
    }

    /* ===================================================
       链接
    =================================================== */
    a {
        color: var(--primary-600);
        text-decoration: none;
        border-bottom: 1px solid var(--primary-200);
        transition: all var(--transition-fast);
        font-weight: 500;
    }

    a:hover {
        color: var(--primary-800);
        border-bottom-color: var(--primary-600);
    }

    /* ===================================================
       代码样式
    =================================================== */
    code {
        background-color: var(--primary-50);
        color: var(--primary-700);
        padding: 2px 8px;
        border-radius: var(--radius-sm);
        font-family: 'JetBrains Mono', 'SF Mono', 'Fira Code', 'Consolas', 'Courier New', monospace;
        font-size: 0.9em;
        border: 1px solid var(--primary-100);
        letter-spacing: -0.3px;
    }

    pre {
        background: linear-gradient(180deg, var(--neutral-900) 0%, var(--neutral-800) 100%);
        color: #cdd9e5;
        padding: 24px 28px;
        border-radius: var(--radius-md);
        overflow-x: auto;
        border-left: 5px solid var(--accent-500);
        margin: 28px 0;
        box-shadow: var(--shadow-lg);
        font-size: 0.9em;
        line-height: 1.7;
        position: relative;
    }

    pre::before {
        content: '';
        position: absolute;
        top: 14px;
        left: 18px;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #ff5f57;
        box-shadow: 18px 0 0 #febc2e, 36px 0 0 #28c840;
    }

    pre code {
        background: transparent;
        color: inherit;
        padding: 0;
        border: none;
        font-size: inherit;
    }

    /* ===================================================
       表格样式 - 精致线性设计
    =================================================== */
    table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        margin: 28px 0;
        background: #ffffff;
        box-shadow: var(--shadow-sm);
        border-radius: var(--radius-md);
        overflow: hidden;
        border: 1px solid var(--primary-100);
        table-layout: auto;
    }

    thead {
        background: linear-gradient(135deg, var(--primary-700) 0%, var(--primary-600) 100%) !important;
    }

    th {
        padding: 14px 16px;
        text-align: left;
        font-weight: 600;
        font-size: 0.82em;
        letter-spacing: 0.8px;
        text-transform: uppercase;
        border-bottom: none;
        min-width: 90px;
        color: rgba(255, 255, 255, 0.95) !important;
        background: linear-gradient(135deg, var(--primary-700) 0%, var(--primary-600) 100%) !important;
        white-space: nowrap;
    }

    table thead th,
    table.markdown-table thead th,
    .markdown-body table thead th {
        color: rgba(255, 255, 255, 0.95) !important;
        background: linear-gradient(135deg, var(--primary-700) 0%, var(--primary-600) 100%) !important;
    }

    td {
        padding: 13px 16px;
        border-bottom: 1px solid var(--neutral-100);
        transition: background-color var(--transition-fast);
        min-width: 90px;
        word-break: break-word;
        color: var(--neutral-800);
        font-size: 0.95em;
    }

    th:first-child, td:first-child { min-width: 110px; }

    tbody tr {
        transition: background-color var(--transition-fast);
    }

    tbody tr:nth-child(odd)  { background-color: #ffffff; }
    tbody tr:nth-child(even) { background-color: var(--neutral-50); }
    tbody tr:hover           { background-color: var(--primary-50) !important; }
    tbody tr:last-child td   { border-bottom: none; }

    /* 表格第一列加粗 */
    tbody td:first-child {
        font-weight: 500;
        color: var(--neutral-900);
    }

    /* ===================================================
       列表样式
    =================================================== */
    ul, ol {
        margin: 18px 0;
        padding-left: 32px;
    }

    li {
        margin: 9px 0;
        line-height: 1.8;
        color: var(--neutral-800);
        font-size: 1em;
    }

    ul > li {
        list-style: none;
        position: relative;
    }

    ul > li::before {
        content: '';
        position: absolute;
        left: -18px;
        top: 0.65em;
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: var(--primary-400);
        border: 2px solid var(--primary-200);
    }

    ol li {
        list-style-type: decimal;
    }

    /* 嵌套列表 */
    li > ul > li::before {
        width: 5px;
        height: 5px;
        background: transparent;
        border-color: var(--primary-400);
    }

    /* ===================================================
       水平分割线
    =================================================== */
    hr, .markdown-hr {
        border: none;
        height: 0;
        margin: 40px 0;
        border-top: 1px solid var(--primary-300);
        background: none;
    }

    /* ===================================================
       图片
    =================================================== */
    img {
        max-width: 100%;
        height: auto;
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-md);
        margin: 20px 0;
    }

    /* ===================================================
       引用块
    =================================================== */
    blockquote {
        border-left: 4px solid var(--primary-400);
        margin: 24px 0;
        padding: 16px 22px;
        background: linear-gradient(90deg, var(--primary-50) 0%, rgba(238, 247, 247, 0.3) 100%);
        border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
        color: var(--neutral-700);
        font-style: italic;
    }

    blockquote p {
        margin: 0;
        color: inherit;
    }

    /* ===================================================
       页脚样式
    =================================================== */
    .report-footer {
        margin-top: 56px;
        padding: 24px 28px;
        border-top: 2px solid var(--primary-100);
        text-align: center;
        background: linear-gradient(135deg, var(--primary-50) 0%, var(--accent-100) 100%);
        border-radius: var(--radius-md);
        margin-left: -52px;
        margin-right: -52px;
        margin-bottom: -48px;
        line-height: 1.9;
    }

    .report-footer .generation-time {
        margin-bottom: 8px;
        color: var(--neutral-500);
        font-size: 0.9em;
    }

    .report-footer .copyright {
        font-weight: 600;
        color: var(--primary-600);
        font-size: 1em;
    }

    .report-footer .disclaimer {
        margin-top: 10px;
        color: var(--neutral-500);
        font-style: italic;
        font-size: 0.88em;
    }

    /* ===================================================
       返回顶部 / 父章节按钮
    =================================================== */
    .section-buttons {
        margin-top: 40px;
        margin-bottom: 20px;
        padding-top: 18px;
        border-top: 1px solid var(--primary-100);
        text-align: right;
    }

    .section-button {
        display: inline-block;
        padding: 7px 15px;
        margin-left: 10px;
        background: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-700) 100%);
        color: white;
        text-decoration: none;
        border-radius: 20px;
        font-size: 0.85em;
        font-weight: 500;
        transition: all var(--transition-fast);
        border: none;
        cursor: pointer;
        box-shadow: 0 2px 8px rgba(26, 127, 135, 0.25);
        letter-spacing: 0.3px;
    }

    .section-button:hover {
        background: linear-gradient(135deg, var(--primary-600) 0%, var(--primary-800) 100%);
        transform: translateY(-2px);
        box-shadow: 0 5px 14px rgba(26, 127, 135, 0.35);
    }

    .section-button:active {
        transform: translateY(0);
    }

    .section-button i {
        margin-right: 4px;
    }

    /* JavaScript功能样式 */
    script { display: none; }

    /* ===================================================
       标签页样式
    =================================================== */
    .report-tabs {
        margin-bottom: 0;
        background: transparent;
        padding: 0;
    }

    .tab-buttons {
        display: flex;
        gap: 6px;
        margin: 0 0 0 0;
        padding: 0;
        list-style: none;
        background: transparent;
        border-bottom: 2px solid var(--primary-200);
        padding-bottom: 0;
    }

    .tab-button {
        flex: 1;
        padding: 14px 24px;
        background: var(--neutral-100);
        border: 1px solid var(--neutral-200);
        border-bottom: 3px solid transparent;
        border-radius: var(--radius-sm) var(--radius-sm) 0 0;
        cursor: pointer;
        font-size: 1em;
        font-weight: 600;
        color: var(--neutral-500);
        transition: all var(--transition-fast);
        text-align: center;
        position: relative;
        letter-spacing: 0.3px;
        margin-bottom: -2px;
    }

    .tab-button:hover {
        background: var(--primary-50);
        color: var(--primary-600);
        border-color: var(--primary-200);
        border-bottom-color: var(--primary-300);
    }

    .tab-button.active {
        color: var(--primary-700);
        background: #ffffff;
        border-color: var(--primary-200);
        border-bottom: 3px solid var(--accent-500);
        font-weight: 700;
    }

    .tab-button.active:hover {
        background: #ffffff;
    }

    .tab-content {
        display: none;
        padding: 32px 0 0 0;
        animation: fadeIn var(--transition-normal);
    }

    .tab-content.active {
        display: block;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(8px); }
        to   { opacity: 1; transform: translateY(0);   }
    }

    /* ===================================================
       封面页样式 - 浅色清爽背景（logo 与正文对比清晰）
    =================================================== */
    .cover-page {
        width: calc(100% - var(--toc-width) - 8px);
        min-height: calc(100vh - 40px);
        background:
            linear-gradient(165deg,
                var(--neutral-50) 0%,
                var(--primary-50) 38%,
                #f4fbfc 72%,
                var(--primary-100) 100%);
        background-size: 400% 400%;
        animation: coverShift 20s ease infinite;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 48px 30px;
        margin-left: calc(var(--toc-width) + 8px);
        margin-bottom: 40px;
        box-shadow: var(--shadow-xl);
        page-break-after: always;
        position: relative;
        z-index: 1;
        transition: width var(--transition-slow), margin-left var(--transition-slow);
        overflow: hidden;
    }

    /* 封面装饰：浅色光晕 */
    .cover-page::before {
        content: '';
        position: absolute;
        top: -10%;
        right: -10%;
        width: 55%;
        height: 70%;
        background: radial-gradient(ellipse, rgba(26, 127, 135, 0.10) 0%, transparent 68%);
        pointer-events: none;
    }

    .cover-page::after {
        content: '';
        position: absolute;
        bottom: -5%;
        left: -5%;
        width: 45%;
        height: 55%;
        background: radial-gradient(ellipse, rgba(245, 177, 32, 0.14) 0%, transparent 68%);
        pointer-events: none;
    }

    /* 封面内容卡片 */
    .cover-content {
        background: rgba(255, 255, 255, 0.94);
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
        border: 1px solid rgba(15, 31, 40, 0.07);
        border-radius: var(--radius-xl);
        padding: 52px 56px 46px 56px;
        max-width: 940px;
        width: 100%;
        text-align: center;
        box-shadow:
            0 0 0 1px rgba(255, 255, 255, 0.9) inset,
            var(--shadow-lg);
        margin: 0 auto;
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        min-height: 82vh;
    }

    .cover-content::before {
        content: '';
        position: absolute;
        top: 0;
        left: 8%;
        right: 8%;
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(15, 31, 40, 0.08), transparent);
    }

    /* 封面 Logo */
    .cover-logo {
        margin: 10px 0 28px 0;
        flex-shrink: 0;
    }

    .logo-image {
        max-width: 280px;
        height: auto;
        display: block;
        margin: 0 auto;
        filter: drop-shadow(0 4px 14px rgba(15, 31, 40, 0.08));
        transition: transform var(--transition-normal);
    }

    .logo-image:hover { transform: scale(1.03); }

    .logo-circle {
        width: 130px;
        height: 130px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-700) 100%);
        color: #ffffff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 2.6em;
        font-weight: bold;
        box-shadow: 0 6px 24px rgba(26, 127, 135, 0.5);
        margin: 0 auto;
    }

    /* 封面标题 */
    .cover-title {
        font-size: 2.7em;
        font-weight: 800;
        color: var(--neutral-800);
        margin: 12px 0 18px 0;
        line-height: 1.25;
        letter-spacing: -0.5px;
        text-shadow: none;
        flex-shrink: 0;
    }

    .cover-subtitle {
        font-size: 1.3em;
        font-weight: 400;
        color: var(--primary-700);
        margin: 0 0 28px 0;
        font-style: italic;
    }

    /* 封面分割线 */
    .cover-divider {
        width: 100px;
        height: 4px;
        background: linear-gradient(90deg, var(--primary-500) 0%, var(--accent-500) 100%);
        margin: 20px auto 26px auto;
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(26, 127, 135, 0.18);
        position: relative;
        flex-shrink: 0;
    }

    .cover-divider::before,
    .cover-divider::after {
        content: '';
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 7px;
        height: 7px;
        border-radius: 50%;
        box-shadow: 0 2px 6px rgba(245, 177, 32, 0.4);
    }

    .cover-divider::before {
        left: -14px;
        background: var(--primary-400);
    }

    .cover-divider::after {
        right: -14px;
        background: var(--accent-500);
    }

    /* 封面信息 */
    .cover-info {
        margin: 16px 0 24px 0;
        text-align: center;
        display: inline-block;
        background: var(--neutral-50);
        padding: 16px 32px;
        border-radius: var(--radius-md);
        border: 1px solid rgba(15, 31, 40, 0.06);
        flex-shrink: 0;
    }

    .cover-info-item {
        margin: 7px 0;
        font-size: 1.05em;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
    }

    .cover-info-item .info-label {
        font-weight: 600;
        color: var(--neutral-600);
        font-size: 0.95em;
    }

    .cover-info-item .info-value {
        color: var(--primary-700);
        font-weight: 700;
        font-size: 1.05em;
    }

    /* 封面页脚 */
    .cover-footer {
        margin-top: auto;
        padding: 26px 20px 20px 20px;
        border-top: 1px solid rgba(15, 31, 40, 0.08);
        background: rgba(248, 250, 251, 0.75);
        border-radius: 0 0 var(--radius-lg) var(--radius-lg);
        margin-left: -36px;
        margin-right: -36px;
        flex-shrink: 0;
    }

    .cover-company {
        font-size: 1.3em;
        font-weight: 700;
        color: var(--neutral-800);
        margin-bottom: 8px;
        letter-spacing: 0.3px;
    }

    .cover-tool {
        font-size: 1em;
        color: var(--primary-700);
        font-weight: 500;
        margin-bottom: 18px;
    }

    .cover-contact {
        margin-top: 16px;
        padding-top: 16px;
        border-top: 1px solid rgba(15, 31, 40, 0.07);
    }

    .contact-hotline {
        font-size: 1em;
        color: var(--neutral-700);
        margin-bottom: 6px;
        font-weight: 500;
    }

    .contact-address {
        font-size: 0.9em;
        color: var(--neutral-500);
        line-height: 1.6;
    }

    .cover-wechat {
        margin-top: 16px;
        padding-top: 16px;
        border-top: 1px solid rgba(15, 31, 40, 0.07);
        text-align: center;
    }

    .wechat-title {
        font-size: 0.95em;
        color: var(--neutral-600);
        margin-bottom: 14px;
        font-weight: 500;
    }

    .wechat-qrcode {
        max-width: 140px;
        height: auto;
        display: block;
        margin: 0 auto;
        border-radius: var(--radius-md);
        box-shadow: 0 4px 18px rgba(15, 31, 40, 0.10);
        border: 2px solid rgba(15, 31, 40, 0.06);
        transition: transform var(--transition-normal), box-shadow var(--transition-normal);
    }

    .wechat-qrcode:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 24px rgba(15, 31, 40, 0.14);
    }

    /* 金仓社区封面样式 */
    .cover-kes-community-cta {
        margin-top: 8px;
        padding-top: 20px;
        border-top: 1px solid rgba(15, 31, 40, 0.07);
    }

    .cover-kes-community-cta-inner {
        max-width: 260px;
        margin: 0 auto;
        padding: 20px 18px 22px;
        text-align: center;
        background: var(--neutral-50);
        border-radius: var(--radius-lg);
        border: 1px solid rgba(15, 31, 40, 0.06);
        box-shadow: 0 6px 20px rgba(15, 31, 40, 0.08);
    }

    .cover-kes-community-qr {
        width: 140px;
        max-width: 100%;
        height: auto;
        display: block;
        margin: 0 auto 14px;
        border-radius: var(--radius-md);
        border: 2px solid rgba(15, 31, 40, 0.06);
        box-shadow: 0 4px 14px rgba(15, 31, 40, 0.08);
        transition: transform var(--transition-fast), box-shadow var(--transition-fast);
    }

    .cover-kes-community-qr:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 22px rgba(26, 127, 135, 0.18);
    }

    .cover-kes-community-slogan {
        margin: 0;
        font-size: 1em;
        font-weight: 600;
        color: var(--neutral-800);
        line-height: 1.5;
        letter-spacing: 0.02em;
    }

    @keyframes coverShift {
        0%   { background-position: 0%   50%; }
        50%  { background-position: 100% 50%; }
        100% { background-position: 0%   50%; }
    }

    /* 打印 */
    @media print {
        .cover-page {
            page-break-after: always;
            min-height: 100vh;
        }
    }

    /* ===================================================
       响应式设计
    =================================================== */
    @media (max-width: 1200px) {
        .markdown-body { padding: 36px 40px; }
    }

    @media (max-width: 992px) {
        .report-content { flex-direction: column; }

        .toc-container {
            width: 100% !important;
            position: relative;
            max-height: 340px;
            min-width: auto;
            max-width: none;
            height: auto;
            border-right: none;
            border-bottom: 1px solid var(--primary-100);
        }

        .toc-resizer { display: none; }

        .cover-page {
            width: 100% !important;
            margin-left: 0 !important;
        }

        .markdown-body { padding: 28px 32px; }

        .content-wrapper {
            width: 100% !important;
            margin-left: 0 !important;
            padding: 16px;
        }

        h1 { font-size: 1.9em; }
        h2 { font-size: 1.5em; }
        h3 { font-size: 1.25em; }
    }

    @media (max-width: 768px) {
        .markdown-body { padding: 20px 22px; }

        table { font-size: 0.88em; }
        th, td { padding: 11px 12px; min-width: 70px; }

        .cover-title { font-size: 2em; }
        .cover-content { padding: 36px 28px 32px; min-height: 70vh; }

        h1 { font-size: 1.7em; }
        h2 { font-size: 1.35em; }
        h3 { font-size: 1.15em; }
    }

    @media (max-width: 480px) {
        .markdown-body { padding: 16px 18px; }

        th, td { padding: 9px 10px; font-size: 0.85em; }

        h1 { font-size: 1.5em; }
        h2 { font-size: 1.25em; }
        h3 { font-size: 1.1em; }

        .cover-title { font-size: 1.7em; }
        .cover-content { padding: 28px 20px 24px; }

        .report-footer {
            margin-left: -18px;
            margin-right: -18px;
            margin-bottom: -16px;
        }
    }
</style>

<script>
// 目录显示/隐藏切换功能
function toggleToc() {
    const body = document.body;
    const tocContainer = document.getElementById('toc-container');
    const toggleBtn = document.getElementById('toc-toggle-btn');
    
    if (body.classList.contains('toc-hidden')) {
        // 显示目录
        body.classList.remove('toc-hidden');
        if (tocContainer) {
            tocContainer.classList.remove('hidden');
        }
        if (toggleBtn) {
            toggleBtn.textContent = '☰';
            toggleBtn.title = '隐藏目录';
        }
        // 保存状态到localStorage
        localStorage.setItem('toc-visible', 'true');
    } else {
        // 隐藏目录
        body.classList.add('toc-hidden');
        if (tocContainer) {
            tocContainer.classList.add('hidden');
        }
        if (toggleBtn) {
            toggleBtn.textContent = '☰';
            toggleBtn.title = '显示目录';
        }
        // 保存状态到localStorage
        localStorage.setItem('toc-visible', 'false');
    }
}

// 页面加载时恢复目录显示状态
function restoreTocState() {
    const savedState = localStorage.getItem('toc-visible');
    if (savedState === 'false') {
        document.body.classList.add('toc-hidden');
        const tocContainer = document.getElementById('toc-container');
        if (tocContainer) {
            tocContainer.classList.add('hidden');
        }
        const toggleBtn = document.getElementById('toc-toggle-btn');
        if (toggleBtn) {
            toggleBtn.title = '显示目录';
        }
    }
}

// 返回顶部功能
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// 返回父章节功能
function scrollToParent(level) {
    // 获取当前章节的父章节
    // 例如，如果当前是h3，父章节就是h2
    // 如果当前是h2，父章节就是h1
    
    if (level <= 1) {
        // 如果是h1章节，直接返回顶部
        scrollToTop();
        return;
    }
    
    // 计算父章节级别
    const parentLevel = level - 1;
    
    // 查找父章节元素
    const parentHeading = findParentHeading(parentLevel);
    
    if (parentHeading) {
        // 平滑滚动到父章节
        parentHeading.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    } else {
        // 如果没有找到父章节，返回顶部
        scrollToTop();
    }
}

// 查找父章节
function findParentHeading(parentLevel) {
    // 获取所有标题元素
    const headings = document.querySelectorAll(`h${parentLevel}`);
    
    // 获取当前滚动位置
    const scrollPosition = window.scrollY || window.pageYOffset;
    
    // 从后往前查找，找到第一个在当前滚动位置之前的父章节
    for (let i = headings.length - 1; i >= 0; i--) {
        const heading = headings[i];
        const headingPosition = heading.offsetTop;
        
        // 如果标题位置在当前滚动位置之前，这就是我们要找的父章节
        if (headingPosition < scrollPosition) {
            return heading;
        }
    }
    
    // 如果没找到，返回第一个父章节（如果存在）
    return headings.length > 0 ? headings[0] : null;
}

// 目录宽度拖拽功能
function initTocResizer() {
    // 从localStorage恢复保存的宽度
    const savedWidth = localStorage.getItem('toc-width');
    if (savedWidth) {
        document.documentElement.style.setProperty('--toc-width', savedWidth + 'px');
    }
    
    const resizer = document.getElementById('toc-resizer');
    if (!resizer) {
        // 如果元素不存在，稍后重试
        setTimeout(initTocResizer, 100);
        return;
    }
    
    let isResizing = false;
    let startX = 0;
    let startWidth = 0;
    
    // 获取当前CSS变量值
    function getTocWidth() {
        const width = getComputedStyle(document.documentElement).getPropertyValue('--toc-width').trim();
        return parseFloat(width) || 280;
    }
    
    // 设置CSS变量值
    function setTocWidth(width) {
        const minWidth = 200;
        const maxWidth = 600;
        width = Math.max(minWidth, Math.min(maxWidth, width));
        document.documentElement.style.setProperty('--toc-width', width + 'px');
        localStorage.setItem('toc-width', width.toString());
    }
    
    // 鼠标按下事件
    resizer.addEventListener('mousedown', function(e) {
        isResizing = true;
        startX = e.clientX;
        startWidth = getTocWidth();
        resizer.classList.add('active');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        e.preventDefault();
        e.stopPropagation();
    });
    
    // 鼠标移动事件
    document.addEventListener('mousemove', function(e) {
        if (!isResizing) return;
        
        const diff = e.clientX - startX;
        const newWidth = startWidth + diff;
        setTocWidth(newWidth);
        e.preventDefault();
    });
    
    // 鼠标释放事件
    document.addEventListener('mouseup', function() {
        if (isResizing) {
            isResizing = false;
            resizer.classList.remove('active');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
        }
    });
    
    // 触摸事件支持（移动设备）
    let touchStartX = 0;
    let touchStartWidth = 0;
    
    resizer.addEventListener('touchstart', function(e) {
        isResizing = true;
        touchStartX = e.touches[0].clientX;
        touchStartWidth = getTocWidth();
        resizer.classList.add('active');
        e.preventDefault();
        e.stopPropagation();
    });
    
    document.addEventListener('touchmove', function(e) {
        if (!isResizing) return;
        
        const diff = e.touches[0].clientX - touchStartX;
        const newWidth = touchStartWidth + diff;
        setTocWidth(newWidth);
        e.preventDefault();
    });
    
    document.addEventListener('touchend', function() {
        if (isResizing) {
            isResizing = false;
            resizer.classList.remove('active');
        }
    });
}

// 标签页切换功能
function switchTab(tabName) {
    // 隐藏所有标签内容
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        content.classList.remove('active');
    });
    
    // 移除所有按钮的active状态
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.classList.remove('active');
    });
    
    // 显示选中的标签内容
    const activeContent = document.getElementById('tab-' + tabName);
    if (activeContent) {
        activeContent.classList.add('active');
    }
    
    // 激活对应的按钮（优先使用data-tab属性查找，更可靠）
    let activeButton = document.querySelector('[data-tab="' + tabName + '"]');
    if (!activeButton) {
        // 降级方案：使用onclick属性查找
        const buttons = document.querySelectorAll('.tab-button');
        buttons.forEach(button => {
            const onclickAttr = button.getAttribute('onclick');
            if (onclickAttr && onclickAttr.includes("'" + tabName + "'")) {
                activeButton = button;
            }
        });
    }
    if (activeButton) {
        activeButton.classList.add('active');
    }
    
    // 切换目录显示（如果有标签页）
    const summaryTocContent = document.getElementById('toc-summary-content');
    const detailTocContent = document.getElementById('toc-detail-content');
    if (summaryTocContent && detailTocContent) {
        if (tabName === 'summary') {
            summaryTocContent.style.display = 'block';
            detailTocContent.style.display = 'none';
        } else if (tabName === 'detail') {
            summaryTocContent.style.display = 'none';
            detailTocContent.style.display = 'block';
        }
    }
    
    // 保存当前选中的标签到localStorage
    localStorage.setItem('active-tab', tabName);
}

// 恢复标签页状态
function restoreTabState() {
    // 先检查是否有标签页元素
    const tabContents = document.querySelectorAll('.tab-content');
    if (tabContents.length === 0) {
        // 没有标签页，直接返回
        return;
    }
    
    const savedTab = localStorage.getItem('active-tab');
    if (savedTab && (savedTab === 'summary' || savedTab === 'detail')) {
        // 有保存的状态，使用保存的状态
        switchTab(savedTab);
    } else {
        // 默认显示详细报告
        // 先清除所有active状态
        tabContents.forEach(content => {
            content.classList.remove('active');
        });
        const tabButtons = document.querySelectorAll('.tab-button');
        tabButtons.forEach(button => {
            button.classList.remove('active');
        });
        
        // 设置详细报告为默认显示
        const detailContent = document.getElementById('tab-detail');
        const detailButton = document.querySelector('[data-tab="detail"]') || 
                           document.querySelector('button[onclick*="detail"]');
        if (detailContent) {
            detailContent.classList.add('active');
        }
        if (detailButton) {
            detailButton.classList.add('active');
        }
        
        // 设置目录显示（默认显示详细报告的目录）
        const summaryTocContent = document.getElementById('toc-summary-content');
        const detailTocContent = document.getElementById('toc-detail-content');
        if (summaryTocContent && detailTocContent) {
            summaryTocContent.style.display = 'none';
            detailTocContent.style.display = 'block';
        }
        
        // 清除localStorage，确保下次也是默认显示详细报告（除非用户手动切换）
        localStorage.removeItem('active-tab');
    }
}

// 在DOM加载完成后初始化
function initAll() {
    initTocResizer();
    restoreTocState();
    // 延迟一点执行，确保DOM完全加载
    setTimeout(function() {
        restoreTabState();
    }, 100);
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
} else {
    // DOM已经加载完成
    initAll();
}
</script>
"""
    
    # 如果有标签页，需要分别处理概要和详细报告
    if has_tabs:
        # 为概要和详细报告的标题添加锚点ID
        summary_html = _add_anchor_ids(summary_html)
        detail_html = _add_anchor_ids(detail_html)
        
        # 为概要和详细报告添加返回按钮
        summary_html = _add_section_buttons(summary_html, lang=lang)
        detail_html = _add_section_buttons(detail_html, lang=lang)
        
        # 为概要和详细报告分别生成目录
        summary_toc_html = _generate_toc(summary_html, lang=lang) if show_toc else ""
        detail_toc_html = _generate_toc(detail_html, lang=lang) if show_toc else ""
        
        # 生成标签页HTML
        tab_text_map = {
            'zh': {
                'summary_tab': '报告概要',
                'detail_tab': '详细报告'
            },
            'en': {
                'summary_tab': 'Summary',
                'detail_tab': 'Detailed Report'
            }
        }
        tab_lang = lang if lang in tab_text_map else 'zh'
        tab_texts = tab_text_map[tab_lang]
        
        tabs_html = f"""
        <div class="report-tabs">
            <ul class="tab-buttons">
                <li>
                    <button class="tab-button" data-tab="summary" onclick="switchTab('summary')">{tab_texts['summary_tab']}</button>
                </li>
                <li>
                    <button class="tab-button active" data-tab="detail" onclick="switchTab('detail')">{tab_texts['detail_tab']}</button>
                </li>
            </ul>
        </div>
        <div id="tab-summary" class="tab-content">
            {summary_html}
        </div>
        <div id="tab-detail" class="tab-content active">
            {detail_html}
        </div>
        """
        html_body = tabs_html
    else:
        # 为标题添加锚点ID
        html_body = _add_anchor_ids(html_body)
        
        # 在每个章节末尾添加返回按钮
        html_body = _add_section_buttons(html_body, lang=lang)
    
    # 生成封面页
    cover_html = ""
    if show_cover:
        cover_html = _generate_cover_page(report_title=cover_title, lang=lang, tool_name=tool_name)
    
    # 生成目录导航栏
    toc_html = ""
    if show_toc:
        if has_tabs:
            # 如果有标签页，需要提取目录内容部分（不包括按钮和resizer）
            # 从summary_toc_html和detail_toc_html中提取目录容器内容
            import re
            
            def extract_toc_content(toc_html_str):
                """从完整的TOC HTML中提取目录列表内容（不包括标题）"""
                # 提取toc-list ul的内容
                match = re.search(r'<ul class="toc-list">(.*?)</ul>', toc_html_str, re.DOTALL)
                if match:
                    return f'<ul class="toc-list">{match.group(1)}</ul>'
                return ""
            
            summary_toc_content = extract_toc_content(summary_toc_html)
            detail_toc_content = extract_toc_content(detail_toc_html)
            
            # 获取目录标题（从详细报告中提取，因为两个目录的标题应该相同）
            toc_title_match = re.search(r'<div class="toc-title">(.*?)</div>', detail_toc_html)
            toc_title = toc_title_match.group(1) if toc_title_match else "目录"
            
            # 生成共享的按钮和resizer，以及两个可切换的目录容器
            toc_html = f"""
    <button class="toc-toggle-btn" id="toc-toggle-btn" onclick="toggleToc()" title="隐藏/显示目录">☰</button>
    <div class="toc-container" id="toc-container">
        <div class="toc-title">{toc_title}</div>
        <div id="toc-summary-content" class="toc-content-wrapper" style="display: none;">
            {summary_toc_content if summary_toc_content else '<ul class="toc-list"></ul>'}
        </div>
        <div id="toc-detail-content" class="toc-content-wrapper" style="display: block;">
            {detail_toc_content if detail_toc_content else '<ul class="toc-list"></ul>'}
        </div>
    </div>
    <div class="toc-resizer" id="toc-resizer"></div>"""
        else:
            toc_html = _generate_toc(html_body, lang=lang)
    
    # 生成页脚HTML
    footer_html = ""
    if show_footer:
        from datetime import datetime
        
        # 页脚文本多语言映射
        footer_text_map = {
            'zh': {
                'generation_time_label': '报告生成时间：',
                'company': '佰晟智算(深圳)技术有限公司',
                'disclaimer': '报告由BIC-QA 分析工具生成，仅供参考。'
            },
            'en': {
                'generation_time_label': 'Report Generated at: ',
                'company': 'Baisheng Intelligence (Shenzhen) Technology Co., Ltd.',
                'disclaimer': 'This report is generated by BIC-QA Analysis Tool, for reference only.'
            }
        }
        
        # 默认使用中文
        footer_lang = lang if lang in footer_text_map else 'zh'
        footer_texts = footer_text_map[footer_lang]
        generation_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        footer_html = f"""
    <div class="report-footer">
        <div class="generation-time">{footer_texts['generation_time_label']}{generation_time}</div>
        <div class="disclaimer">{footer_texts['disclaimer']}</div>
    </div>"""
    
    # 根据语言设置HTML lang属性
    html_lang = 'zh-CN' if lang == 'zh' else 'en'
    # 如果没有提供封面标题，使用默认值
    if cover_title is None:
        html_title = 'Oracle AWR 分析报告' if lang == 'zh' else 'Oracle AWR Analysis Report'
    else:
        html_title = cover_title
    
    return f"""<!DOCTYPE html>
<html lang="{html_lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html_title}</title>
    {styles}
</head>
<body>
    <div class="main-container">
        {cover_html}
        <div class="report-content">
            {toc_html}
            <div class="content-wrapper">
                <div class="markdown-body">
                    {html_body}
                    {footer_html}
                </div>
            </div>
        </div>
    </div>
</body>
</html>"""


def _allow_basic_tags(s: str) -> str:
    """
    转义 HTML 但允许少量基础标签在结果中呈现（strong/br/b/em/i/code），
    并且保留这些标签上的样式或其他属性（例如 style="color:red"）。
    用于表格单元格等场景。
    """
    import re

    # 先整体转义，确保非允许标签不会被直接执行
    esc = html_module.escape(s)

    # 允许带任意属性的基础标签：strong/b/em/i/code/span
    # 形态示例：&lt;strong style="color:red"&gt;... 转回 <strong style="color:red">
    # span 标签用于支持表格中自定义样式，如 <span style="color:red;font-weight:bold">异常</span>
    basic_tags = ['strong', 'b', 'em', 'i', 'code', 'span']
    for tag in basic_tags:
        # 起始标签（带任意属性，内部可能包含 &quot; 等实体，所以使用非贪婪匹配到 &gt; 之前）
        esc = re.sub(
            rf'&lt;({tag}\b.*?)&gt;',
            r'<\1>',
            esc,
            flags=re.IGNORECASE
        )
        # 结束标签
        esc = re.sub(
            rf'&lt;/{tag}&gt;',
            rf'</{tag}>',
            esc,
            flags=re.IGNORECASE
        )

    # 允许换行标签（兼容 <br>、<br/>、<br />）
    esc = re.sub(
        r'&lt;br\s*/?&gt;',
        '<br/>',
        esc,
        flags=re.IGNORECASE
    )

    # 允许标签属性中的引号正常存在（例如 style="color:red"）
    # 注意：这里只是把实体 &quot; 还原成 "，不影响整体的 XSS 安全性，
    # 因为非允许的标签仍然是整体转义的。
    esc = esc.replace('&quot;', '"')

    # 自动为未闭合的基础标签补全结束标签（常见于 Markdown 表格单元格中遗漏 </strong> 的场景）
    for tag in basic_tags:
        # 统计起始和结束标签数量
        open_pattern = re.compile(rf'<{tag}\b[^>]*>', re.IGNORECASE)
        close_pattern = re.compile(rf'</{tag}>', re.IGNORECASE)
        opens = len(open_pattern.findall(esc))
        closes = len(close_pattern.findall(esc))
        if opens > closes:
            # 在末尾补全缺失的结束标签，确保不会把后续整行内容都包进样式里
            esc = esc + ('</{0}>'.format(tag) * (opens - closes))

    return esc

if __name__ == "__main__":
    import os
    print("\n测试2：传统方式（单个Markdown文件）...")
    test_file = os.path.join(os.path.dirname(__file__), "AWR1_4.report.md")
    if os.path.exists(test_file):
        with open(test_file, "r", encoding="utf-8") as f:
            md_text = f.read()
        html_text = render_markdown_to_html(
            md_text=md_text,
            lang='zh',
            cover_title='测试报告',
            tool_name='BIC-QA工具'
        )
        output_file = os.path.join(os.path.dirname(__file__), "test_single.html")
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(html_text)
        print(f"✓ 单文件测试完成，输出文件: {output_file}")

    print("\n所有测试完成！")