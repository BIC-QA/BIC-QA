"""
大模型对话封装模块（向后兼容）
已迁移至 CommUtil，此模块仅作兼容封装
"""

from typing import Optional, Generator
from CommUtil import chat as _comm_chat


def chat(
    message: str,
    model: str = "qwen-plus",
    temperature: float = 0.8,
    stream: bool = True,
    timeout_sec: int = 120
) -> str | Generator[str, None, None]:
    """
    调用大模型 RESTful 接口，返回模型生成的文本。

    已迁移至 CommUtil.chat，此函数仅作兼容封装。
    """
    return _comm_chat(
        message=message,
        model=model,
        temperature=temperature,
        stream=stream,
        timeout_sec=timeout_sec
    )
