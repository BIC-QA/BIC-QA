/**
 * 固定 OpenAI 兼容问答接口（主问答、字数限制下的建议问题共用）
 */
export const FIXED_CHAT_COMPLETIONS_URL = 'http://106.38.159.13:8081/v1/chat/completions';
export const FIXED_CHAT_API_KEY = 'ygyQIqL5Uk0O3K0irG5eUmScYtGW4cybkCxB';
export const FIXED_CHAT_MODEL = 'hermes-agent';
