/**
 * 赛事首页「配套资料」——配套 zip 直链（点击后直接走浏览器下载）。
 * 更新版本时只需改下方 URL / 文件名常量。
 */
export const CONTEST_MATERIALS_DOWNLOAD_URL =
    'https://gitee.com/BIC-QA/bic-qa/releases/download/v1.0.6/KES%20%E8%B5%9B%E4%BA%8B%E9%85%8D%E5%A5%97%E8%B5%84%E6%96%99%E5%8C%85_20260509_V1.0.zip';

/** 下载保存时的建议文件名（与发行包一致） */
export const CONTEST_MATERIALS_DOWNLOAD_FILENAME =
    'KES 赛事配套资料包_20260509_V1.0.zip';
