/**
 * 会话管理器
 * 负责会话相关的功能，包括开启新会话、清理缓存等
 */
export function createSessionManager(popup) {
    return {
        /**
         * 开启新会话
         */
        startNewSession() {
            console.log('开启新会话');

            // 停止定期检查提示信息
            popup.stopProgressMessageReplacement();

            // 清空当前结果
            popup.clearResult();

            // 清空当前会话历史与关键词延续状态
            popup.currentSessionHistory = [];
            popup.currentConversationTurns = [];
            popup.accumulatedKeywordsForNextQuery = '';
            popup.currentHistorySessionId = null;
            console.log('startNewSession: 当前会话历史与关键词已清空');

            // 重置知识库相关状态变量
            popup._useKnowledgeBaseThisTime = false;
            popup._kbMatchCount = 0;
            popup._kbItems = [];
            popup._kbImageList = [];
            console.log('startNewSession: 知识库状态变量已重置');

            // 显示提示消息
            popup.showMessage(popup.t('popup.message.newSessionStarted'), 'success');

            // 重置一些会话相关的状态
            // 重置计时
            popup.startTime = null;

            // 重置加载状态
            popup.setLoading(false);

            // 重置按钮状态
            popup.updateButtonState();

            // 确保输入框获得焦点
            if (popup.questionInput) {
                popup.questionInput.focus();
                console.log('输入框已获得焦点');
            } else {
                console.warn('未找到输入框元素');
            }

            // 重新开始定期检查提示信息
            setTimeout(() => {
                popup.startProgressMessageReplacement();
            }, 1000);

            // 可选：重置其他会话相关的状态
            // 例如清除任何缓存的上下文信息等

            console.log('新会话已开启，所有状态已重置');
        },

        /**
         * 清理格式缓存
         */
        clearFormatCache() {
            popup._lastContent = null;
            popup._lastFormattedContent = null;
        },

        /**
         * 估算消息的token数量（简单估算：中文1字符≈1token，英文1词≈1token）
         */
        estimateTokens(content) {
            if (!content) return 0;
            // 简单估算：中文字符数 + 英文单词数
            const chineseChars = (content.match(/[\u4e00-\u9fa5]/g) || []).length;
            const englishWords = content.split(/\s+/).filter(word => /[a-zA-Z]/.test(word)).length;
            // 保守估算：中文字符按1.5倍计算，英文单词按1倍计算
            return Math.ceil(chineseChars * 1.5 + englishWords);
        },

        /**
         * 获取历史对话的总token数
         */
        getHistoryTokens() {
            if (!popup.currentSessionHistory || popup.currentSessionHistory.length === 0) {
                return 0;
            }
            return popup.currentSessionHistory.reduce((total, msg) => {
                return total + this.estimateTokens(msg.content);
            }, 0);
        },

        /**
         * 限制历史对话长度，避免超过token限制
         * @param {number} maxTokens - 最大token数（默认2000，约为max_tokens的一半）
         */
        limitHistoryLength(maxTokens = 2000) {
            if (!popup.currentSessionHistory || popup.currentSessionHistory.length === 0) {
                return;
            }

            let totalTokens = this.getHistoryTokens();
            
            // 如果总token数超过限制，从最旧的消息开始删除
            while (totalTokens > maxTokens && popup.currentSessionHistory.length > 0) {
                const removedMessage = popup.currentSessionHistory.shift();
                const removedTokens = this.estimateTokens(removedMessage.content);
                totalTokens -= removedTokens;
                console.log(`移除历史消息以控制token数量，剩余token: ${totalTokens}`);
            }

            // 确保至少保留一对对话（用户+助手），如果超过限制也要保留最新的
            if (popup.currentSessionHistory.length === 0 && totalTokens > maxTokens) {
                console.warn('历史对话token数超过限制，但保留最新对话');
            }
        },

        /**
         * 添加到当前会话历史
         */
        addToCurrentSessionHistory(userQuestion, aiAnswer) {
            // 检查是否已经存在相同的对话，避免重复添加
            const lastUserMessage = popup.currentSessionHistory[popup.currentSessionHistory.length - 2];
            const lastAssistantMessage = popup.currentSessionHistory[popup.currentSessionHistory.length - 1];

            // 如果最后一条用户消息和AI回答与当前要添加的相同，则不添加
            if (lastUserMessage && lastAssistantMessage &&
                lastUserMessage.role === "user" && lastAssistantMessage.role === "assistant" &&
                lastUserMessage.content === userQuestion && lastAssistantMessage.content === aiAnswer) {
                console.log('检测到重复对话，跳过添加:', { userQuestion, aiAnswer });
                return;
            }

            // 添加用户问题
            popup.currentSessionHistory.push({
                role: "user",
                content: userQuestion
            });

            // 添加AI回答
            popup.currentSessionHistory.push({
                role: "assistant",
                content: aiAnswer
            });

            // 限制历史对话长度（基于token数量，默认最多2000 tokens）
            // 这样可以确保历史对话不会占用太多token，为当前对话留出空间
            this.limitHistoryLength(2000);

            // 如果token限制后仍然超过6条消息，则按消息数量限制（兜底策略）
            if (popup.currentSessionHistory.length > 6) {
                popup.currentSessionHistory = popup.currentSessionHistory.slice(-6);
                console.log('历史对话超过6条，保留最新6条');
            }

            console.log('当前会话历史:', popup.currentSessionHistory);
            console.log('历史对话token数:', this.getHistoryTokens());
        }
    };
}

