import { escapeHtml } from '../utils/common.js';
import { extractKeywords } from './keyword-extractor.js';

/** 历史记录最大条数 */
const HISTORY_MAX_RECORDS = 30;
/** 每条历史记录最多保留的对话轮数 */
const MAX_TURNS_PER_RECORD = 20;
/** 每页显示条数 */
const HISTORY_PAGE_SIZE = 10;

function bindToPopup(fn, popup) {
    return fn.bind(null, popup);
}

export function createHistoryService(popup) {
    return {
        saveConversationHistory: bindToPopup(saveConversationHistory, popup),
        cleanupHistoryRecords: bindToPopup(cleanupHistoryRecords, popup),
        showHistoryDialog: bindToPopup(showHistoryDialog, popup),
        hideHistoryDialog: bindToPopup(hideHistoryDialog, popup),
        loadHistoryList: bindToPopup(loadHistoryList, popup),
        goToHistoryPage: bindToPopup(goToHistoryPage, popup),
        createHistoryItemElement: bindToPopup(createHistoryItemElement, popup),
        copyHistoryItem: bindToPopup(copyHistoryItem, popup),
        deleteHistoryItem: bindToPopup(deleteHistoryItem, popup),
        updateBatchButtons: bindToPopup(updateBatchButtons, popup),
        batchDeleteHistory: bindToPopup(batchDeleteHistory, popup),
        toggleSelectAll: bindToPopup(toggleSelectAll, popup),
        toggleHistoryExpansion: bindToPopup(toggleHistoryExpansion, popup),
        clearHistory: bindToPopup(clearHistory, popup),
        exportHistory: bindToPopup(exportHistory, popup),
        batchExportHistory: bindToPopup(batchExportHistory, popup),
        continueConversation: bindToPopup(continueConversation, popup)
    };
}

/**
 * 将 turns 转为 sessionHistory
 * @param {Array} turns
 * @param {boolean} limitForApi - 若 true 则只保留最后 6 轮（供 API 上下文），否则全部保留（供展示）
 */
function turnsToSessionHistory(turns, limitForApi = false) {
    if (!turns || !Array.isArray(turns)) return [];
    const msgs = [];
    for (const t of turns) {
        if (t.question) msgs.push({ role: 'user', content: t.question });
        if (t.answer) msgs.push({ role: 'assistant', content: t.answer });
    }
    return limitForApi ? msgs.slice(-12) : msgs;
}

async function saveConversationHistory(popup, question, answer, modelName, knowledgeBaseId, pageUrl, options = {}) {
    try {
        const maxLength = 1000;
        const modelKey = options.model ? JSON.stringify({ name: options.model.name, provider: options.model.provider }) : null;
        const safeQuestion = typeof question === 'string' ? question : (question ?? '');
        const safeAnswer = typeof answer === 'string' ? answer : (answer ?? '');
        const truncatedQuestion = safeQuestion.length > maxLength ? safeQuestion.substring(0, maxLength) + '...' : safeQuestion;
        const truncatedAnswer = safeAnswer.length > maxLength ? safeAnswer.substring(0, maxLength) + '...' : safeAnswer;

        // 提取关键词（异步，设 3 秒超时，避免用户关闭弹窗前无法完成保存）
        let keywords = '';
        const { provider, model } = options;
        if (provider && model) {
            try {
                keywords = await Promise.race([
                    extractKeywords(popup, question, answer, provider, model),
                    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 3000))
                ]);
            } catch (e) {
                if (e?.message !== 'timeout') console.warn('关键词提取失败，跳过:', e);
            }
        }

        // 更新当前会话的 turns 与 accumulatedKeywords
        if (!popup.currentConversationTurns) popup.currentConversationTurns = [];
        popup.currentConversationTurns.push({
            question: truncatedQuestion,
            answer: truncatedAnswer,
            keywords: keywords
        });
        if (popup.currentConversationTurns.length > MAX_TURNS_PER_RECORD) {
            popup.currentConversationTurns = popup.currentConversationTurns.slice(-MAX_TURNS_PER_RECORD);
        }

        const newKeywords = keywords ? keywords.trim() : '';
        if (popup.accumulatedKeywordsForNextQuery) {
            popup.accumulatedKeywordsForNextQuery = [popup.accumulatedKeywordsForNextQuery, newKeywords]
                .filter(Boolean)
                .join(', ');
        } else {
            popup.accumulatedKeywordsForNextQuery = newKeywords;
        }

        let knowledgeBaseName = null;
        let knowledgeBaseIdForHistory = knowledgeBaseId;
        if (knowledgeBaseId) {
            try {
                const knowledgeBase = JSON.parse(knowledgeBaseId);
                if (knowledgeBase.name) {
                    knowledgeBaseName = knowledgeBase.name;
                    knowledgeBaseIdForHistory = knowledgeBase.id;
                }
            } catch (parseError) {
                const knowledgeBase = window.knowledgeBaseManager?.getKnowledgeBaseById(knowledgeBaseId);
                if (knowledgeBase) {
                    knowledgeBaseName = knowledgeBase.name;
                }
            }
        }

        const turns = popup.currentConversationTurns.map(t => ({
            question: (t.question || '').substring(0, 2000),
            answer: (t.answer || '').substring(0, 2000),
            keywords: (t.keywords || '').substring(0, 200)
        }));

        const sessionHistoryToSave = turnsToSessionHistory(turns, true);
        const firstQ = turns[0]?.question || truncatedQuestion;
        const lastA = turns[turns.length - 1]?.answer || truncatedAnswer;

        let targetItem;
        if (popup.currentHistorySessionId) {
            targetItem = popup.conversationHistory.find(h => h.id === popup.currentHistorySessionId);
            if (targetItem) {
                targetItem.turns = turns;
                targetItem.sessionHistory = sessionHistoryToSave;
                targetItem.accumulatedKeywords = popup.accumulatedKeywordsForNextQuery || '';
                targetItem.question = firstQ;
                targetItem.answer = lastA;
                targetItem.timestamp = new Date().toISOString();
                if (modelKey) targetItem.modelKey = modelKey;
                if (knowledgeBaseIdForHistory !== undefined) targetItem.knowledgeBaseId = knowledgeBaseIdForHistory;
                // 将该条移至最前
                popup.conversationHistory = popup.conversationHistory.filter(h => h.id !== targetItem.id);
                popup.conversationHistory.unshift(targetItem);
            } else {
                popup.currentHistorySessionId = null;
                targetItem = null;
            }
        }

        if (!targetItem) {
            targetItem = {
                id: Date.now().toString(),
                question: firstQ,
                answer: lastA,
                modelName: modelName,
                modelKey: modelKey || null,
                knowledgeBaseId: knowledgeBaseIdForHistory,
                knowledgeBaseName: knowledgeBaseName,
                pageUrl: pageUrl ? pageUrl.substring(0, 200) : '',
                timestamp: new Date().toISOString(),
                turns: turns,
                sessionHistory: sessionHistoryToSave,
                accumulatedKeywords: popup.accumulatedKeywordsForNextQuery || ''
            };
            popup.currentHistorySessionId = targetItem.id;
            popup.conversationHistory.unshift(targetItem);
        }

        if (popup.conversationHistory.length > HISTORY_MAX_RECORDS) {
            popup.conversationHistory = popup.conversationHistory.slice(0, HISTORY_MAX_RECORDS);
        }

        try {
            await chrome.storage.local.set({
                conversationHistory: popup.conversationHistory
            });
            console.log('对话历史记录已保存到 local 存储，当前记录数:', popup.conversationHistory.length, '本轮关键词:', keywords);
        } catch (error) {
            console.error('保存对话历史记录失败:', error);
            if (error.message && error.message.includes('quota')) {
                await cleanupHistoryRecords(popup);
                try {
                    await chrome.storage.local.set({
                        conversationHistory: popup.conversationHistory
                    });
                } catch (retryError) {
                    if (popup.conversationHistory.length > 10) {
                        popup.conversationHistory = popup.conversationHistory.slice(0, 10);
                        try {
                            await chrome.storage.local.set({
                                conversationHistory: popup.conversationHistory
                            });
                        } catch (finalError) {
                            console.error('最终保存失败:', finalError);
                        }
                    }
                }
            }
        }
    } catch (error) {
        console.error('保存对话历史记录失败:', error);
    }
}

async function cleanupHistoryRecords(popup) {
    try {
        console.log('开始清理历史记录...');

        // 如果历史记录过多，保留最近30条（与上限一致）
        if (popup.conversationHistory.length > 30) {
            console.log(`历史记录过多(${popup.conversationHistory.length}条)，清理到30条`);
            popup.conversationHistory = popup.conversationHistory.slice(0, 30);
        }

        const result = await chrome.storage.sync.get(['feedbackHistory']);
        const feedbackHistory = result.feedbackHistory || [];

        if (feedbackHistory.length > 20) {
            const cleanedFeedbackHistory = feedbackHistory.slice(0, 20);
            await chrome.storage.sync.set({ feedbackHistory: cleanedFeedbackHistory });
            console.log('反馈历史记录已清理，保留20条');
        }

        await chrome.storage.local.set({
            conversationHistory: popup.conversationHistory
        });

        console.log('历史记录清理完成');
    } catch (error) {
        console.error('清理历史记录失败:', error);
    }
}

function showHistoryDialog(popup) {
    if (popup.historyDialog) {
        popup.historyDialog.style.display = 'flex';
        
        // 确保更新图标仍然可见（如果应该显示）
        if (popup.ensureUpdateIconVisible) {
            setTimeout(() => {
                popup.ensureUpdateIconVisible();
            }, 100);
        }
        
        loadHistoryList(popup);
    }
}

function hideHistoryDialog(popup) {
    if (popup.historyDialog) {
        popup.historyDialog.style.display = 'none';
    }
}

function loadHistoryList(popup) {
    const historyList = popup.historyList;
    if (!historyList) return;

    const total = popup.conversationHistory ? popup.conversationHistory.length : 0;
    const totalPages = Math.max(1, Math.ceil(total / HISTORY_PAGE_SIZE));
    if (popup.historyCurrentPage == null || popup.historyCurrentPage < 1) {
        popup.historyCurrentPage = 1;
    }
    if (popup.historyCurrentPage > totalPages) {
        popup.historyCurrentPage = totalPages;
    }
    const currentPage = popup.historyCurrentPage;

    historyList.innerHTML = '';

    if (total === 0) {
        const emptyTitle = popup.t('popup.history.emptyTitle');
        const emptySubtitle = popup.t('popup.history.emptySubtitle');
        historyList.innerHTML = `
            <div class="empty-history">
                <div class="empty-history-icon">📝</div>
                <div class="empty-history-text">${emptyTitle}</div>
                <div class="empty-history-subtext">${emptySubtitle}</div>
            </div>
        `;
        return;
    }

    const batchActionsDiv = document.createElement('div');
    batchActionsDiv.className = 'batch-actions';
    const selectAllText = popup.t('popup.history.selectAll');
    const initialExportText = popup.t('popup.history.batchExport', { count: 0 });
    const initialDeleteText = popup.t('popup.history.batchDelete', { count: 0 });
    batchActionsDiv.innerHTML = `
        <div class="batch-controls">
            <label class="select-all-label">
                <input type="checkbox" id="selectAllCheckbox">
                ${selectAllText}
            </label>
            <div class="batch-buttons">
                <button id="batchExportBtn" class="batch-export-btn" disabled>
                    ${initialExportText}
                </button>
                <button id="batchDeleteBtn" class="batch-delete-btn" disabled>
                    ${initialDeleteText}
                </button>
            </div>
        </div>
    `;
    historyList.appendChild(batchActionsDiv);

    const startIndex = (currentPage - 1) * HISTORY_PAGE_SIZE;
    const endIndex = Math.min(startIndex + HISTORY_PAGE_SIZE, total);
    const pageItems = popup.conversationHistory.slice(startIndex, endIndex);

    const itemsContainer = document.createElement('div');
    itemsContainer.className = 'history-list-items';
    pageItems.forEach((item, index) => {
        const globalIndex = startIndex + index;
        const historyItem = createHistoryItemElement(popup, item, globalIndex);
        itemsContainer.appendChild(historyItem);
    });
    historyList.appendChild(itemsContainer);

    const prevText = popup.t('popup.history.prevPage');
    const nextText = popup.t('popup.history.nextPage');
    const pageInfoText = popup.t('popup.history.pageInfo', {
        total: String(total),
        current: String(currentPage),
        totalPages: String(totalPages)
    });

    const paginationDiv = document.createElement('div');
    paginationDiv.className = 'history-pagination';
    const pageNumsFragment = document.createDocumentFragment();
    for (let p = 1; p <= totalPages; p++) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'history-page-btn' + (p === currentPage ? ' active' : '');
        btn.dataset.page = String(p);
        btn.textContent = p;
        pageNumsFragment.appendChild(btn);
    }
    paginationDiv.innerHTML = `
        <span class="history-pagination-info">${pageInfoText}</span>
        <div class="history-pagination-controls">
            <button type="button" class="history-pagination-prev" ${currentPage <= 1 ? ' disabled' : ''}>${prevText}</button>
            <span class="history-page-nums"></span>
            <button type="button" class="history-pagination-next" ${currentPage >= totalPages ? ' disabled' : ''}>${nextText}</button>
        </div>
    `;
    const pageNumsContainer = paginationDiv.querySelector('.history-page-nums');
    if (pageNumsContainer) {
        pageNumsContainer.appendChild(pageNumsFragment);
    }
    historyList.appendChild(paginationDiv);
}

function goToHistoryPage(popup, page) {
    const total = popup.conversationHistory ? popup.conversationHistory.length : 0;
    const totalPages = Math.max(1, Math.ceil(total / HISTORY_PAGE_SIZE));
    const pageNum = Math.max(1, Math.min(Number(page) || 1, totalPages));
    popup.historyCurrentPage = pageNum;
    loadHistoryList(popup);
}

function createHistoryItemElement(popup, item) {
    const div = document.createElement('div');
    div.className = 'history-item';
    const locale = popup.i18n?.getIntlLocale(popup.currentLanguage);

    const questionPreview = item.question.length > 50 ? item.question.substring(0, 50) + '...' : item.question;
    const answerPreview = item.answer.length > 100 ? item.answer.substring(0, 100) + '...' : item.answer;
    const time = new Date(item.timestamp).toLocaleString(locale);

    const deleteTitle = popup.t('popup.history.deleteSingleTitle');
    const continueTitle = popup.t('popup.history.continueConversation', '继续对话');
    const modelLabel = popup.t('popup.history.modelLabel');
    const knowledgeLabel = popup.t('popup.history.knowledgeLabel');
    const pageLabel = popup.t('popup.history.pageLabel');
    const questionLabel = popup.t('popup.history.questionLabel');
    const answerLabel = popup.t('popup.history.answerLabel');
    const fullQuestionLabel = popup.t('popup.history.fullQuestionLabel');
    const fullAnswerLabel = popup.t('popup.history.fullAnswerLabel');
    const checkboxAriaLabel = popup.t('popup.history.selectRecordAria', { time });

    // 所有历史记录都可以继续对话（即使没有保存的上下文，也可以从当前记录构建基础上下文）
    div.innerHTML = `
        <div class="history-header">
            <div class="history-time">
                <input type="checkbox" class="history-checkbox" data-id="${item.id}" aria-label="${checkboxAriaLabel}">
                ${time}
            </div>
            <div class="history-actions">
                <button class="history-action-btn continue-conversation-btn" data-id="${item.id}" title="${continueTitle}">
                    💬
                </button>
                <button class="history-action-btn delete-single-btn" data-id="${item.id}" title="${deleteTitle}">
                    🗑️
                </button>
            </div>
        </div>
        <div class="history-meta">
            <span class="history-model">${modelLabel} ${item.modelName}</span>
            ${item.knowledgeBaseName ? `<span class="history-knowledge-base">${knowledgeLabel} ${item.knowledgeBaseName}</span>` : ''}
        </div>
        <div class="history-question">
            <strong>${questionLabel}</strong> ${escapeHtml(questionPreview)}
        </div>
        <div class="history-answer">
            <strong>${answerLabel}</strong> ${escapeHtml(answerPreview)}
        </div>
        <div class="history-full-content" id="history-full-${item.id}" style="display: none;">
            <div class="history-full-question">
                <strong>${fullQuestionLabel}</strong><br>
                ${escapeHtml(item.question)}
            </div>
            <div class="history-full-answer">
                <strong>${fullAnswerLabel}</strong><br>
                ${escapeHtml(item.answer)}
            </div>
        </div>
    `;

    return div;
}

async function copyHistoryItem(popup, id) {
    try {
        const item = popup.conversationHistory.find(h => h.id === id);
        if (item) {
            const questionLabel = popup.t('popup.history.questionLabel');
            const answerLabel = popup.t('popup.history.answerLabel');
            const textToCopy = `${questionLabel} ${item.question}\n\n${answerLabel} ${item.answer}`;
            await navigator.clipboard.writeText(textToCopy);
            popup.showMessage(popup.t('popup.message.copied'), 'success');
        }
    } catch (error) {
        console.error('复制历史记录失败:', error);
        popup.showMessage(popup.t('popup.message.copyFailed'), 'error');
    }
}

async function deleteHistoryItem(popup, id) {
    try {
        const confirmMessage = popup.t('popup.history.confirmDeleteSingle');
        if (!confirm(confirmMessage)) {
            return;
        }

        popup.conversationHistory = popup.conversationHistory.filter(h => h.id !== id);
        popup.historyCurrentPage = 1;
        await chrome.storage.local.set({
            conversationHistory: popup.conversationHistory
        });
        loadHistoryList(popup);
        popup.showMessage(popup.t('popup.message.historyDeleted'), 'success');
    } catch (error) {
        console.error('删除历史记录失败:', error);
        popup.showMessage(popup.t('popup.message.deleteFailed'), 'error');
    }
}

function updateBatchButtons(popup) {
    const checkboxes = document.querySelectorAll('.history-checkbox:checked');
    const batchExportBtn = document.getElementById('batchExportBtn');
    const batchDeleteBtn = document.getElementById('batchDeleteBtn');

    const selectedCount = checkboxes.length;

    if (batchExportBtn) {
        batchExportBtn.disabled = selectedCount === 0;
        batchExportBtn.textContent = popup.t('popup.history.batchExport', { count: selectedCount });
    }

    if (batchDeleteBtn) {
        batchDeleteBtn.disabled = selectedCount === 0;
        batchDeleteBtn.textContent = popup.t('popup.history.batchDelete', { count: selectedCount });
    }
}

async function batchDeleteHistory(popup) {
    const checkboxes = document.querySelectorAll('.history-checkbox:checked');
    const selectedIds = Array.from(checkboxes).map(cb => cb.dataset.id);

    if (selectedIds.length === 0) {
        popup.showMessage(popup.t('popup.message.selectRecordsToDelete'), 'warning');
        return;
    }

    const confirmMessage = popup.t('popup.history.confirmDeleteSelected', { count: selectedIds.length });
    if (!confirm(confirmMessage)) {
        return;
    }

    try {
        popup.conversationHistory = popup.conversationHistory.filter(h => !selectedIds.includes(h.id));
        popup.historyCurrentPage = 1;
        await chrome.storage.local.set({
            conversationHistory: popup.conversationHistory
        });
        loadHistoryList(popup);
        popup.showMessage(popup.t('popup.message.deleteHistorySelectionSuccess', { count: selectedIds.length }), 'success');
    } catch (error) {
        console.error('批量删除历史记录失败:', error);
        popup.showMessage(popup.t('popup.message.batchDeleteFailed'), 'error');
    }
}

function toggleSelectAll(popup) {
    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
    const checkboxes = document.querySelectorAll('.history-checkbox');
    if (!selectAllCheckbox) return;

    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
    });

    updateBatchButtons(popup);
}

function toggleHistoryExpansion(_, id) {
    const fullContent = document.getElementById(`history-full-${id}`);
    if (fullContent) {
        fullContent.style.display = fullContent.style.display === 'none' ? 'block' : 'none';
    }
}

async function clearHistory(popup) {
    try {
        const confirmMessage = popup.t('popup.history.confirmClearAll');
        if (confirm(confirmMessage)) {
            popup.conversationHistory = [];
            popup.historyCurrentPage = 1;
            await chrome.storage.local.set({
                conversationHistory: []
            });
            loadHistoryList(popup);
            popup.showMessage(popup.t('popup.message.historyCleared'), 'success');
        }
    } catch (error) {
        console.error('清空历史记录失败:', error);
        if (error.message && error.message.includes('quota')) {
            console.log('检测到存储配额问题，尝试清理旧记录...');
            await cleanupHistoryRecords(popup);
            loadHistoryList(popup);
            popup.showMessage(popup.t('popup.message.historyCleaned'), 'info');
        } else {
            popup.showMessage(popup.t('popup.message.clearFailed'), 'error');
        }
    }
}

async function exportHistory(popup) {
    try {
        // 从 manifest.json 获取版本号
        const { getVersion } = await import('../../utils/version.js');
        const version = await getVersion();

        const exportData = {
            conversationHistory: popup.conversationHistory,
            exportTime: new Date().toISOString(),
            totalCount: popup.conversationHistory.length,
            version: version
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], {
            type: 'application/json'
        });

        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `bic-qa-history-all-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        popup.showMessage(popup.t('popup.message.exportAllHistorySuccess', { count: popup.conversationHistory.length }), 'success');
    } catch (error) {
        console.error('导出历史记录失败:', error);
        popup.showMessage(popup.t('popup.message.exportFailed'), 'error');
    }
}

async function batchExportHistory(popup) {
    const checkboxes = document.querySelectorAll('.history-checkbox:checked');
    const selectedIds = Array.from(checkboxes).map(cb => cb.dataset.id);

    if (selectedIds.length === 0) {
        popup.showMessage(popup.t('popup.message.selectRecordsToExport'), 'warning');
        return;
    }

    try {
        // 从 manifest.json 获取版本号
        const { getVersion } = await import('../../utils/version.js');
        const version = await getVersion();

        const selectedHistory = popup.conversationHistory.filter(h => selectedIds.includes(h.id));

        const exportData = {
            conversationHistory: selectedHistory,
            exportTime: new Date().toISOString(),
            totalCount: selectedHistory.length,
            selectedCount: selectedIds.length,
            version: version
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], {
            type: 'application/json'
        });

        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `bic-qa-history-selected-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        popup.showMessage(popup.t('popup.message.exportHistorySelectionSuccess', { count: selectedHistory.length }), 'success');
    } catch (error) {
        console.error('批量导出历史记录失败:', error);
        popup.showMessage(popup.t('popup.message.batchExportFailed'), 'error');
    }
}

/**
 * 继续历史对话
 * 从历史记录中恢复对话上下文，展示全部对话轮次，并注入关键词供后续问答延续思路
 */
async function continueConversation(popup, historyId) {
    try {
        const historyItem = popup.conversationHistory.find(h => h.id === historyId);
        if (!historyItem) {
            popup.showMessage(popup.t('popup.message.historyNotFound', '未找到历史记录'), 'error');
            return;
        }

        // 解析 turns（支持新格式与旧格式）
        let turns = historyItem.turns;
        if (!turns || !Array.isArray(turns) || turns.length === 0) {
            turns = [{
                question: historyItem.question || '',
                answer: historyItem.answer || '',
                keywords: ''
            }];
        }

        // 恢复 sessionHistory（展示用：全部轮次；API 会从 currentSessionHistory 取，在 request 里已有 limitHistoryLength）
        popup.currentSessionHistory = turnsToSessionHistory(turns, false);

        // 恢复 accumulatedKeywords 与 currentConversationTurns，用于后续问答
        popup.accumulatedKeywordsForNextQuery = historyItem.accumulatedKeywords || '';
        popup.currentConversationTurns = JSON.parse(JSON.stringify(turns));
        popup.currentHistorySessionId = historyItem.id;

        // 恢复模型选择
        if (popup.modelSelect) {
            let modelValue = null;
            if (historyItem.modelKey) {
                const modelOption = Array.from(popup.modelSelect.options).find(opt => opt.value === historyItem.modelKey);
                if (modelOption) modelValue = historyItem.modelKey;
            }
            if (!modelValue && historyItem.modelName && popup.models) {
                const displayText = historyItem.modelName;
                const modelOption = Array.from(popup.modelSelect.options).find(opt => {
                    const text = `${opt.textContent}`.trim();
                    return text === displayText || text.includes(displayText) || displayText.includes(text);
                });
                if (modelOption) modelValue = modelOption.value;
            }
            if (modelValue) {
                popup.modelSelect.value = modelValue;
                console.log('已恢复模型选择');
            }
        }

        // 恢复知识库选择
        if (historyItem.knowledgeBaseId && popup.knowledgeBaseSelect) {
            const kbId = typeof historyItem.knowledgeBaseId === 'string' && historyItem.knowledgeBaseId.startsWith('{')
                ? (() => { try { return JSON.parse(historyItem.knowledgeBaseId).id; } catch { return historyItem.knowledgeBaseId; } })()
                : historyItem.knowledgeBaseId;
            const kbOption = Array.from(popup.knowledgeBaseSelect.options).find(opt => {
                if (!opt.value) return false;
                try {
                    const v = JSON.parse(opt.value);
                    return v && (v.id === kbId || String(v.id) === String(kbId));
                } catch { return opt.value === historyItem.knowledgeBaseId; }
            });
            if (kbOption) {
                popup.knowledgeBaseSelect.value = kbOption.value;
                console.log('已恢复知识库选择:', historyItem.knowledgeBaseName || kbId);
            }
        } else if (popup.knowledgeBaseSelect && (!historyItem.knowledgeBaseId || historyItem.knowledgeBaseId === '')) {
            popup.knowledgeBaseSelect.value = '';
        }

        if (popup.updateCharacterCount) popup.updateCharacterCount();

        // 关闭历史对话框
        hideHistoryDialog(popup);

        // 确保结果容器可见
        if (popup.resultContainer) {
            popup.resultContainer.style.display = 'block';
        }

        // 关键：更新布局状态，使 content-area 从 no-result 变为 has-result
        // 否则 .content-area.no-result .result-section { display: none } 会隐藏整个结果区域
        if (popup.updateLayoutState) {
            popup.updateLayoutState();
        }

        // 清空当前结果显示区域，准备显示历史对话
        // 注意：先清空，再显示历史对话
        if (popup.resultContainer) {
            popup.resultContainer.innerHTML = '';
        }

        // 显示历史对话内容
        if (popup.currentSessionHistory && popup.currentSessionHistory.length > 0) {
            console.log('开始显示历史对话内容，共', popup.currentSessionHistory.length, '条消息');

            // 遍历历史对话，每对用户问题和AI回答显示为一个对话容器
            for (let i = 0; i < popup.currentSessionHistory.length; i += 2) {
                const userMessage = popup.currentSessionHistory[i];
                const assistantMessage = popup.currentSessionHistory[i + 1];

                if (userMessage && userMessage.role === 'user' && assistantMessage && assistantMessage.role === 'assistant') {
                    // 创建新的对话容器
                    let conversationContainer;
                    if (i === 0) {
                        // 第一条对话使用默认容器
                        conversationContainer = popup.createNewConversationContainer();
                        // 将默认容器的ID改为conversation-default
                        conversationContainer.id = 'conversation-default';
                    } else {
                        // 后续对话创建新容器
                        conversationContainer = popup.createNewConversationContainer();
                    }

                    // 确保容器已添加到DOM
                    if (!popup.resultContainer.contains(conversationContainer)) {
                        popup.resultContainer.appendChild(conversationContainer);
                    }

                    // 显示用户问题
                    popup.updateQuestionDisplay(userMessage.content, conversationContainer);

                    // 显示 AI 头像区域（与正常问答流程一致）
                    if (popup.updateAIDisplay) {
                        popup.updateAIDisplay(conversationContainer);
                    }

                    // 显示AI回答（使用setTimeout确保DOM更新后再渲染）
                    setTimeout(() => {
                        popup.showResult(assistantMessage.content, conversationContainer);
                    }, 50);

                    console.log(`已显示历史对话 ${i / 2 + 1}: 用户问题="${userMessage.content.substring(0, 50)}..."`);
                }
            }

            console.log('历史对话内容显示完成');

            // 滚动到底部
            setTimeout(() => {
                if (popup.scrollToBottom) {
                    popup.scrollToBottom();
                } else if (popup.resultContainer) {
                    popup.resultContainer.scrollTop = popup.resultContainer.scrollHeight;
                }
            }, 200);
        }

        // 显示提示消息
        const continueMessage = popup.t('popup.message.continueConversationStarted', '已恢复历史对话上下文，您可以继续提问');
        popup.showMessage(continueMessage, 'success');

        // 聚焦输入框，允许用户继续提问
        if (popup.questionInput) {
            popup.questionInput.focus();
        }

        console.log('继续对话功能已启动，当前会话历史:', popup.currentSessionHistory);
    } catch (error) {
        console.error('继续对话失败:', error);
        popup.showMessage(popup.t('popup.message.continueConversationFailed', '继续对话失败') + ': ' + error.message, 'error');
    }
}
