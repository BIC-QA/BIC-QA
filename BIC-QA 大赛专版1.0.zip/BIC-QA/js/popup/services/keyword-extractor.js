/**
 * 关键词提取服务
 * 从每次问答中提取核心关键词，用于后续对话的上下文延续
 */

const KEYWORD_PROMPT = `根据以下问答内容，提取3-5个能够概括这次对话核心思想的关键词，用于后续对话延续上下文。
仅输出关键词，用中文逗号或英文逗号分隔，不要输出任何其他内容、标点或解释。

问：
{{question}}

答：
{{answer}}`;

const MAX_CONTENT_LENGTH = 1500; // 防止内容过长超出 token 限制

/**
 * 使用大模型提取问答关键词
 * @param {Object} popup - popup 实例
 * @param {string} question - 用户问题
 * @param {string} answer - AI 回答
 * @param {Object} provider - API 服务商
 * @param {Object} model - 模型配置
 * @returns {Promise<string>} 关键词字符串，失败返回空字符串
 */
export async function extractKeywords(popup, question, answer, provider, model) {
    if (!question && !answer) return '';
    if (!provider || !model) return '';

    try {
        const safeQ = String(question || '').trim();
        const safeA = String(answer || '').trim();
        const truncatedQ = safeQ.length > MAX_CONTENT_LENGTH ? safeQ.substring(0, MAX_CONTENT_LENGTH) + '...' : safeQ;
        const truncatedA = safeA.length > MAX_CONTENT_LENGTH ? safeA.substring(0, MAX_CONTENT_LENGTH) + '...' : safeA;

        const prompt = KEYWORD_PROMPT
            .replace('{{question}}', truncatedQ)
            .replace('{{answer}}', truncatedA);

        const endpoint = provider.apiEndpoint?.includes('/chat/completions')
            ? provider.apiEndpoint
            : (provider.apiEndpoint || '') + '/chat/completions';

        const requestBody = {
            model: model.name,
            messages: [
                { role: 'system', content: '你只输出关键词，不输出任何其他内容。' },
                { role: 'user', content: prompt }
            ],
            max_tokens: 150,
            temperature: 0.2
        };

        const fetchOptions = popup.requestUtil?.buildFetchOptions?.(endpoint, {
            method: 'POST',
            body: requestBody,
            provider: provider
        }) || { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(requestBody) };

        const response = await fetch(endpoint, fetchOptions);
        if (!response.ok) {
            console.warn('关键词提取 API 失败:', response.status);
            return '';
        }

        const data = await response.json();
        let text = '';
        if (data.choices?.[0]?.message?.content) {
            text = data.choices[0].message.content.trim();
        } else if (data.response) {
            text = String(data.response).trim();
        } else if (data.content) {
            text = String(data.content).trim();
        }

        if (!text) return '';

        // 规范化：去除多余空格和换行，保留逗号分隔
        const keywords = text
            .replace(/[\r\n]+/g, ',')
            .split(/[,，、;；]/)
            .map(k => k.trim())
            .filter(k => k.length > 0)
            .slice(0, 5); // 最多 5 个

        return keywords.join(', ');
    } catch (err) {
        console.warn('关键词提取失败:', err);
        return '';
    }
}
