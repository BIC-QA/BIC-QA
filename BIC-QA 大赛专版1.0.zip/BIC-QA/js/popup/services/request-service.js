import {
    FIXED_CHAT_API_KEY,
    FIXED_CHAT_COMPLETIONS_URL,
    FIXED_CHAT_MODEL
} from '../constants/fixed-chat-api.js';
import { accumulateOpenAIChatCompletionSSE } from '../utils/openai-stream-read.js';

export function createRequestService(popup, streamService) {
    const COMPETITION_CHAT_URL = FIXED_CHAT_COMPLETIONS_URL;
    const COMPETITION_CHAT_API_KEY = FIXED_CHAT_API_KEY;
    const COMPETITION_CHAT_MODEL = FIXED_CHAT_MODEL;

    // 去掉markdown图片语法，避免图片地址影响大模型思考

    // 去掉markdown图片语法，避免图片地址影响大模型思考
    function removeMarkdownImages(content) {
        if (!content) return content;
        // 匹配markdown图片语法：![alt text](url) 或 ![](url)
        // 使用非贪婪匹配，确保只匹配一个图片语法
        // 移除图片语法后，清理多余的空白字符
        return content.replace(/!\[.*?\]\([^)]+\)/g, '').replace(/\n{3,}/g, '\n\n').trim();
    }

    async function callCompetitionChat(message, container = null, originalQuestion = null) {
        popup.startTime = Date.now();
        popup.hasBeenStopped = false;
        popup._useKnowledgeBaseThisTime = false;
        popup._kbMatchCount = 0;
        popup._kbItems = [];
        popup._kbImageList = [];

        const displayQuestion = originalQuestion || message;
        let conversationContainer = container;

        if (!conversationContainer) {
            conversationContainer = popup.getCurrentConversationContainer?.()
                || popup.resultContainer?.querySelector?.('#conversation-default')
                || popup.createNewConversationContainer?.();
        }

        popup.updateQuestionDisplay(displayQuestion, conversationContainer);
        popup.updateAIDisplay(conversationContainer);
        popup.updateLayoutState?.();

        const resultText = conversationContainer?.querySelector?.('.result-text');
        if (resultText) {
            let tipsEl = resultText.querySelector('.result-text-tips');
            if (!tipsEl) {
                tipsEl = document.createElement('p');
                tipsEl.className = 'result-text-tips';
                resultText.appendChild(tipsEl);
            }
            tipsEl.textContent = popup.t('popup.progress.processing');
        }

        const resultTitle = conversationContainer?.querySelector?.('.result-title');
        if (resultTitle) {
            resultTitle.textContent = popup.t('popup.progress.generating');
        }

        const response = await fetch(COMPETITION_CHAT_URL, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${COMPETITION_CHAT_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: COMPETITION_CHAT_MODEL,
                stream: true,
                messages: [
                    {
                        role: 'user',
                        content: message
                    }
                ]
            })
        });

        if (!response.ok) {
            let errorText = '';
            try {
                errorText = await response.text();
            } catch (_) {
                errorText = response.statusText || popup.t('popup.common.unknownError');
            }
            throw new Error(`HTTP ${response.status}: ${errorText}`);
        }

        const ct = (response.headers.get('content-type') || '').toLowerCase();
        const fallbackResponse = response.clone();

        if (ct.includes('text/event-stream')) {
            let answer = await streamService.handleStreamResponse(
                response,
                conversationContainer,
                displayQuestion,
                null,
                null
            );
            answer = String(answer || '').trim();
            if (!answer) {
                answer = await recoverNonStreamAnswerFromClone(fallbackResponse, popup, conversationContainer);
            }
            if (!answer) {
                throw new Error('接口未返回有效回答内容');
            }
            return answer;
        }

        const rawText = await response.text();
        const trimmed = rawText.trim();
        if (trimmed.startsWith('data:')) {
            const answer = await accumulateOpenAIChatCompletionSSE(
                new Response(rawText, { headers: { 'Content-Type': 'text/event-stream' } })
            );
            const finalAnswer = String(answer || '').trim();
            if (!finalAnswer) {
                throw new Error('接口未返回有效回答内容');
            }
            popup.showResult(finalAnswer, conversationContainer);
            return finalAnswer;
        }

        try {
            const result = JSON.parse(trimmed);
            const answer = String(result?.choices?.[0]?.message?.content || '').trim();
            if (!answer) {
                throw new Error('接口未返回有效回答内容');
            }
            popup.showResult(answer, conversationContainer);
            return answer;
        } catch (e) {
            if (e.message === '接口未返回有效回答内容') {
                throw e;
            }
            throw new Error(
                popup.t('popup.error.modelCallFailed') + ': ' + (e.message || String(e))
            );
        }
    }

    async function recoverNonStreamAnswerFromClone(cloned, popup, conversationContainer) {
        try {
            const result = await cloned.json();
            const answer = String(result?.choices?.[0]?.message?.content || '').trim();
            if (answer) {
                popup.showResult(answer, conversationContainer);
                return answer;
            }
        } catch (_) {
            /* fall through */
        }
        try {
            const txt = await cloned.text();
            const answer = String(
                (await accumulateOpenAIChatCompletionSSE(new Response(txt))) || ''
            ).trim();
            if (answer) {
                popup.showResult(answer, conversationContainer);
                return answer;
            }
        } catch (_) {
            /* empty */
        }
        return '';
    }

    async function callAIAPI(question, pageContent, pageUrl, provider, model, knowledgeBaseId = null, parameterRule = null, container = null, originalQuestion = null) {
        console.log('callAIAPI=======');

        // 检查输入问题是否为乱码标识
        if (question && (
            question.includes('当前问题为乱码') ||
            question.includes('当前内容为乱码') ||
            question.includes('Current question is gibberish') ||
            question.includes('Current content is gibberish') ||
            question.includes('現在の質問は乱雑') ||
            question.includes('現在のコンテンツは乱雑')
        )) {
            console.warn('检测到乱码标识作为API输入:', question);

            // 创建错误提示容器
            const targetContainer = container || popup.resultContainer;
            const conversationContainer = popup.createNewConversationContainer();
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.style.cssText = `
                background: #fff3cd;
                color: #856404;
                border: 1px solid #ffeaa7;
                border-radius: 6px;
                padding: 16px 20px;
                margin: 10px 0;
                font-size: 14px;
                text-align: center;
            `;
            errorDiv.innerHTML = `
                <div style="font-weight: 600; margin-bottom: 8px;">🚫 检测到乱码输入</div>
                <div>AI检测到您的输入可能包含乱码或无效内容，无法进行有效问答。</div>
                <div style="margin-top: 8px; font-size: 12px; color: #533f00;">
                    请检查输入内容，确保包含有效的文本后再试。
                </div>
            `;

            conversationContainer.appendChild(errorDiv);

            // 显示错误提示
            popup.showMessage('输入内容检测为乱码，请重新输入有效的问题', 'error');
            return;
        }

        // 注意：前端乱码检测现在在handleAskQuestion中进行，这里不再重复检测
        // 这样可以避免重复显示错误提示

        popup._useKnowledgeBaseThisTime = false;
        popup._kbMatchCount = 0;

        const isFirstConversation = popup.currentSessionHistory.length === 0;
        let conversationContainer;

        if (container) {
            conversationContainer = container;
            console.log('使用传入的容器:', conversationContainer);
        } else if (isFirstConversation) {
            conversationContainer = popup.resultContainer.querySelector('#conversation-default');
            if (conversationContainer) {
                popup.resultContainer.style.display = 'block';
            }
        } else {
            conversationContainer = popup.createNewConversationContainer();
        }

        console.log("-----question", question);
        console.log("-----originalQuestion", originalQuestion);
        console.log("-----pageContent", pageContent);
        console.log("-----pageUrl", pageUrl);
        console.log("-----provider", provider);
        console.log("-----model", model);

        // 使用原始问题显示，如果没有提供原始问题则使用翻译后的问题
        const displayQuestion = originalQuestion || question;
        popup.updateQuestionDisplay(displayQuestion, conversationContainer);
        popup.updateAIDisplay(conversationContainer);

        const resultText = conversationContainer.querySelector('.result-text');
        if (resultText) {
            let tipsEl = resultText.querySelector('.result-text-tips');
            if (!tipsEl) {
                tipsEl = document.createElement('p');
                tipsEl.className = 'result-text-tips';
                resultText.appendChild(tipsEl);
            }
            tipsEl.textContent = popup.t('popup.progress.processing');
            let contentEl = resultText.querySelector('.result-text-content');
            if (!contentEl) {
                contentEl = document.createElement('div');
                contentEl.className = 'result-text-content';
                resultText.appendChild(contentEl);
            }
        }

        const resultTitle = conversationContainer.querySelector('.result-title');
        if (resultTitle) {
            resultTitle.textContent = popup.t('popup.progress.generating');
        }

        popup.updateLayoutState();

        var context = `${popup.t('popup.context.pageUrl')}: ${pageUrl}\n${popup.t('popup.context.pageContent')}: ${pageContent.substring(0, 2000)}...`;
        let systemContent = popup.t('popup.system.aiAssistantPrompt');

        console.log('=== 参数规则调试信息 ===');
        console.log('parameterRule:', parameterRule);
        if (parameterRule) {
            console.log('parameterRule.similarity:', parameterRule.similarity);
            console.log('parameterRule.topN:', parameterRule.topN);
            console.log('parameterRule.temperature:', parameterRule.temperature);
        }
        console.log('========================');
        if (parameterRule && parameterRule.prompt) {
            let rulePrompt = parameterRule.prompt;
            rulePrompt = popup.applyLanguageInstructionToSystemContent(rulePrompt, displayQuestion || question);
            systemContent = `${rulePrompt}\n\n${systemContent}`;
        }

        if (knowledgeBaseId) {
            try {
                const knowledgeBase = JSON.parse(knowledgeBaseId);
                if (knowledgeBase.name) {
                    systemContent += `\n\n${popup.t('popup.system.knowledgeBasePrompt', { name: knowledgeBase.name })}`;
                }
            } catch (parseError) {
                const knowledgeBase = window.knowledgeBaseManager?.getKnowledgeBaseById(knowledgeBaseId);
                if (knowledgeBase) {
                    systemContent += `\n\n${popup.t('popup.system.knowledgeBasePrompt', { name: knowledgeBase.name })}`;
                }
            }
            context = `${popup.t('popup.context.baseContent')}:\n\n${context}\n\n${popup.t('popup.context.question')}:${question}`

            // 去掉markdown图片语法，避免图片地址影响大模型思考
            context = removeMarkdownImages(context);
        } else {
            context = `${question}`;
        }

        // 注入前序对话关键词，供大模型延续上下文与思路
        if (popup.accumulatedKeywordsForNextQuery && popup.accumulatedKeywordsForNextQuery.trim()) {
            systemContent += `\n\n## 前序对话核心关键词（请在此次回答中延续这些上下文与思路）\n${popup.accumulatedKeywordsForNextQuery.trim()}`;
        }

        console.log('知识库处理后的systemContent:', systemContent);
        systemContent = popup.applyLanguageInstructionToSystemContent(systemContent, displayQuestion || question);

        const messages = [
            {
                role: "system",
                content: systemContent
            }
        ];

        // 将历史对话添加到messages数组中，作为上下文
        if (popup.currentSessionHistory && popup.currentSessionHistory.length > 0) {
            console.log('添加历史对话到上下文:', popup.currentSessionHistory);
            // 将历史对话插入到system message之后
            messages.push(...popup.currentSessionHistory);
        }

        messages.push({
            role: "user",
            content: context
        });

        const requestBody = {
            model: model.name,
            messages: messages,
            max_tokens: model.maxTokens || 2048,
            temperature: model.temperature || 0.7,
            stream: true
        };
        if (parameterRule) {
            if (parameterRule.similarity !== undefined) {
                requestBody.similarity = parameterRule.similarity;
            }
            if (parameterRule.topN !== undefined) {
                requestBody.top_n = parameterRule.topN;
            }
            if (parameterRule.temperature !== undefined) {
                requestBody.temperature = parameterRule.temperature;
            }
            console.log('使用参数规则:', parameterRule);
        }
        if (knowledgeBaseId) {
            requestBody.knowledge_base_id = knowledgeBaseId;
        } else {
            requestBody.temperature = 0.7;
        }

        if (provider.apiEndpoint.indexOf("/chat/completions") > -1) {
            provider.apiEndpoint = provider.apiEndpoint
        } else {
            provider.apiEndpoint = provider.apiEndpoint + "/chat/completions"
        }
        try {
            if (requestBody.stream) {
                popup.abortController = new AbortController();
                const fetchOptions = popup.requestUtil.buildFetchOptions(provider.apiEndpoint, {
                    method: 'POST',
                    body: requestBody,
                    provider: provider,
                    signal: popup.abortController.signal
                });
                const response = await fetch(provider.apiEndpoint, fetchOptions);

                if (!response.ok) {
                    let errorText;
                    try {
                        errorText = await response.text();
                        console.error('API错误响应体:', errorText);
                    } catch (e) {
                        errorText = popup.t('popup.error.cannotReadErrorResponse');
                    }

                    let errorMessage;
                    if (response.status === 400) {
                        errorMessage = popup.t('popup.error.modelBadRequest');
                    } else if (response.status === 401) {
                        errorMessage = popup.t('popup.error.modelAuthFailed');
                    } else if (response.status === 403) {
                        errorMessage = popup.t('popup.error.modelPermissionDenied');
                    } else if (response.status === 404) {
                        errorMessage = popup.t('popup.error.modelNotFound');
                    } else if (response.status === 429) {
                        errorMessage = popup.t('popup.error.modelRateLimited');
                    } else if (response.status === 500) {
                        errorMessage = popup.t('popup.error.modelInternal');
                    } else if (response.status === 502 || response.status === 503 || response.status === 504) {
                        errorMessage = popup.t('popup.error.modelUnavailable');
                    } else {
                        errorMessage = popup.t('popup.error.modelRequestFailedStatus', { status: response.status, statusText: response.statusText });
                    }

                    if (errorText && errorText !== popup.t('popup.error.cannotReadErrorResponse')) {
                        errorMessage += '\n\n' + popup.t('popup.error.serverErrorDetails', { details: errorText });
                    }

                    throw new Error(errorMessage);
                }

                // 传递 provider 和 model 给流式处理函数，以便在流式过程中进行实时翻译
                const result = await streamService.handleStreamResponse(response, conversationContainer, displayQuestion || question, provider, model);
                
                // 使用原始问题保存到会话历史（流式处理函数已经处理了翻译后的内容）
                popup.addToCurrentSessionHistory(displayQuestion || question, result);
                return result;
            } else {
                const data = await popup.requestUtil.post(provider.apiEndpoint, requestBody, {
                    provider: provider
                });

                let result = '';
                if (data.choices && data.choices[0] && data.choices[0].message) {
                    result = data.choices[0].message.content;
                } else if (data.response) {
                    result = data.response;
                } else if (data.content) {
                    result = data.content;
                } else {
                    result = JSON.stringify(data);
                }

                // 如果用户选择的语言不是中文，需要将回答翻译回用户选择的语言（非流式响应）
                const targetLanguageName = popup.getLanguageDisplayName(popup.currentLanguage);
                const needsTranslation = popup.currentLanguage && popup.currentLanguage !== 'zhcn' && !targetLanguageName.includes('中文');
                
                if (needsTranslation && result && result.trim()) {
                    try {
                        console.log('开始翻译回答回用户选择的语言:', targetLanguageName);
                        const translatedAnswer = await popup.requestChatCompletionTranslation(
                            result,
                            provider,
                            model,
                            targetLanguageName
                        );
                        if (translatedAnswer && translatedAnswer.trim()) {
                            result = translatedAnswer.trim();
                            console.log('回答翻译完成');
                        }
                    } catch (translationError) {
                        console.error('翻译回答失败:', translationError);
                        // 翻译失败时继续使用原始结果
                    }
                }

                popup.showResult(result, conversationContainer);
                const resultActions = conversationContainer.querySelector('.result-actions');
                if (resultActions) {
                    resultActions.style.display = 'block';
                    setTimeout(() => {
                        resultActions.style.opacity = '1';
                    }, 100);
                }
                if (popup.startTime) {
                    const endTime = Date.now();
                    const duration = Math.round((endTime - popup.startTime) / 1000);
                    const resultTitle = conversationContainer.querySelector('.result-title');
                    if (resultTitle) {
                        resultTitle.textContent = popup.t('popup.progress.answerCompleted', { seconds: duration });
                    }
                }

                // 使用原始问题保存到会话历史
                popup.addToCurrentSessionHistory(displayQuestion || question, result);

                return result;
            }

        } catch (error) {
            console.error('API调用失败:', error);

            throw error;
        }
    }

    async function callOllamaAPI(question, pageContent, pageUrl, provider, model, knowledgeBaseId = null, parameterRule, container = null, originalQuestion = null) {
        console.log('callOllamaAPI=======');
        popup.startTime = Date.now();
        popup.hasBeenStopped = false;

        const isFirstConversation = popup.currentSessionHistory.length === 0;
        let conversationContainer;

        if (container) {
            conversationContainer = container;
            console.log('使用传入的容器:', conversationContainer);
        } else if (isFirstConversation) {
            conversationContainer = popup.resultContainer.querySelector('#conversation-default');
            if (conversationContainer) {
                popup.resultContainer.style.display = 'block';
            }
        } else {
            conversationContainer = popup.createNewConversationContainer();
        }
        
        // 使用原始问题显示，如果没有提供原始问题则使用翻译后的问题
        const displayQuestion = originalQuestion || question;

        console.log("-----question", question);
        console.log("-----originalQuestion", originalQuestion);
        console.log("-----displayQuestion", displayQuestion);
        console.log("-----pageContent", pageContent);
        console.log("-----pageUrl", pageUrl);
        console.log("-----provider", provider);
        console.log("-----model", model);

        popup.updateQuestionDisplay(displayQuestion, conversationContainer);
        popup.updateAIDisplay(conversationContainer);

        const resultText = conversationContainer.querySelector('.result-text');
        if (resultText) {
            let tipsEl = resultText.querySelector('.result-text-tips');
            if (!tipsEl) {
                tipsEl = document.createElement('p');
                tipsEl.className = 'result-text-tips';
                resultText.appendChild(tipsEl);
            }
            if (!tipsEl.textContent || tipsEl.textContent.trim() === '') {
                tipsEl.textContent = popup.t('popup.progress.processing');
            }
            let contentEl = resultText.querySelector('.result-text-content');
            if (!contentEl) {
                contentEl = document.createElement('div');
                contentEl.className = 'result-text-content';
                resultText.appendChild(contentEl);
            }
        }

        const resultTitle = conversationContainer.querySelector('.result-title');
        if (resultTitle) {
            resultTitle.textContent = popup.t('popup.progress.generating');
        }

        popup.updateLayoutState();

        var context = '';

        if (pageContent.includes('相似度：') || pageContent.includes('版本：')) {
            context = `${popup.t('popup.context.kbQueryResult')}:\n${pageContent}`;
            console.log(popup.t('popup.log.usingKbQueryResult'));
        } else {
            context = `${popup.t('popup.context.pageUrl')}: ${pageUrl}\n${popup.t('popup.context.pageContent')}: ${pageContent.substring(0, 2000)}...`;
            console.log(popup.t('popup.log.usingPageContent'));
        }

        let systemContent = popup.t('popup.system.aiAssistantPromptGeneral');

        console.log('=== 参数规则调试信息 ===');
        console.log('parameterRule:', parameterRule);
        if (parameterRule) {
            console.log('parameterRule.prompt:', parameterRule.prompt);
            console.log('parameterRule.similarity:', parameterRule.similarity);
            console.log('parameterRule.topN:', parameterRule.topN);
            console.log('parameterRule.temperature:', parameterRule.temperature);
        }
        console.log('========================');
        console.log('知识库处理后的systemContent:', systemContent);
        // 使用原始问题来应用语言指令（用于判断是否需要翻译）
        systemContent = popup.applyLanguageInstructionToSystemContent(systemContent, displayQuestion || question);

        if (parameterRule && parameterRule.prompt) {
            let rulePrompt = parameterRule.prompt;
            // 使用原始问题来应用语言指令
            rulePrompt = popup.applyLanguageInstructionToSystemContent(rulePrompt, displayQuestion || question);
            systemContent = `${rulePrompt}\n\n${systemContent}`;
        }
        if (knowledgeBaseId) {
            try {
                const knowledgeBase = JSON.parse(knowledgeBaseId);
                if (knowledgeBase.name) {
                    systemContent += `\n\n${popup.t('popup.system.knowledgeBasePrompt', { name: knowledgeBase.name })}`;
                }
            } catch (parseError) {
                const knowledgeBase = window.knowledgeBaseManager?.getKnowledgeBaseById(knowledgeBaseId);
                if (knowledgeBase) {
                    systemContent += `\n\n${popup.t('popup.system.knowledgeBasePrompt', { name: knowledgeBase.name })}`;
                }
            }
            context = `${popup.t('popup.context.baseContent')}:\n\n${context}\n\n${popup.t('popup.context.question')}:${question}`

            // 去掉markdown图片语法，避免图片地址影响大模型思考
            context = removeMarkdownImages(context);
        } else {
            systemContent = popup.t('popup.system.aiAssistantPrompt');
            context = `${question}`
        }

        // 注入前序对话关键词
        if (popup.accumulatedKeywordsForNextQuery && popup.accumulatedKeywordsForNextQuery.trim()) {
            systemContent += `\n\n## 前序对话核心关键词（请在此次回答中延续这些上下文与思路）\n${popup.accumulatedKeywordsForNextQuery.trim()}`;
        }

        console.log('知识库处理后的systemContent:', systemContent);

        const messages = [
            {
                role: "system",
                content: systemContent
            }
        ];

        // 将历史对话添加到messages数组中，作为上下文
        if (popup.currentSessionHistory && popup.currentSessionHistory.length > 0) {
            console.log('添加历史对话到上下文:', popup.currentSessionHistory);
            // 将历史对话插入到system message之后
            messages.push(...popup.currentSessionHistory);
        }

        messages.push({
            role: "user",
            content: context
        });

        const requestBody = {
            model: model.name,
            messages: messages,
            max_tokens: model.maxTokens || 2048,
            temperature: model.temperature || 0.7,
            stream: true
        };

        if (parameterRule) {
            if (parameterRule.similarity !== undefined) {
                requestBody.similarity = parameterRule.similarity;
            }
            if (parameterRule.topN !== undefined) {
                requestBody.top_n = parameterRule.topN;
            }
            if (parameterRule.temperature !== undefined) {
                requestBody.temperature = parameterRule.temperature;
            }
            console.log('使用参数规则:', parameterRule);
        }
        if (knowledgeBaseId) {
            requestBody.knowledge_base_id = knowledgeBaseId;
        } else {
            requestBody.temperature = 0.7;
        }

        if (provider.apiEndpoint.indexOf("/chat/completions") > -1) {
            provider.apiEndpoint = provider.apiEndpoint
        } else {
            provider.apiEndpoint = provider.apiEndpoint + "/chat/completions"
        }
        try {
            if (requestBody.stream) {
                popup.abortController = new AbortController();
                const fetchOptions = popup.requestUtil.buildFetchOptions(provider.apiEndpoint, {
                    method: 'POST',
                    body: requestBody,
                    provider: provider,
                    signal: popup.abortController.signal
                });
                const response = await fetch(provider.apiEndpoint, fetchOptions);

                if (!response.ok) {
                    let errorText;
                    try {
                        errorText = await response.text();
                        console.error('API错误响应体:', errorText);
                    } catch (e) {
                        errorText = popup.t('popup.error.cannotReadErrorResponse');
                    }

                    let errorMessage = popup.t('popup.error.apiRequestFailedBase', { status: response.status, statusText: response.statusText });

                    if (response.status === 400) {
                        errorMessage += '\n' + popup.t('popup.error.apiRequestFormatError');
                    } else if (response.status === 401) {
                        errorMessage += '\n' + popup.t('popup.error.apiAuthFailed');
                    } else if (response.status === 403) {
                        errorMessage += '\n' + popup.t('popup.error.apiPermissionDenied');
                    } else if (response.status === 404) {
                        errorMessage += '\n' + popup.t('popup.error.apiEndpointNotFound');
                    } else if (response.status === 429) {
                        errorMessage += '\n' + popup.t('popup.error.apiRateLimited');
                    }

                    if (errorText) {
                        errorMessage += '\n\n' + popup.t('popup.error.serverErrorDetails', { details: errorText });
                    }

                    throw new Error(errorMessage);
                }

                // 传递 provider 和 model 给流式处理函数，以便在流式过程中进行实时翻译
                const result = await streamService.handleStreamResponse(response, conversationContainer, displayQuestion || question, provider, model);
                
                // 使用原始问题保存到会话历史（流式处理函数已经处理了翻译后的内容）
                popup.addToCurrentSessionHistory(displayQuestion || question, result);
                return result;
            } else {
                const data = await popup.requestUtil.post(provider.apiEndpoint, requestBody, {
                    provider: provider
                });

                let result = '';
                if (data.choices && data.choices[0] && data.choices[0].message) {
                    result = data.choices[0].message.content;
                } else if (data.response) {
                    result = data.response;
                } else {
                    result = JSON.stringify(data);
                }

                // 如果用户选择的语言不是中文，需要将回答翻译回用户选择的语言（非流式响应）
                const targetLanguageName = popup.getLanguageDisplayName(popup.currentLanguage);
                const needsTranslation = popup.currentLanguage && popup.currentLanguage !== 'zhcn' && !targetLanguageName.includes('中文');
                
                if (needsTranslation && result && result.trim()) {
                    try {
                        console.log('开始翻译回答回用户选择的语言:', targetLanguageName);
                        const translatedAnswer = await popup.requestChatCompletionTranslation(
                            result,
                            provider,
                            model,
                            targetLanguageName
                        );
                        if (translatedAnswer && translatedAnswer.trim()) {
                            result = translatedAnswer.trim();
                            console.log('回答翻译完成');
                        }
                    } catch (translationError) {
                        console.error('翻译回答失败:', translationError);
                        // 翻译失败时继续使用原始结果
                    }
                }

                popup.showResult(result, conversationContainer);
                const resultActions = conversationContainer.querySelector('.result-actions');
                if (resultActions) {
                    resultActions.style.display = 'block';
                    setTimeout(() => {
                        resultActions.style.opacity = '1';
                    }, 100);
                }
                if (popup.startTime) {
                    const endTime = Date.now();
                    const duration = Math.round((endTime - popup.startTime) / 1000);
                    const resultTitle = conversationContainer.querySelector('.result-title');
                    if (resultTitle) {
                        resultTitle.textContent = popup.t('popup.progress.answerCompleted', { seconds: duration });
                    }
                }

                // 使用原始问题保存到会话历史
                popup.addToCurrentSessionHistory(displayQuestion || question, result);

                return result;
            }

        } catch (error) {
            if (error.name === 'AbortError') {
                console.log('流式回答请求已中止');
                return '';
            }
            console.error('API调用失败:', error);

            let errorMessage = popup.t('popup.error.modelCallFailed');

            if (error.message.includes(popup.t('popup.error.apiRequestFailedBase', { status: '', statusText: '' }).replace('{{status}}', '').replace('{{statusText}}', '')) || error.message.includes('API请求失败:')) {
                const detail = error.message.replace(/API请求失败:?\s*/i, '').trim();
                errorMessage = popup.t('popup.error.modelRequestFailed') + ': ' + detail;
            } else if (error.message.includes('API调用失败:')) {
                const detail = error.message.replace('API调用失败:', '').trim();
                errorMessage = popup.t('popup.error.modelCallFailed') + ': ' + detail;
            } else if (error.message.includes('网络') || error.message.includes('连接')) {
                errorMessage = popup.t('popup.error.modelNetworkFailed');
            } else {
                errorMessage = error.message;
            }

            throw new Error(errorMessage);
        }
    }

    async function streamChatWithConfig(message, model, provider, knowledgeBaseId = null, parameterRule = null, container = null, originalQuestion = null) {
        // 检查输入消息是否为乱码标识
        if (message && (
            message.includes('当前问题为乱码') ||
            message.includes('当前内容为乱码') ||
            message.includes('Current question is gibberish') ||
            message.includes('Current content is gibberish') ||
            message.includes('現在の質問は乱雑') ||
            message.includes('現在のコンテンツは乱雑')
        )) {
            console.warn('检测到乱码标识作为输入消息:', message);

            // 创建错误提示容器
            const targetContainer = container || popup.resultContainer;
            const conversationContainer = popup.createNewConversationContainer();
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.style.cssText = `
                background: #fff3cd;
                color: #856404;
                border: 1px solid #ffeaa7;
                border-radius: 6px;
                padding: 16px 20px;
                margin: 10px 0;
                font-size: 14px;
                text-align: center;
            `;
            errorDiv.innerHTML = `
                <div style="font-weight: 600; margin-bottom: 8px;">🚫 检测到乱码输入</div>
                <div>AI检测到您的输入可能包含乱码或无效内容，无法进行有效问答。</div>
                <div style="margin-top: 8px; font-size: 12px; color: #533f00;">
                    请检查输入内容，确保包含有效的文本后再试。
                </div>
            `;

            conversationContainer.appendChild(errorDiv);

            // 显示错误提示
            popup.showMessage('输入内容检测为乱码，请重新输入有效的问题', 'error');
            return;
        }

        try {
            return await callCompetitionChat(message, container, originalQuestion);
        } catch (error) {
            console.error('比赛专用问答接口调用失败:', error);
            throw new Error(`问答接口调用失败: ${error.message}`);
        }
    }

    async function streamChat(message, streamUrl = null, apiKey = null, knowledgeBaseId = null, parameterRule = null, model = null, provider = null, container = null, originalQuestion = null) {
        popup.startTime = Date.now();
        popup.hasBeenStopped = false;
        popup._useKnowledgeBaseThisTime = false;

        if (!streamUrl) {
            popup.showMessage(popup.t('popup.message.configureStreamUrl'), 'error');
            throw new Error(popup.t('popup.message.configureStreamUrl'));
        }

        try {
            const displayQuestion = originalQuestion || message;

            console.log(popup.t('popup.log.startKbQuery'), message);
            console.log(popup.t('popup.log.usingConfigStreamUrl'), streamUrl);
            console.log('knowledgeBaseId:', knowledgeBaseId);
            console.log('parameterRule:', parameterRule);
            console.log('model:', model);
            console.log('provider:', provider);
            console.log('displayQuestion:', displayQuestion);

            let userEmail = null;
            let userName = null;
            try {
                const result = await chrome.storage.sync.get(['registration']);
                const registration = result.registration;
                if (registration && registration.status === 'registered') {
                    userEmail = registration.email;
                    userName = registration.username;
                    console.log(popup.t('popup.log.registrationInfoRetrieved'), { email: userEmail, name: userName });
                } else {
                    console.log(popup.t('popup.log.noValidRegistrationInfo'));
                }
            } catch (error) {
                console.error(popup.t('popup.log.registrationInfoFailed'), error);
            }

            const requestBody = {
                question: message,
                similarity: 0.8,
                topn: 4,
                dataset_name: null,
                temperature: 0.7,
                language: popup.getAcceptLanguage(),
                isSupportImg: "true"
            };

            if (knowledgeBaseId) {
                try {
                    const knowledgeBase = JSON.parse(knowledgeBaseId);
                    if (knowledgeBase.id) {
                        requestBody.dataset_name = knowledgeBase.id;
                        console.log(popup.t('popup.log.usingKbIdAsDataset'), knowledgeBase.id);
                    } else {
                        requestBody.dataset_name = knowledgeBase.dataset_name;
                        console.log(popup.t('popup.log.usingKbDatasetNameAsFallback'), knowledgeBase.dataset_name);
                    }
                } catch (parseError) {
                    requestBody.dataset_name = knowledgeBaseId;
                    console.log(popup.t('popup.log.usingOriginalKbIdAsDataset'), knowledgeBaseId);
                }
            }

            if (parameterRule) {
                if (parameterRule.temperature !== undefined) {
                    requestBody.temperature = parameterRule.temperature;
                }
                if (parameterRule.similarity !== undefined) {
                    requestBody.similarity = parameterRule.similarity;
                }
                if (parameterRule.topN !== undefined) {
                    requestBody.topn = parameterRule.topN;
                }
                console.log(popup.t('popup.log.usingParameterRule'), parameterRule);
            }

            console.log(popup.t('popup.log.finalRequestBody'), requestBody);

            // 直接使用fetch进行请求，不依赖requestUtil的baseURL机制
            const headers = {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            };

            console.log('发送知识库查询请求到:', streamUrl);
            const response = await fetch(streamUrl, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) {
                let errorText = '';
                try {
                    errorText = await response.text();
                } catch (e) {
                    errorText = '无法读取错误响应';
                }
                throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText}`);
            }

            const responseData = await response.json();
            console.log(popup.t('popup.log.kbQueryResponse'), responseData);

            if (responseData.status !== "200") {
                throw new Error(popup.t('popup.error.kbQueryFailedDetail', { detail: responseData.message || popup.t('popup.common.unknownError') }));
            }

            let contextContent = '';
            let matchCount = 0;
            let knowledgeItems = [];
            let imageList = [];

            // 根据请求参数判断响应格式
            // 如果请求包含isSupportImg="true"，则使用新格式（data.dataList和data.imageList）
            // 否则使用旧格式（data直接是数组）
            if (requestBody.isSupportImg === "true") {
                // 新版本格式：data包含dataList和imageList
                console.log('使用新版本响应格式解析');

                // 提取 imageList
                if (responseData.data && responseData.data.imageList && Array.isArray(responseData.data.imageList)) {
                    imageList = responseData.data.imageList;
                    console.log('提取到图片列表:', imageList);
                }

                // 从 data.dataList 获取知识库数据
                if (responseData.data && responseData.data.dataList && Array.isArray(responseData.data.dataList)) {
                    knowledgeItems = responseData.data.dataList.map(item => (typeof item === 'string' ? item : String(item)));
                    // 过滤掉markdown图片语法，避免图片地址影响大模型思考
                    knowledgeItems = knowledgeItems.map(item => removeMarkdownImages(item));
                } else {
                    console.warn(popup.t('popup.log.noDataListInResponse'));
                    knowledgeItems = [];
                }
            } else {
                // 旧版本格式：data直接是数组
                console.log('使用旧版本响应格式解析');

                if (responseData.data && Array.isArray(responseData.data)) {
                    knowledgeItems = responseData.data.map(item => (typeof item === 'string' ? item : String(item)));
                    // 过滤掉markdown图片语法，避免图片地址影响大模型思考
                    knowledgeItems = knowledgeItems.map(item => removeMarkdownImages(item));
                } else {
                    console.warn(popup.t('popup.log.noDataArrayInResponse'));
                    knowledgeItems = [];
                }
                imageList = []; // 旧版本没有图片列表
            }

            // 处理知识库数据（翻译等）
            if (knowledgeItems.length > 0) {
                const targetLanguageName = popup.getLanguageDisplayName(popup.currentLanguage);
                // 强制检查是否需要翻译：当前语言不是中文，或者知识项看起来是中文的
                const currentLang = popup.currentLanguage || 'zhcn';
                const hasChineseContent = knowledgeItems.some(item =>
                    item && typeof item === 'string' && popup.isLikelyChinese(item)
                );
                const needContextTranslation = currentLang !== 'zhcn' || hasChineseContent;

                console.log('知识库翻译调试信息:');
                console.log('- currentLanguage:', currentLang);
                console.log('- targetLanguageName:', targetLanguageName);
                console.log('- hasChineseContent:', hasChineseContent);
                console.log('- needContextTranslation:', needContextTranslation);
                console.log('- provider:', provider);
                console.log('- model:', model);
                console.log('- knowledgeItems.length:', knowledgeItems.length);
                console.log('- knowledgeItems sample:', knowledgeItems.slice(0, 2));

                if (needContextTranslation) {
                    try {
                        console.log('开始翻译知识库内容...');
                        knowledgeItems = await popup.translateKnowledgeItems(knowledgeItems, targetLanguageName, provider, model);
                        console.log('知识库内容翻译完成，翻译后样本:', knowledgeItems.slice(0, 2));
                    } catch (error) {
                        console.error(popup.t('popup.log.kbContentTranslationFailed'), error);
                        console.error('翻译失败详情:', error.message);
                        // 如果翻译失败但当前语言不是中文，尝试使用备用翻译逻辑
                        if (currentLang !== 'zhcn') {
                            console.log('尝试备用翻译逻辑...');
                            try {
                                // 这里可以添加备用翻译逻辑，比如使用不同的provider
                            } catch (fallbackError) {
                                console.error('备用翻译也失败:', fallbackError.message);
                            }
                        }
                    }
                }

                contextContent = knowledgeItems.join('\n\n');
                matchCount = knowledgeItems.length;
                popup._kbItems = knowledgeItems;
                popup._kbImageList = imageList; // 保存图片列表
                console.log(popup.t('popup.log.extractedKbContent'), contextContent);
            } else {
                popup._kbItems = [];
                popup._kbImageList = [];
            }

            popup._useKnowledgeBaseThisTime = !!knowledgeBaseId;
            popup._kbMatchCount = matchCount;

            console.log(popup.t('popup.log.streamChatKbStatus'));
            console.log('knowledgeBaseId:', knowledgeBaseId);
            console.log('_useKnowledgeBaseThisTime:', popup._useKnowledgeBaseThisTime);
            console.log('_kbMatchCount:', popup._kbMatchCount);
            console.log('_kbItems:', popup._kbItems);
            console.log('_kbItems.length:', popup._kbItems ? popup._kbItems.length : 'null');

            if (knowledgeBaseId) {
                const targetContainer = container || popup.resultContainer;
                const resultText = targetContainer ? targetContainer.querySelector('.result-text') : popup.resultText;
                const tipsEl = resultText?.querySelector('.result-text-tips');
                if (tipsEl) {
                    tipsEl.innerHTML = popup.t('popup.progress.kbSearching', { count: matchCount });
                }
            }

            if (knowledgeBaseId && matchCount === 0) {
                const targetContainer = container || popup.resultContainer;
                const resultText = targetContainer ? targetContainer.querySelector('.result-text') : popup.resultText;
                const tipsEl = resultText?.querySelector('.result-text-tips');
                if (tipsEl) {
                    tipsEl.innerHTML = popup.t('popup.progress.kbNoMatch', { count: matchCount });
                }
                const knowlistEl = resultText?.querySelector('.result-text-knowlist');
                if (knowlistEl) {
                    knowlistEl.innerHTML = '';
                }
                if (popup.startTime) {
                    const endTime = Date.now();
                    const duration = Math.round((endTime - popup.startTime) / 1000);
                    const resultTitle = targetContainer ? targetContainer.querySelector('.result-title') : document.querySelector('.result-title');
                    if (resultTitle) {
                        resultTitle.textContent = popup.t('popup.progress.answerCompleted', { seconds: duration });
                    }
                }
                return '';
            }

            if (!contextContent.trim()) {
                console.log(popup.t('popup.log.noKbContent'));
                contextContent = pageContent || popup.t('popup.error.cannotGetPageContent');
            }

            console.log(popup.t('popup.log.startCallOllamaApi'));
            try {
                let finalAnswer = await callOllamaAPI(
                    displayQuestion,
                    contextContent,
                    window.location.href,
                    provider,
                    model,
                    knowledgeBaseId,
                    parameterRule,
                    container
                );

                const targetLanguageName = popup.getLanguageDisplayName(popup.currentLanguage);
                const needsTranslation = popup.currentLanguage && popup.currentLanguage !== 'zhcn' && !targetLanguageName.includes('中文');

                if (needsTranslation) {
                    try {
                        const translatedAnswer = await popup.requestChatCompletionTranslation(
                            finalAnswer,
                            provider,
                            model,
                            targetLanguageName
                        );
                        if (translatedAnswer && translatedAnswer.trim()) {
                            finalAnswer = translatedAnswer.trim();
                        }
                    } catch (translationError) {
                        console.error(popup.t('popup.log.answerTranslationFailed'), translationError);
                    }
                }

                // 检查AI是否检测到输入为乱码
                if (finalAnswer && (
                    finalAnswer.includes('当前问题为乱码') ||
                    finalAnswer.includes('当前内容为乱码') ||
                    finalAnswer.includes('Current question is gibberish') ||
                    finalAnswer.includes('Current content is gibberish') ||
                    finalAnswer.includes('現在の質問は乱雑') ||
                    finalAnswer.includes('現在のコンテンツは乱雑')
                )) {
                    console.warn('AI检测到用户输入为乱码:', finalAnswer.trim());
                    // 返回特殊的乱码提示信息
                    return '🚫 AI检测到您的输入可能包含乱码或无效内容，无法进行有效问答。\n\n请检查输入内容，确保包含有效的文本后再试。';
                }

                return finalAnswer;
            } catch (modelError) {
                console.error(popup.t('popup.log.modelServiceCallFailed'), modelError);
                throw new Error(popup.t('popup.error.modelServiceFailed', { error: modelError.message }));
            }

        } catch (error) {
            console.error(popup.t('popup.log.kbQueryFailed'), error);
            console.error(popup.t('popup.log.errorDetails'), error.stack);

            if (error.message.includes('大模型服务调用失败:') ||
                error.message.includes('模型服务调用失败:') ||
                error.message.includes('API调用失败:')) {
                throw error;
            }

            let errorMessage = popup.t('popup.error.kbQueryFailedBase');

            if (error.message.includes('请求失败:')) {
                const detail = error.message.replace('请求失败:', '').trim();
                errorMessage = popup.t('popup.error.kbNetworkRequestFailed', { detail });
            } else if (error.message.includes('知识库查询失败:')) {
                const detail = error.message.replace('知识库查询失败:', '').trim();
                errorMessage = popup.t('popup.error.kbQueryFailedDetail', { detail });
            } else if (error.message.includes('未配置')) {
                errorMessage = popup.t('popup.error.kbConfigIssue', { message: error.message });
            } else if (error.message.includes('网络') || error.message.includes('连接')) {
                errorMessage = popup.t('popup.error.kbNetworkConnectionFailed');
            } else {
                errorMessage = error.message;
            }

            throw new Error(errorMessage);
        }
    }

    return {
        callAIAPI,
        callOllamaAPI,
        streamChatWithConfig,
        streamChat
    };
}
