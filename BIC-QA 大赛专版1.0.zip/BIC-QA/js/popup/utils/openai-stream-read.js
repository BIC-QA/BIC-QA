/**
 * 解析 OpenAI 兼容 chat/completions 的 SSE 行（stream=true）。
 * @param {string} line 单行原文
 * @returns {{ text: string, done: boolean }}
 */
export function parseChatCompletionSSELine(line) {
    const trimmed = String(line).trimEnd();
    if (!trimmed) {
        return { text: '', done: false };
    }
    if (!trimmed.startsWith('data:')) {
        return { text: '', done: false };
    }
    let payload = trimmed.slice(5).trimStart();
    if (payload === '[DONE]') {
        return { text: '', done: true };
    }
    try {
        const data = JSON.parse(payload);
        const choice = data?.choices?.[0];
        if (!choice) {
            return { text: '', done: false };
        }
        const delta = choice.delta;
        if (delta && typeof delta.content === 'string' && delta.content.length > 0) {
            return { text: delta.content, done: false };
        }
        const msg = choice.message?.content;
        if (typeof msg === 'string' && msg.length > 0) {
            return { text: msg, done: false };
        }
    } catch (_) {
        /* 忽略单行解析失败 */
    }
    return { text: '', done: false };
}

/**
 * 读取完整 SSE 响应体并拼接助手输出（无 UI，用于建议问题等非展示场景）。
 * @param {Response} response fetch 响应
 * @returns {Promise<string>}
 */
export async function accumulateOpenAIChatCompletionSSE(response) {
    if (!response.body) {
        const text = await response.text();
        return accumulateFromSSEText(text);
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let full = '';
    while (true) {
        const { done, value } = await reader.read();
        if (done) {
            break;
        }
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) {
            const { text, done: streamDone } = parseChatCompletionSSELine(line);
            if (streamDone) {
                return full;
            }
            if (text) {
                full += text;
            }
        }
    }
    if (buffer.trim()) {
        const lines = buffer.split('\n');
        for (const line of lines) {
            const { text, done: streamDone } = parseChatCompletionSSELine(line);
            if (streamDone) {
                break;
            }
            if (text) {
                full += text;
            }
        }
    }
    return full;
}

function accumulateFromSSEText(text) {
    let full = '';
    for (const line of String(text).split('\n')) {
        const { text: piece, done } = parseChatCompletionSSELine(line);
        if (done) {
            break;
        }
        if (piece) {
            full += piece;
        }
    }
    return full;
}
