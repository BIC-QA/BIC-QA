/**
 * 侧栏「上传材料」：弹框展示历史上传文件名 + 按钮选择压缩包上传。
 */

import { escapeHtml, formatTime } from '../utils/common.js';

/** 100MB */
export const MATERIALS_ARCHIVE_MAX_BYTES = 100 * 1024 * 1024;

/** 上传材料允许更长的传输时间，避免大文件在前端超时被取消 */
export const MATERIALS_UPLOAD_TIMEOUT_MS = 10 * 60 * 1000;

/** POST multipart，字段名 file；新增接口 remark 为 query 参数 */
export const MATERIALS_UPLOAD_API_PATH = '/api/achievementResult/add';

/** POST 列表，Body 字段即使为空也必须传 */
export const MATERIALS_LIST_API_PATH = '/api/achievementResult/list';

/** POST multipart，字段名 file；更新接口 achievementId 必传，remark 可空 */
export const MATERIALS_UPDATE_API_PATH = '/api/achievementResult/update';

const COMPOUND_SUFFIXES = ['.tar.gz', '.tar.bz2', '.tar.xz'];

const SINGLE_EXT = new Set(['.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz', '.tgz']);

const API_KEY_MISSING_MESSAGE = 'API KEY不存在，请先在设置中配置apikey';

/**
 * @param {import('../app.js').BicQAPopup} app
 */
export function attachMaterialsUploadModule(app) {
    app.showMaterialsDialog = showMaterialsDialog.bind(app);
    app.hideMaterialsDialog = hideMaterialsDialog.bind(app);
    app.showMaterialsUploadDialog = showMaterialsUploadDialog.bind(app);
    app.hideMaterialsUploadDialog = hideMaterialsUploadDialog.bind(app);
    app.handleMaterialsArchiveChange = handleMaterialsArchiveChange.bind(app);
}

function ensureMaterialsApiKey(app) {
    const apiKey = app.resolveApiKey?.();
    if (apiKey) {
        return true;
    }
    app.showMessage?.(API_KEY_MISSING_MESSAGE, 'error', {
        centered: true,
        durationMs: 4000,
        maxWidth: '420px'
    });
    return false;
}

/**
 * @param {string} fileName
 */
export function isAllowedArchiveFileName(fileName) {
    const lower = String(fileName || '').toLowerCase();
    for (const suf of COMPOUND_SUFFIXES) {
        if (lower.endsWith(suf)) {
            return true;
        }
    }
    const dot = lower.lastIndexOf('.');
    if (dot === -1) {
        return false;
    }
    return SINGLE_EXT.has(lower.slice(dot));
}

function setMaterialsScrollLock(locked) {
    document.documentElement.style.overflow = locked ? 'hidden' : '';
    document.body.style.overflow = locked ? 'hidden' : '';
}

/**
 * @this {import('../app.js').BicQAPopup}
 */
async function showMaterialsDialog() {
    const dialog = document.getElementById('materialsDialog');
    if (!dialog) {
        return;
    }

    await this.refreshCompetitionStatus?.();

    ensureMaterialsDialogBindings.call(this);
    dialog.style.display = 'flex';
    setMaterialsScrollLock(true);
    this.translateStaticElements?.(this.currentLanguage);
    this.applyCompetitionAccessState?.();

    await loadMaterialsHistory.call(this);
}

/**
 * @this {import('../app.js').BicQAPopup}
 */
function hideMaterialsDialog() {
    const dialog = document.getElementById('materialsDialog');
    if (!dialog) {
        return;
    }
    dialog.style.display = 'none';
    hideMaterialsUploadDialog.call(this);
    setMaterialsScrollLock(false);
}

/**
 * @this {import('../app.js').BicQAPopup}
 */
function showMaterialsUploadDialog(options = {}) {
    const dialog = document.getElementById('materialsUploadDialog');
    if (!dialog) {
        return;
    }
    if (!(this.isCompetitionOperationAllowed?.() ?? true)) {
        this.showMessage?.(this.getCompetitionDisabledMessage?.(), 'warning', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }
    if (options.mode) {
        this.materialsUploadMode = options.mode;
        this.materialsEditingAchievementId = Number(options.achievementId || 0);
    } else {
        const existingItem = Array.isArray(this.materialsCurrentItems) ? this.materialsCurrentItems[0] : null;
        this.materialsUploadMode = existingItem?.achievementId ? 'update' : 'add';
        this.materialsEditingAchievementId = Number(existingItem?.achievementId || 0);
    }
    setSelectedMaterialsFile.call(this, null);
    dialog.style.display = 'flex';
    setMaterialsScrollLock(true);
    this.translateStaticElements?.(this.currentLanguage);
    this.applyCompetitionAccessState?.();
}

function showMaterialsUpdateDialog(achievementId) {
    const dialog = document.getElementById('materialsUploadDialog');
    if (!dialog) {
        return;
    }
    if (!(this.isCompetitionOperationAllowed?.() ?? true)) {
        this.showMessage?.(this.getCompetitionDisabledMessage?.(), 'warning', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }
    this.materialsUploadMode = 'update';
    this.materialsEditingAchievementId = Number(achievementId || 0);
    dialog.style.display = 'flex';
    setMaterialsScrollLock(true);
    this.translateStaticElements?.(this.currentLanguage);
    this.applyCompetitionAccessState?.();
}

/**
 * @this {import('../app.js').BicQAPopup}
 */
function hideMaterialsUploadDialog() {
    const dialog = document.getElementById('materialsUploadDialog');
    if (!dialog) {
        return;
    }
    dialog.style.display = 'none';
    setSelectedMaterialsFile.call(this, null);
    const mainOpen = document.getElementById('materialsDialog')?.style.display === 'flex';
    setMaterialsScrollLock(mainOpen);
}

function setSelectedMaterialsFile(file) {
    this.materialsSelectedFile = file || null;
    const nameEl = document.getElementById('materialsSelectedFileName');
    const confirmBtn = document.getElementById('materialsUploadConfirmBtn');

    if (nameEl) {
        nameEl.textContent = file ? `已选择：${file.name}` : '未选择文件';
        nameEl.title = file?.name || '';
    }
    if (confirmBtn) {
        if (!(this.isCompetitionOperationAllowed?.() ?? true)) {
            this.updateCompetitionButtonState?.(confirmBtn, true);
        } else {
            confirmBtn.disabled = !file;
        }
    }
}

function ensureMaterialsDialogBindings() {
    if (this._materialsDialogBindings) {
        return;
    }
    const closeBtn = document.getElementById('closeMaterialsDialog');
    const uploadBtn = document.getElementById('materialsDialogUploadBtn');
    const fileInput = document.getElementById('materialsArchiveFileInput');
    const uploadCloseBtn = document.getElementById('closeMaterialsUploadDialog');
    const selectFileBtn = document.getElementById('materialsSelectFileBtn');
    const confirmUploadBtn = document.getElementById('materialsUploadConfirmBtn');
    const cancelUploadBtn = document.getElementById('materialsUploadCancelBtn');
    const dropZone = document.getElementById('materialsDropZone');
    const prevBtn = document.getElementById('materialsPrevPageBtn');
    const nextBtn = document.getElementById('materialsNextPageBtn');
    const listEl = document.getElementById('materialsHistoryList');

    if (closeBtn) {
        closeBtn.addEventListener('click', () => hideMaterialsDialog.call(this));
    }
    if (uploadBtn) {
        uploadBtn.addEventListener('click', () => {
            if (!ensureMaterialsApiKey(this)) {
                return;
            }
            showMaterialsUploadDialog.call(this);
        });
    }
    if (uploadCloseBtn) {
        uploadCloseBtn.addEventListener('click', () => hideMaterialsUploadDialog.call(this));
    }
    if (cancelUploadBtn) {
        cancelUploadBtn.addEventListener('click', () => hideMaterialsUploadDialog.call(this));
    }
    if (confirmUploadBtn) {
        confirmUploadBtn.addEventListener('click', () => {
            void confirmMaterialsUpload.call(this);
        });
    }
    if (selectFileBtn && fileInput) {
        selectFileBtn.addEventListener('click', () => fileInput.click());
    }
    if (fileInput) {
        fileInput.addEventListener('change', event => {
            void handleMaterialsArchiveChange.call(this, event);
        });
    }
    if (dropZone) {
        const stop = (event) => {
            event.preventDefault();
            event.stopPropagation();
        };
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(name => {
            dropZone.addEventListener(name, stop);
        });
        ['dragenter', 'dragover'].forEach(name => {
            dropZone.addEventListener(name, () => {
                dropZone.classList.add('is-dragover');
            });
        });
        ['dragleave', 'drop'].forEach(name => {
            dropZone.addEventListener(name, () => {
                dropZone.classList.remove('is-dragover');
            });
        });
        dropZone.addEventListener('drop', event => {
            const file = event.dataTransfer?.files?.[0];
            if (!file) {
                return;
            }
            void selectMaterialsFile.call(this, file);
        });
    }
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if ((this.materialsCurrentPage || 1) > 1) {
                this.materialsCurrentPage -= 1;
                void loadMaterialsHistory.call(this);
            }
        });
    }
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            const totalPages = Math.max(1, Math.ceil((this.materialsTotal || 0) / (this.materialsPageSize || 10)));
            if ((this.materialsCurrentPage || 1) < totalPages) {
                this.materialsCurrentPage += 1;
                void loadMaterialsHistory.call(this);
            }
        });
    }
    if (listEl) {
        listEl.addEventListener('click', event => {
            const button = event.target?.closest?.('[data-action="update-material"]');
            if (!button) {
                return;
            }
            showMaterialsUpdateDialog.call(this, button.dataset.achievementId);
        });
    }

    this._materialsDialogBindings = true;
}

/**
 * @typedef {{ achievementId: number, userId: number, fileName: string, fileSize: number, remark: string, uploadedAt?: number }} MaterialsItem
 */

/**
 * @param {unknown} result
 * @returns {MaterialsItem[]}
 */
function normalizeRemoteMaterialsList(result) {
    if (!result || typeof result !== 'object') {
        return [];
    }
    const raw =
        /** @type {{ data?: unknown, list?: unknown, records?: unknown }} */ (result);
    let arr = raw.data ?? raw.list ?? raw.records;
    if (!Array.isArray(arr) && raw.data && typeof raw.data === 'object') {
        const inner = /** @type {{ list?: unknown }} */ (raw.data).list;
        if (Array.isArray(inner)) {
            arr = inner;
        }
    }
    if (!Array.isArray(arr)) {
        return [];
    }

    return arr
        .map(entry => {
            if (!entry || typeof entry !== 'object') {
                return null;
            }
            const o = /** @type {Record<string, unknown>} */ (entry);
            const achievementId = Number(o.achievementId || 0);
            const userId = Number(o.userId || 0);
            const fileSize = Number(o.fileSize || 0);
            const remark = String(o.remark || '').trim();
            const fileName = String(o.fileName ?? o.filename ?? o.name ?? o.originalFilename ?? '').trim();
            const uploadedAtRaw = o.createTime ?? o.uploadedAt ?? o.uploadTime ?? o.createdAt ?? o.time;
            let uploadedAt;
            if (typeof uploadedAtRaw === 'number' && Number.isFinite(uploadedAtRaw)) {
                uploadedAt = uploadedAtRaw;
            } else if (typeof uploadedAtRaw === 'string' && uploadedAtRaw) {
                const parsed = Date.parse(uploadedAtRaw);
                uploadedAt = Number.isFinite(parsed) ? parsed : undefined;
            }
            if (!fileName) {
                return null;
            }
            return /** @type {MaterialsItem} */ ({ achievementId, userId, fileName, fileSize, remark, uploadedAt });
        })
        .filter(Boolean);
}

function getMaterialsTotal(result, fallback = 0) {
    return Number(
        result?.data?.total
        || result?.data?.totalCount
        || result?.data?.count
        || result?.total
        || fallback
        || 0
    );
}

function assertMaterialsBusinessSuccess(result, fallbackMessage) {
    const status = String(result?.status ?? '').toLowerCase();
    if (status && ['error', 'fail', 'failed'].includes(status)) {
        throw new Error(result?.message || fallbackMessage);
    }
}

function buildMaterialsListPayload() {
    return {
        keyword: '',
        currentUser: '',
        pageNum: Number(this.materialsCurrentPage || 1),
        pageSize: Number(this.materialsPageSize || 10)
    };
}

function buildMaterialsUploadUrl(basePath, params) {
    const query = Object.entries(params).map(([key, value]) => {
        return `${encodeURIComponent(key)}=${encodeURIComponent(String(value ?? ''))}`;
    }).join('&');
    return query ? `${basePath}?${query}` : basePath;
}

/**
 * @this {import('../app.js').BicQAPopup}
 */
async function loadMaterialsHistory() {
    const loadingEl = document.getElementById('materialsHistoryLoading');
    const emptyEl = document.getElementById('materialsHistoryEmpty');
    const listEl = document.getElementById('materialsHistoryList');

    if (loadingEl) {
        loadingEl.style.display = 'block';
    }
    if (emptyEl) {
        emptyEl.style.display = 'none';
    }
    if (listEl) {
        listEl.innerHTML = '';
    }

    try {
        const apiKey = this.resolveApiKey?.();
        if (!apiKey) {
            throw new Error(API_KEY_MISSING_MESSAGE);
        }

        this.materialsCurrentPage = Number(this.materialsCurrentPage || 1);
        this.materialsPageSize = Number(this.materialsPageSize || 10);
        const provider = { authType: 'Bearer', apiKey };
        const result = await this.requestUtil.post(
            MATERIALS_LIST_API_PATH,
            buildMaterialsListPayload.call(this),
            { provider }
        );
        assertMaterialsBusinessSuccess(result, this.t('popup.materialsUpload.loadFailed'));
        const items = normalizeRemoteMaterialsList(result);
        this.materialsTotal = getMaterialsTotal(result, items.length);
        this.materialsCurrentItems = items;

        if (loadingEl) {
            loadingEl.style.display = 'none';
        }
        renderMaterialsHistoryList.call(this, items);
        updateMaterialsPagination.call(this);
    } catch (error) {
        console.warn('材料列表接口加载失败:', error);
        if (loadingEl) {
            loadingEl.style.display = 'none';
        }
        this.materialsTotal = 0;
        this.materialsCurrentItems = [];
        renderMaterialsHistoryList.call(this, []);
        updateMaterialsPagination.call(this);
        this.showMessage?.(
            this.normalizeApiKeyProfileErrorMessage?.(
                error?.message || this.t('popup.materialsUpload.loadFailed')
            ) || error?.message || this.t('popup.materialsUpload.loadFailed'),
            'error',
            {
            centered: true,
            durationMs: 4500,
            maxWidth: '420px'
        });
    }
}

/**
 * @this {import('../app.js').BicQAPopup}
 * @param {MaterialsItem[]} items
 */
function renderMaterialsHistoryList(items) {
    const listEl = document.getElementById('materialsHistoryList');

    if (!listEl) {
        return;
    }

    listEl.innerHTML = '';

    if (!items.length) {
        const emptyText = this.t('popup.materialsUpload.empty');
        listEl.innerHTML = `<tr><td colspan="3" class="materials-history-empty-cell">${emptyText}</td></tr>`;
        return;
    }

    for (const item of items) {
        const tr = document.createElement('tr');
        tr.className = 'materials-history-row';
        const safeName = escapeHtml(String(item.fileName || ''));
        const timeText = item.uploadedAt ? formatTime(new Date(item.uploadedAt)) : '--';
        const competitionAllowed = this.isCompetitionOperationAllowed?.() ?? true;
        const disabledAttrs = competitionAllowed
            ? ''
            : ` disabled title="${escapeHtml(this.getCompetitionDisabledMessage?.())}"`;
        tr.innerHTML = `
            <td class="materials-history-name-cell" title="${safeName}">${safeName}</td>
            <td class="materials-history-time-cell">${timeText}</td>
            <td class="materials-history-action-cell">
                <button type="button" class="toolset-action-btn" data-action="update-material" data-achievement-id="${escapeHtml(String(item.achievementId || 0))}"${disabledAttrs}>更新</button>
            </td>
        `;
        listEl.appendChild(tr);
    }
}

function updateMaterialsPagination() {
    const prevBtn = document.getElementById('materialsPrevPageBtn');
    const nextBtn = document.getElementById('materialsNextPageBtn');
    const pageInfo = document.getElementById('materialsPageInfo');
    const currentPage = Number(this.materialsCurrentPage || 1);
    const pageSize = Number(this.materialsPageSize || 10);
    const total = Number(this.materialsTotal || 0);
    const totalPages = Math.max(1, Math.ceil(total / pageSize));

    if (prevBtn) {
        prevBtn.disabled = currentPage <= 1;
    }
    if (nextBtn) {
        nextBtn.disabled = currentPage >= totalPages;
    }
    if (pageInfo) {
        pageInfo.textContent = `第 ${currentPage} / ${totalPages} 页，共 ${total} 条`;
    }
}

/**
 * @this {import('../app.js').BicQAPopup}
 * @param {Event & { target: HTMLInputElement }} event
 */
async function handleMaterialsArchiveChange(event) {
    const input = event.target;
    const file = input.files && input.files[0];
    input.value = '';

    if (!file) {
        return;
    }

    await selectMaterialsFile.call(this, file);
}

/**
 * @this {import('../app.js').BicQAPopup}
 * @param {File} file
 */
async function selectMaterialsFile(file) {
    if (!isAllowedArchiveFileName(file.name)) {
        this.showMessage(this.t('popup.materialsUpload.invalidType'), 'error', {
            centered: true,
            durationMs: 4500,
            maxWidth: '420px'
        });
        return;
    }

    if (file.size > MATERIALS_ARCHIVE_MAX_BYTES) {
        this.showMessage(this.t('popup.materialsUpload.tooLarge'), 'error', {
            centered: true,
            durationMs: 4500,
            maxWidth: '420px'
        });
        return;
    }

    setSelectedMaterialsFile.call(this, file);
}

async function confirmMaterialsUpload() {
    if (!(this.isCompetitionOperationAllowed?.() ?? true)) {
        this.showMessage?.(this.getCompetitionDisabledMessage?.(), 'warning', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }

    const file = this.materialsSelectedFile;
    if (!file) {
        this.showMessage('请先选择压缩包文件', 'warning', {
            centered: true,
            durationMs: 3000,
            maxWidth: '420px'
        });
        return;
    }

    await submitMaterialsArchive.call(this, file);
    hideMaterialsUploadDialog.call(this);
}

/**
 * @this {import('../app.js').BicQAPopup}
 * @param {File} file
 */
async function submitMaterialsArchive(file) {
    const apiKey = this.resolveApiKey?.();
    if (!apiKey) {
        this.showMessage(API_KEY_MISSING_MESSAGE, 'error', {
            centered: true,
            maxWidth: '420px',
            durationMs: 4000
        });
        return;
    }

    try {
        this.showLoadingOverlay?.(this.t('popup.materialsUpload.uploading'));
        const formData = new FormData();
        formData.append('file', file, file.name);
        const remark = '';

        const provider = { authType: 'Bearer', apiKey };
        const isUpdate = this.materialsUploadMode === 'update';
        if (isUpdate && !Number(this.materialsEditingAchievementId || 0)) {
            throw new Error('缺少材料ID，无法更新');
        }
        const url = isUpdate
            ? buildMaterialsUploadUrl(MATERIALS_UPDATE_API_PATH, {
                achievementId: Number(this.materialsEditingAchievementId || 0),
                remark
            })
            : buildMaterialsUploadUrl(MATERIALS_UPLOAD_API_PATH, {
                remark
            });
        const result = await this.requestUtil.upload(url, formData, {
            provider,
            timeout: MATERIALS_UPLOAD_TIMEOUT_MS
        });
        assertMaterialsBusinessSuccess(result, this.t('popup.materialsUpload.failed'));

        this.hideLoadingOverlay?.();

        this.materialsCurrentPage = 1;
        await loadMaterialsHistory.call(this);

        this.showMessage(this.t('popup.materialsUpload.success', { name: file.name }), 'success', {
            centered: true,
            durationMs: 4000,
            maxWidth: '440px'
        });
    } catch (error) {
        this.hideLoadingOverlay?.();
        const msg = String(error?.message || '').trim();
        this.showMessage(msg || this.t('popup.materialsUpload.failed'), 'error', {
            centered: true,
            durationMs: 5000,
            maxWidth: '440px'
        });
    }
}
