/**
 * 工具集管理模块。
 * 当前模式：列表展示 + 新增/编辑表单 + 删除。
 * @param {import('../app.js').BicQAPopup} app
 */

const DATABASE_CODE_OPTIONS = [
    ['2101', 'Oracle'],
    ['2102', 'MySQL兼容'],
    ['2103', '达梦'],
    ['2104', 'PG兼容生态'],
    ['2105', 'SQL Server'],
    ['2106', '神通-OSCAR'],
    ['2107', 'YashanDB'],
    ['2108', 'Redis'],
    ['2109', 'MongoDB'],
    ['2110', 'Redis Cluster'],
    ['2111', 'DB2'],
    ['2114', 'KingBase'],
    ['2115', 'Gbase'],
    ['2116', '磐维'],
    ['2117', 'OpenGauss'],
    ['2118', 'GreatSQL'],
    ['2119', '虚谷(Xugu)'],
    ['2201', 'TDSQL'],
    ['2202', 'GaussDB'],
    ['2203', 'OceanBase'],
    ['2204', 'TiDB'],
    ['2205', 'GoldenDB'],
    ['2206', 'Gbase 分布式'],
    ['2208', 'GBase 8a'],
    ['2209', 'HashData']
];

const DATABASE_CODE_ALIAS_MAP = DATABASE_CODE_OPTIONS.reduce((acc, [code, name]) => {
    acc[code] = code;
    acc[name.toLowerCase()] = code;
    return acc;
}, {});

const API_KEY_MISSING_MESSAGE = 'API KEY不存在，请先在设置中配置apikey';

export function attachToolsetModule(app) {
    app.showToolsetDialog = showToolsetDialog.bind(app);
    app.hideToolsetDialog = hideToolsetDialog.bind(app);
    app.resetToolsetForm = resetToolsetForm.bind(app);
    app.loadToolsetList = loadToolsetList.bind(app);
}

function ensureToolsetApiKey(app) {
    const apiKey = app.resolveApiKey?.();
    if (apiKey) {
        return true;
    }
    app.showMessage?.(API_KEY_MISSING_MESSAGE, 'error', {
        centered: true,
        durationMs: 4000,
        maxWidth: '420px'
    });
    return false;
}

async function showToolsetDialog() {
    if (!this.toolsetDialog) {
        return;
    }

    await this.refreshCompetitionStatus?.();

    ensureToolsetBindings.call(this);
    resetToolsetForm.call(this);

    if (!ensureToolsetApiKey(this)) {
        return;
    }

    this.toolsetDialog.style.display = 'flex';
    setToolsetScrollLock(true);
    this.translateStaticElements(this.currentLanguage);
    this.applyCompetitionAccessState?.();
    renderDatabaseOptions.call(this);

    await loadToolsetList.call(this);
    hideToolsetFormModal();
}

function hideToolsetDialog() {
    if (!this.toolsetDialog) return;
    this.toolsetDialog.style.display = 'none';
    setToolsetScrollLock(false);
    resetToolsetForm.call(this);
}

function resetToolsetForm() {
    this.toolUploadSelectedFile = null;
    this.toolsetList = this.toolsetList || [];
    this.toolsetFilteredList = this.toolsetList || [];
    this.toolsetCurrentPage = this.toolsetCurrentPage || 1;
    this.toolsetPageSize = this.toolsetPageSize || 10;
    this.toolsetTotal = this.toolsetTotal || 0;

    setInputValue('toolUploadToolId', '');
    setInputValue('toolUploadName', '');
    setInputValue('toolUploadCode', '');
    setInputValue('toolUploadDatabaseCode', '');
    setInputValue('toolUploadAccessScope', 'private');
    setInputValue('toolUploadFileDisplay', '');
    setInputValue('toolUploadFileInput', '');

    setText('toolFormTitle', this.t('popup.toolset.uploadTool.title'));
    setText('toolFormIntro', this.t('popup.toolset.uploadTool.intro'));
    setText('toolUploadSubmitBtn', this.t('popup.toolset.uploadTool.submit'));

    const submitBtn = document.getElementById('toolUploadSubmitBtn');
    if (submitBtn) {
        submitBtn.disabled = false;
    }

    updateFilePlaceholder.call(this, false);

    hideToolsetFormModal();
}

async function loadToolsetList() {
    const statusElText = this.t('popup.toolset.manager.loading');
    updateToolsetListStatus(statusElText, 'idle');

    const apiKey = this.resolveApiKey?.();
    if (!apiKey) {
        renderToolsetManagerRows.call(this, []);
        updateToolsetListStatus(API_KEY_MISSING_MESSAGE, 'warning');
        return;
    }

    try {
        this.toolsetCurrentUserId = await resolveCurrentToolsetUserId.call(this, apiKey);
        const filters = buildToolsetListFilters();
        const result = await fetchToolsetListFromApi.call(
            this,
            apiKey,
            filters,
            this.toolsetCurrentPage || 1,
            this.toolsetPageSize || 10
        );
        const list = result.list;
        this.toolsetList = list;
        this.toolsetTotal = result.total;
        this.toolsetCurrentPage = result.pageNum;
        this.toolsetPageSize = result.pageSize;
        this.toolsetFilteredList = list;
        renderToolsetManagerRows.call(this, list);
        updateToolsetPagination.call(this);
        updateToolsetListStatus(
            this.toolsetTotal
                ? this.t('popup.toolset.manager.loaded', { count: this.toolsetTotal })
                : this.t('popup.toolset.manager.empty'),
            this.toolsetTotal ? 'success' : 'warning'
        );
    } catch (error) {
        console.error('加载工具列表失败:', error);
        renderToolsetManagerRows.call(this, []);
        this.toolsetTotal = 0;
        this.toolsetCurrentPage = 1;
        updateToolsetListStatus(this.t('popup.toolset.manager.loadFailed', { error: error.message || 'unknown error' }), 'error');
        updateToolsetPagination.call(this);
    }
}

async function fetchToolsetListFromApi(apiKey, filters = {}, page = 1, pageSize = 10) {
    const provider = { authType: 'Bearer', apiKey };
    const requestBody = {
        keyword: String(filters.keyword || '').trim(),
        supportOs: String(filters.supportOs || '').trim(),
        supportArch: String(filters.supportArch || '').trim(),
        code: String(filters.code || '').trim(),
        accessScope: String(filters.accessScope || '').trim(),
        auditStatus: String(filters.auditStatus || '').trim()
    };
    const result = await this.requestUtil.post('/api/tool/list', {
        ...requestBody,
        pageNum: Number(page || 1),
        pageSize: Number(pageSize || 10)
    }, { provider });
    assertBusinessSuccess(result, '工具列表加载失败');
    const normalizedList = normalizeToolsetList(result);

    return {
        list: normalizedList,
        total: getToolsetTotal(result, normalizedList.length),
        pageNum: Number(result?.data?.pageNum || page || 1),
        pageSize: Number(result?.data?.pageSize || pageSize || 10)
    };
}

function normalizeToolsetList(result) {
    const rawList = result?.data?.list || result?.data?.records || result?.data?.rows || result?.data || result?.list || result?.records || [];
    if (!Array.isArray(rawList)) {
        return [];
    }

    return rawList.map(item => ({
        toolId: String(item.toolId || item.id || '').trim(),
        toolName: String(item.toolName || item.name || '').trim(),
        toolCode: String(item.toolCode || item.toolType || item.codeName || '').trim(),
        code: normalizeDatabaseCode(item.code || item.dbCode || item.databaseCode || ''),
        accessScope: normalizeAccessScope(item.accessScope || item.access_scope || ''),
        auditStatus: normalizeAuditStatus(item.auditStatus || item.audit_status || ''),
        auditRemark: String(item.auditRemark || item.audit_remark || item.remark || item.rejectReason || item.reject_reason || '').trim(),
        createdBy: normalizeUserId(item.createdBy || item.createBy || item.creator || item.userId || item.userid || item.user_id || ''),
        createdAt: item.createdAt || item.createTime || '',
        updatedAt: item.updatedAt || item.updateTime || ''
    })).filter(item => item.toolId || item.toolCode || item.toolName);
}

function getToolsetTotal(result, fallback = 0) {
    return Number(
        result?.data?.total
        || result?.data?.totalCount
        || result?.data?.count
        || result?.total
        || fallback
        || 0
    );
}

function renderToolsetManagerRows(list) {
    const tbody = document.getElementById('toolsetManagerList');
    if (!tbody) return;

    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="5" class="toolset-history-empty">${escapeHtml(this.t('popup.toolset.manager.empty'))}</td></tr>`;
        return;
    }

    tbody.innerHTML = list.map(item => {
        const editableByOwner = canManageTool.call(this, item);
        const competitionAllowed = this.isCompetitionOperationAllowed?.() ?? true;
        const editEnabled = editableByOwner && competitionAllowed;
        const editDisabledTitle = escapeHtml(
            competitionAllowed
                ? this.t('popup.toolset.manager.publicReadonly')
                : this.getCompetitionDisabledMessage?.()
        );
        const deleteDisabledTitle = escapeHtml(this.t('popup.toolset.manager.publicReadonly'));
        const normalizedAuditStatus = normalizeAuditStatus(item.auditStatus);
        const isRejected = normalizedAuditStatus === 'rejected';
        const rejectRemark = String(item.auditRemark || '').trim();
        const rejectRemarkButton = (editableByOwner && isRejected)
            ? `<button type="button" class="toolset-audit-icon-btn" data-action="audit-remark" data-tool-id="${escapeHtml(item.toolId)}" title="查看驳回说明" aria-label="查看驳回说明" ${rejectRemark ? '' : 'disabled'}>ⓘ</button>`
            : '';
        return `
        <tr>
            <td>${escapeHtml(item.toolName || '-')}</td>
            <td>
                <button
                    type="button"
                    class="toolset-copy-code-btn"
                    data-action="copy-code"
                    data-tool-code="${escapeHtml(item.toolCode || '-')}"
                    title="点击复制工具编码"
                    aria-label="点击复制工具编码"
                >
                    ${escapeHtml(item.toolCode || '-')}
                </button>
            </td>
            <td>
                <div class="toolset-audit-cell">
                    <span class="toolset-audit-status toolset-audit-status-${escapeHtml(normalizedAuditStatus)}">${escapeHtml(formatAuditStatusLabel.call(this, item.auditStatus))}</span>
                    ${rejectRemarkButton}
                </div>
            </td>
            <td>${escapeHtml(item.updatedAt || item.createdAt || '-')}</td>
            <td>
                <div class="toolset-row-actions">
                    <button type="button" class="toolset-action-btn" data-action="edit" data-tool-id="${escapeHtml(item.toolId)}" ${editEnabled ? '' : `disabled title="${editDisabledTitle}"`}>
                        ${escapeHtml(this.t('popup.toolset.manager.edit'))}
                    </button>
                    <button type="button" class="toolset-action-btn toolset-action-btn-danger" data-action="delete" data-tool-id="${escapeHtml(item.toolId)}" ${editableByOwner ? '' : `disabled title="${deleteDisabledTitle}"`}>
                        ${escapeHtml(this.t('popup.toolset.manager.delete'))}
                    </button>
                </div>
            </td>
        </tr>
    `;
    }).join('');
}

function openCreateToolForm() {
    if (!(this.isCompetitionOperationAllowed?.() ?? true)) {
        this.showMessage(this.getCompetitionDisabledMessage?.(), 'warning', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }

    resetToolsetForm.call(this);
    setText('toolFormTitle', this.t('popup.toolset.uploadTool.createTitle'));
    setText('toolFormIntro', this.t('popup.toolset.uploadTool.createIntro'));
    setText('toolUploadSubmitBtn', this.t('popup.toolset.uploadTool.createSubmit'));
    updateFilePlaceholder.call(this, false);
    showToolsetFormModal();
}

async function openEditToolForm(toolId) {
    if (!(this.isCompetitionOperationAllowed?.() ?? true)) {
        this.showMessage(this.getCompetitionDisabledMessage?.(), 'warning', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }

    const apiKey = this.resolveApiKey?.();
    if (!apiKey) {
        this.showMessage(API_KEY_MISSING_MESSAGE, 'error', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }

    const listTool = (this.toolsetList || []).find(item => item.toolId === String(toolId));
    if (listTool && !canManageTool.call(this, listTool)) {
        this.showMessage(this.t('popup.toolset.manager.publicReadonly'), 'warning', { centered: true, durationMs: 4000 });
        return;
    }

    let tool = null;
    try {
        tool = await fetchToolsetById.call(this, toolId, apiKey);
    } catch (error) {
        this.showMessage(error.message || this.t('popup.toolset.manager.editTargetMissing'), 'error', { centered: true, durationMs: 5000, maxWidth: '420px' });
        return;
    }
    if (!tool) {
        this.showMessage(this.t('popup.toolset.manager.editTargetMissing'), 'error', { centered: true });
        return;
    }

    resetToolsetForm.call(this);
    setInputValue('toolUploadToolId', tool.toolId || '');
    setInputValue('toolUploadName', tool.toolName || '');
    setInputValue('toolUploadCode', tool.toolCode || '');
    setInputValue('toolUploadDatabaseCode', tool.code || '');
    setInputValue('toolUploadAccessScope', normalizeAccessScope(tool.accessScope || 'private'));
    setInputValue('toolUploadFileDisplay', extractFileName(tool.scriptPath || ''));

    setText('toolFormTitle', this.t('popup.toolset.uploadTool.editTitle'));
    setText('toolFormIntro', this.t('popup.toolset.uploadTool.editIntro'));
    setText('toolUploadSubmitBtn', this.t('popup.toolset.uploadTool.editSubmit'));
    updateFilePlaceholder.call(this, true);
    showToolsetFormModal();
}

async function fetchToolsetById(toolId, apiKey) {
    if (!toolId) {
        return null;
    }

    const result = await this.requestUtil.post('/api/tool/getById', buildFormUrlEncodedBody({
        toolId: String(toolId)
    }), {
        provider: { authType: 'Bearer', apiKey },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    });
    assertBusinessSuccess(result, '获取工具详情失败');

    const raw = result?.data;
    if (!raw || typeof raw !== 'object') {
        return null;
    }

    return {
        toolId: String(raw.toolId || raw.id || '').trim(),
        toolName: String(raw.toolName || raw.name || '').trim(),
        toolCode: String(raw.toolCode || raw.toolType || raw.codeName || '').trim(),
        code: normalizeDatabaseCode(raw.code || raw.dbCode || raw.databaseCode || ''),
        accessScope: normalizeAccessScope(raw.accessScope || raw.access_scope || ''),
        auditStatus: normalizeAuditStatus(raw.auditStatus || raw.audit_status || ''),
        createdBy: normalizeUserId(raw.createdBy || raw.createBy || raw.creator || raw.userId || raw.userid || raw.user_id || ''),
        scriptPath: String(raw.scriptPath || raw.filePath || raw.path || '').trim(),
        createdAt: raw.createdAt || raw.createTime || '',
        updatedAt: raw.updatedAt || raw.updateTime || ''
    };
}

async function handleToolUploadSubmit(e) {
    e.preventDefault();

    const submitBtn = document.getElementById('toolUploadSubmitBtn');
    if (!submitBtn || submitBtn.disabled) {
        return;
    }

    if (!(this.isCompetitionOperationAllowed?.() ?? true)) {
        this.showMessage(this.getCompetitionDisabledMessage?.(), 'warning', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }

    const apiKey = this.resolveApiKey();
    if (!apiKey) {
        this.showMessage(API_KEY_MISSING_MESSAGE, 'error', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }

    const toolId = getInputValue('toolUploadToolId').trim();
    const isEdit = Boolean(toolId);
    const payload = {
        toolName: getInputValue('toolUploadName').trim(),
        toolCode: getInputValue('toolUploadCode').trim(),
        code: normalizeDatabaseCode(getInputValue('toolUploadDatabaseCode')),
        accessScope: isEdit
            ? normalizeAccessScope(getInputValue('toolUploadAccessScope') || 'private')
            : 'private',
        auditStatus: 'pending'
    };

    if (!payload.toolName || !payload.toolCode || (!isEdit && !this.toolUploadSelectedFile)) {
        this.showMessage(this.t(isEdit ? 'popup.toolset.uploadTool.editRequired' : 'popup.toolset.uploadTool.required'), 'error', { centered: true });
        return;
    }

    const originalText = submitBtn.textContent || '';
    submitBtn.disabled = true;
    submitBtn.textContent = this.t(isEdit ? 'popup.toolset.uploadTool.editSubmitting' : 'popup.toolset.uploadTool.submitting');
    this.showLoadingOverlay(submitBtn.textContent);

    try {
        const formData = new FormData();
        if (isEdit) {
            formData.append('toolId', toolId);
        }
        formData.append('toolName', payload.toolName);
        formData.append('toolCode', payload.toolCode);
        if (payload.code) {
            formData.append('code', payload.code);
        }
        if (payload.supportOs) {
            formData.append('supportOs', payload.supportOs);
        }
        if (payload.supportArch) {
            formData.append('supportArch', payload.supportArch);
        }
        formData.append('accessScope', payload.accessScope);
        if (!isEdit) {
            formData.append('auditStatus', payload.auditStatus);
        }
        if (this.toolUploadSelectedFile) {
            formData.append('file', this.toolUploadSelectedFile);
        }

        const url = isEdit ? '/api/tool/update' : '/api/tool/add';
        const result = await this.requestUtil.upload(url, formData, {
            provider: { authType: 'Bearer', apiKey }
        });
        assertBusinessSuccess(result, isEdit ? '工具更新失败' : '工具上传失败');

        this.hideLoadingOverlay();
        const successBaseText = String(this.t(
            isEdit ? 'popup.toolset.uploadTool.editSuccess' : 'popup.toolset.uploadTool.success'
        )).replace(/[！!。.,，\s]+$/g, '');
        const returnedAuditStatus = normalizeAuditStatus(result?.data?.auditStatus || result?.data?.audit_status || '');
        const successMessage = isEdit
            ? (returnedAuditStatus === 'pending'
                ? `${successBaseText}，已提交审核，请稍等片刻。`
                : successBaseText)
            : `${successBaseText}，已提交审核，请稍等片刻。`;
        this.showMessage(
            successMessage,
            'success',
            { centered: true, durationMs: 3000 }
        );
        await loadToolsetList.call(this);
        resetToolsetForm.call(this);
    } catch (error) {
        this.hideLoadingOverlay();
        const rawMsg = String(error?.message || '').trim();
        const fallbackPrefix = isEdit ? '工具更新失败' : '工具上传失败';
        const apiReturnsFullSentence = /^(工具上传失败|工具更新失败)[：:]/.test(rawMsg);
        const displayMsg = apiReturnsFullSentence
            ? rawMsg
            : normalizeToolsetErrorMessage(
                  this.t(isEdit ? 'popup.toolset.uploadTool.editFailed' : 'popup.toolset.uploadTool.failed', {
                      error: rawMsg || 'unknown error'
                  }),
                  fallbackPrefix
              );
        this.showMessage(displayMsg, 'error', {
            centered: true,
            durationMs: 5000,
            maxWidth: '420px'
        });
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText || this.t('popup.toolset.uploadTool.submit');
    }
}

async function handleDeleteTool(toolId) {
    const apiKey = this.resolveApiKey();
    if (!apiKey) {
        this.showMessage(API_KEY_MISSING_MESSAGE, 'error', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }

    if (!toolId) {
        return;
    }

    const tool = (this.toolsetList || []).find(item => item.toolId === String(toolId));
    if (tool && !canManageTool.call(this, tool)) {
        this.showMessage(this.t('popup.toolset.manager.publicReadonly'), 'warning', { centered: true, durationMs: 4000 });
        return;
    }

    const deleteTargetName = String(tool?.toolName || '未知工具');
    const deleteTargetCode = String(tool?.toolCode || '-');
    const confirmed = await showToolsetConfirm.call(this, {
        title: this.t('popup.toolset.manager.delete'),
        message: `确认删除工具「${deleteTargetName}」（编码：${deleteTargetCode}）吗？删除后无法恢复。`
    });
    if (!confirmed) {
        return;
    }

    this.showLoadingOverlay(this.t('popup.toolset.manager.deleting'));
    try {
        const result = await this.requestUtil.post('/api/tool/delete', buildFormUrlEncodedBody({
            toolId: String(toolId)
        }), {
            provider: { authType: 'Bearer', apiKey },
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });
        assertBusinessSuccess(result, '工具删除失败');
        this.hideLoadingOverlay();
        this.showMessage(this.t('popup.toolset.manager.deleteSuccess'), 'success', { centered: true, durationMs: 3000 });
        await loadToolsetList.call(this);
    } catch (error) {
        this.hideLoadingOverlay();
        this.showMessage(this.t('popup.toolset.manager.deleteFailed', { error: error.message || 'unknown error' }), 'error', {
            centered: true,
            durationMs: 5000,
            maxWidth: '420px'
        });
    }
}

function assertBusinessSuccess(result, fallbackMessage) {
    if (isBusinessErrorResult(result)) {
        throw new Error(result?.message || fallbackMessage);
    }
}

function isBusinessErrorResult(result) {
    return result && typeof result === 'object' && String(result.status || '').toLowerCase() === 'error';
}

function normalizeToolsetErrorMessage(message, prefix) {
    const normalizedPrefix = String(prefix || '').trim();
    const normalizedMessage = String(message || '').trim();
    if (!normalizedPrefix || !normalizedMessage) {
        return normalizedMessage || normalizedPrefix;
    }
    return normalizedMessage.replace(
        new RegExp(`^(${escapeRegExp(normalizedPrefix)}：\\s*)+`),
        `${normalizedPrefix}：`
    );
}

function escapeRegExp(value) {
    return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function handleToolUploadFileSelect(e) {
    const file = e?.target?.files?.[0] || null;
    if (file && !String(file.name || '').toLowerCase().endsWith('.py')) {
        this.toolUploadSelectedFile = null;
        setInputValue('toolUploadFileDisplay', '');
        setInputValue('toolUploadFileInput', '');
        this.showMessage(this.t('popup.toolset.uploadTool.invalidFileType'), 'error', {
            centered: true,
            durationMs: 4000,
            maxWidth: '420px'
        });
        return;
    }
    this.toolUploadSelectedFile = file;
    setInputValue('toolUploadFileDisplay', file?.name || '');
}

function ensureToolsetBindings() {
    if (this.toolsetDialog?.dataset.bound === 'true') {
        return;
    }

    this.toolsetDialog.dataset.bound = 'true';

    document.getElementById('toolsetCreateBtn')?.addEventListener('click', () => {
        if (!ensureToolsetApiKey(this)) {
            return;
        }
        openCreateToolForm.call(this);
    });

    document.getElementById('toolsetSearchKeyword')?.addEventListener('input', () => {
        this.toolsetCurrentPage = 1;
        clearTimeout(this.toolsetSearchDebounceTimer);
        this.toolsetSearchDebounceTimer = setTimeout(() => {
            void loadToolsetList.call(this);
        }, 250);
    });

    document.getElementById('toolsetSearchKeyword')?.addEventListener('keydown', event => {
        if (event.key === 'Enter') {
            event.preventDefault();
            this.toolsetCurrentPage = 1;
            clearTimeout(this.toolsetSearchDebounceTimer);
            void loadToolsetList.call(this);
        }
    });

    document.getElementById('toolsetSearchAccessScope')?.addEventListener('change', () => {
        this.toolsetCurrentPage = 1;
        void loadToolsetList.call(this);
    });

    document.getElementById('toolsetSearchAuditStatus')?.addEventListener('change', () => {
        this.toolsetCurrentPage = 1;
        void loadToolsetList.call(this);
    });

    document.getElementById('toolsetFilterSearchBtn')?.addEventListener('click', () => {
        this.toolsetCurrentPage = 1;
        void loadToolsetList.call(this);
    });

    document.getElementById('toolsetFilterResetBtn')?.addEventListener('click', () => {
        setInputValue('toolsetSearchKeyword', '');
        setInputValue('toolsetSearchAccessScope', '');
        setInputValue('toolsetSearchAuditStatus', '');
        this.toolsetCurrentPage = 1;
        void loadToolsetList.call(this);
    });

    document.getElementById('toolsetPrevPageBtn')?.addEventListener('click', () => {
        if ((this.toolsetCurrentPage || 1) <= 1) {
            return;
        }
        this.toolsetCurrentPage -= 1;
        void loadToolsetList.call(this);
    });

    document.getElementById('toolsetNextPageBtn')?.addEventListener('click', () => {
        const totalPages = Math.ceil((this.toolsetTotal || 0) / (this.toolsetPageSize || 10));
        if (totalPages === 0 || (this.toolsetCurrentPage || 1) >= totalPages) {
            return;
        }
        this.toolsetCurrentPage += 1;
        void loadToolsetList.call(this);
    });

    document.getElementById('toolsetPageSizeSelect')?.addEventListener('change', event => {
        const nextPageSize = Number(event?.target?.value || 10);
        this.toolsetPageSize = Number.isFinite(nextPageSize) && nextPageSize > 0 ? nextPageSize : 10;
        this.toolsetCurrentPage = 1;
        void loadToolsetList.call(this);
    });

    document.getElementById('toolUploadForm')?.addEventListener('submit', event => {
        void handleToolUploadSubmit.call(this, event);
    });

    document.getElementById('toolUploadFileUploadBtn')?.addEventListener('click', () => {
        document.getElementById('toolUploadFileInput')?.click();
    });

    document.getElementById('toolUploadFileInput')?.addEventListener('change', event => {
        handleToolUploadFileSelect.call(this, event);
    });

    document.getElementById('toolFormBackBtn')?.addEventListener('click', () => {
        resetToolsetForm.call(this);
    });

    document.getElementById('toolFormCloseBtn')?.addEventListener('click', () => {
        resetToolsetForm.call(this);
    });

    bindToolsetConfirmEvents.call(this);

    document.getElementById('toolsetManagerList')?.addEventListener('click', event => {
        const button = event.target.closest('[data-action]');
        if (!button) {
            return;
        }

        const action = button.dataset.action;
        if (action === 'copy-code') {
            const toolCode = String(button.dataset.toolCode || '').trim();
            if (!toolCode || toolCode === '-') {
                return;
            }
            navigator.clipboard.writeText(toolCode).then(() => {
                this.showMessage(this.t('popup.message.copied'), 'success', {
                    centered: true,
                    durationMs: 2000
                });
            }).catch(() => {
                this.showMessage(this.t('popup.message.copyFailed'), 'error', {
                    centered: true,
                    durationMs: 3000
                });
            });
            return;
        }

        const toolId = button.dataset.toolId;
        const tool = (this.toolsetList || []).find(item => item.toolId === String(toolId));

        if (!(this.isCompetitionOperationAllowed?.() ?? true) && action === 'edit') {
            this.showMessage(this.getCompetitionDisabledMessage?.(), 'warning', {
                centered: true,
                durationMs: 4000,
                maxWidth: '420px'
            });
            return;
        }

        if (tool && !canManageTool.call(this, tool)) {
            this.showMessage(this.t('popup.toolset.manager.publicReadonly'), 'warning', { centered: true, durationMs: 4000 });
            return;
        }

        if (action === 'edit') {
            void openEditToolForm.call(this, toolId);
        } else if (action === 'delete') {
            void handleDeleteTool.call(this, toolId);
        } else if (action === 'audit-remark') {
            const remark = String(tool?.auditRemark || '').trim();
            void showToolsetConfirm.call(this, {
                title: '审核驳回说明',
                message: remark || '当前未返回驳回说明。',
                showCancel: false,
                okText: '我知道了'
            });
        }
    });
}

function renderDatabaseOptions() {
    populateSelectOptions('toolUploadDatabaseCode', DATABASE_CODE_OPTIONS, this?.t?.('popup.toolset.uploadTool.databaseCodePlaceholder') || '请选择数据库类型');
}

function populateSelectOptions(selectId, options, placeholder = '请选择数据库类型') {
    const select = document.getElementById(selectId);
    if (!select) {
        return;
    }

    select.innerHTML = `<option value="">${escapeHtml(placeholder)}</option>`;
    options.forEach(([code, name]) => {
        select.insertAdjacentHTML('beforeend', `<option value="${escapeHtml(code)}">${escapeHtml(name)}</option>`);
    });
    if (selectId === 'toolUploadDatabaseCode') {
        const firstOption = select.querySelector('option[value=""]');
        if (firstOption) {
            firstOption.textContent = placeholder;
        }
    }
}

function normalizeDatabaseCode(value) {
    const raw = String(value || '').trim();
    if (!raw) {
        return '';
    }
    return DATABASE_CODE_ALIAS_MAP[raw] || DATABASE_CODE_ALIAS_MAP[raw.toLowerCase()] || raw;
}

function formatDatabaseCode(code) {
    const normalized = normalizeDatabaseCode(code);
    const matched = DATABASE_CODE_OPTIONS.find(([value]) => value === normalized);
    if (!matched) {
        return normalized || '-';
    }
    return matched[1];
}

function updateToolsetListStatus(text, status) {
    setText('toolsetListStatus', text);
    const el = document.getElementById('toolsetListStatus');
    if (el) {
        el.dataset.status = status;
    }
}

function updateToolsetPagination() {
    const totalPages = Math.ceil((this.toolsetTotal || 0) / (this.toolsetPageSize || 10));
    const pageInfo = document.getElementById('toolsetPageInfo');
    const prevBtn = document.getElementById('toolsetPrevPageBtn');
    const nextBtn = document.getElementById('toolsetNextPageBtn');
    const pageSizeSelect = document.getElementById('toolsetPageSizeSelect');

    if (pageInfo) {
        pageInfo.textContent = this.t('popup.toolset.pagination.info', {
            current: this.toolsetCurrentPage || 1,
            total: totalPages > 0 ? totalPages : 1,
            records: this.toolsetTotal || 0
        });
    }

    if (prevBtn) {
        prevBtn.disabled = (this.toolsetCurrentPage || 1) <= 1;
    }

    if (nextBtn) {
        nextBtn.disabled = totalPages === 0 || (this.toolsetCurrentPage || 1) >= totalPages;
    }

    if (pageSizeSelect) {
        pageSizeSelect.value = String(this.toolsetPageSize || 10);
    }
}

function buildToolsetListFilters() {
    return {
        keyword: getInputValue('toolsetSearchKeyword').trim(),
        accessScope: normalizeAccessScopeFilter(getInputValue('toolsetSearchAccessScope')),
        auditStatus: normalizeAuditStatusFilter(getInputValue('toolsetSearchAuditStatus')),
        supportOs: '',
        supportArch: '',
        code: ''
    };
}

function buildFormUrlEncodedBody(values) {
    const params = new URLSearchParams();
    Object.entries(values || {}).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
            params.append(key, value);
        }
    });
    return params.toString();
}

function updateFilePlaceholder(isEdit) {
    const input = document.getElementById('toolUploadFileDisplay');
    if (!input) {
        return;
    }

    input.placeholder = this.t(
        isEdit
            ? 'popup.toolset.uploadTool.fileOptionalPlaceholder'
            : 'popup.toolset.uploadTool.filePlaceholder'
    );
}

function canManageTool(tool) {
    const createdBy = normalizeUserId(tool?.createdBy || '');
    const currentUserId = normalizeUserId(this?.toolsetCurrentUserId || '');
    return Boolean(createdBy && currentUserId && createdBy === currentUserId);
}

async function resolveCurrentToolsetUserId(apiKey) {
    try {
        const result = await this.requestUtil.post('/api/user/profile', null, {
            provider: { authType: 'Bearer', apiKey }
        });
        if (result && (result.success === false || (result.code && result.code !== 200))) {
            this.showMessage(
                this.normalizeApiKeyProfileErrorMessage?.(
                    result.message || result.error || this.t('popup.message.apiKeyValidationFailed')
                ) || result.message || result.error || this.t('popup.message.apiKeyValidationFailed'),
                'error',
                {
                centered: true,
                durationMs: 4000,
                maxWidth: '420px'
            });
            return '';
        }
        const user = result?.user || result?.data?.user || result?.data || {};
        return normalizeUserId(user?.userid || user?.userId || user?.id || '');
    } catch (error) {
        console.warn('获取当前登录用户ID失败，将禁用工具集编辑能力:', error);
        return '';
    }
}

function normalizeUserId(value) {
    return String(value || '').trim();
}

function normalizeAccessScope(value) {
    const normalized = String(value || '').trim().toLowerCase();
    if (normalized === 'public' || normalized === 'private') {
        return normalized;
    }
    return 'private';
}

function normalizeAccessScopeFilter(value) {
    const normalized = String(value || '').trim().toLowerCase();
    if (normalized === 'public' || normalized === 'private') {
        return normalized;
    }
    return '';
}

function normalizeAuditStatusFilter(value) {
    const normalized = String(value || '').trim().toLowerCase();
    if (normalized === 'pending' || normalized === 'approved' || normalized === 'rejected') {
        return normalized;
    }
    return '';
}

function normalizeAuditStatus(value) {
    const normalized = String(value || '').trim().toLowerCase();
    if (normalized === 'pending' || normalized === 'approved' || normalized === 'rejected') {
        return normalized;
    }
    return '';
}

function formatAuditStatusLabel(auditStatus) {
    const normalized = normalizeAuditStatus(auditStatus);
    if (!normalized) {
        return '-';
    }
    return this.t(`popup.toolset.manager.auditStatus.${normalized}`);
}

function formatAccessScopeLabel(accessScope) {
    const normalized = normalizeAccessScope(accessScope);
    return this.t(
        normalized === 'public'
            ? 'popup.toolset.common.accessScope.public'
            : 'popup.toolset.common.accessScope.private'
    );
}

function extractFileName(filePath) {
    const normalized = String(filePath || '').trim();
    if (!normalized) {
        return '';
    }

    const segments = normalized.split(/[\\/]/);
    return segments[segments.length - 1] || normalized;
}

function setToolsetScrollLock(locked) {
    document.documentElement.style.overflow = locked ? 'hidden' : '';
    document.body.style.overflow = locked ? 'hidden' : '';
}

function showToolsetFormModal() {
    const modal = document.getElementById('toolsetFormModal');
    if (modal) {
        modal.style.display = 'flex';
    }
}

function hideToolsetFormModal() {
    const modal = document.getElementById('toolsetFormModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function bindToolsetConfirmEvents() {
    const modal = document.getElementById('toolsetConfirmModal');
    if (!modal || modal.dataset.bound === 'true') {
        return;
    }

    modal.dataset.bound = 'true';

    const close = value => {
        if (typeof modal._resolver === 'function') {
            modal._resolver(Boolean(value));
        }
        modal._resolver = null;
        modal.style.display = 'none';
    };

    document.getElementById('toolsetConfirmCloseBtn')?.addEventListener('click', () => close(false));
    document.getElementById('toolsetConfirmCancelBtn')?.addEventListener('click', () => close(false));
    document.getElementById('toolsetConfirmOkBtn')?.addEventListener('click', () => close(true));
}

function showToolsetConfirm({ title, message, showCancel = true, okText, cancelText }) {
    const modal = document.getElementById('toolsetConfirmModal');
    if (!modal) {
        return Promise.resolve(false);
    }

    const titleEl = document.getElementById('toolsetConfirmTitle');
    const messageEl = document.getElementById('toolsetConfirmMessage');
    const cancelBtn = document.getElementById('toolsetConfirmCancelBtn');
    const okBtn = document.getElementById('toolsetConfirmOkBtn');
    if (titleEl) {
        titleEl.textContent = title || '';
    }
    if (messageEl) {
        messageEl.textContent = message || '';
    }
    if (cancelBtn) {
        cancelBtn.style.display = showCancel ? '' : 'none';
        cancelBtn.textContent = cancelText || '取消';
    }
    if (okBtn) {
        okBtn.textContent = okText || '确定';
    }

    modal.style.display = 'flex';

    return new Promise(resolve => {
        modal._resolver = resolve;
    });
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) {
        el.textContent = value || '';
    }
}

function setInputValue(id, value) {
    const el = document.getElementById(id);
    if (el) {
        el.value = value || '';
    }
}

function getInputValue(id) {
    return document.getElementById(id)?.value || '';
}

function escapeHtml(value) {
    return String(value || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}
