/**
 * 故障分析功能模块，将相关方法绑定到 BicQAPopup 实例。
 * 仅保留：优化语言、上传SQL文件、接收邮箱
 * 接口：diagnosis/upload，diagnosisType=fault_analysis
 * 历史：diagnosis/list，diagnosisType=fault_analysis
 * @param {import('../app.js').BicQAPopup} app
 */
import { escapeHtml } from '../utils/common.js';

export function attachFaultAnalysisModule(app) {
    app.showFaultAnalysisDialog = showFaultAnalysisDialog.bind(app);
    app.hideFaultAnalysisDialog = hideFaultAnalysisDialog.bind(app);
    app.resetFaultAnalysisForm = resetFaultAnalysisForm.bind(app);
    app.handleFaultAnalysisFileSelect = handleFaultAnalysisFileSelect.bind(app);
    app.handleFaultAnalysisSubmit = handleFaultAnalysisSubmit.bind(app);
    app.submitFaultAnalysisAnalysis = submitFaultAnalysisAnalysis.bind(app);

    app.switchFaultAnalysisTab = switchFaultAnalysisTab.bind(app);
    app.handleFaultAnalysisSearch = handleFaultAnalysisSearch.bind(app);
    app.handleFaultAnalysisReset = handleFaultAnalysisReset.bind(app);
    app.loadFaultAnalysisHistoryList = loadFaultAnalysisHistoryList.bind(app);
    app.renderFaultAnalysisHistoryList = renderFaultAnalysisHistoryList.bind(app);
    app.createFaultAnalysisHistoryTableRow = createFaultAnalysisHistoryTableRow.bind(app);
    app.getFaultAnalysisStatusText = getFaultAnalysisStatusText.bind(app);
    app.getFaultAnalysisStatusClass = getFaultAnalysisStatusClass.bind(app);
    app.getFaultAnalysisNotifyStatusText = getFaultAnalysisNotifyStatusText.bind(app);
    app.getFaultAnalysisNotifyStatusClass = getFaultAnalysisNotifyStatusClass.bind(app);
    app.updateFaultAnalysisPagination = updateFaultAnalysisPagination.bind(app);
    app.handleFaultAnalysisResend = handleFaultAnalysisResend.bind(app);
    app.handleFaultAnalysisDownload = handleFaultAnalysisDownload.bind(app);
}

async function showFaultAnalysisDialog() {
    if (!this.faultAnalysisDialog) {
        return;
    }

    this.resetFaultAnalysisForm();
    this.faultAnalysisDialog.style.display = 'flex';

    if (this.ensureUpdateIconVisible) {
        setTimeout(() => {
            this.ensureUpdateIconVisible();
        }, 100);
    }

    this.translateStaticElements(this.currentLanguage);

    const envType = await this.getEnvType();
    const emailGroup = document.querySelector('#faultAnalysisEmail')?.closest('.form-group');
    if (emailGroup) {
        emailGroup.style.display = envType === 'in_env' ? 'none' : 'block';
    }

    await this.loadRegistrationEmail(this.faultAnalysisEmail);

    let userProfileData = null;
    try {
        userProfileData = await this.getUserProfile();
        if (this.faultAnalysisUserName && userProfileData.userName) {
            this.faultAnalysisUserName.value = userProfileData.userName;
        }
        if (this.faultAnalysisEmail && !this.faultAnalysisEmail.value && userProfileData.email) {
            this.faultAnalysisEmail.value = userProfileData.email;
        }
    } catch (error) {
        console.error('加载故障分析用户信息失败:', error);
        try {
            await this.populateUserProfileFromApi({
                userNameInput: this.faultAnalysisUserName,
                emailInput: this.faultAnalysisEmail
            });
        } catch (fallbackError) {
            console.error('降级方案也失败:', fallbackError);
        }
    }

    if (typeof this.switchFaultAnalysisTab === 'function') {
        this.switchFaultAnalysisTab('new');
    }
}

function hideFaultAnalysisDialog() {
    this.cleanupDateTimeFilters();
    this.closeDateTimePicker();

    if (!this.faultAnalysisDialog) return;
    this.faultAnalysisDialog.style.display = 'none';
    if (this.faultAnalysisSaveBtn) {
        this.faultAnalysisSaveBtn.disabled = false;
        this.faultAnalysisSaveBtn.textContent = this.t('popup.faultAnalysis.form.submit');
    }
    this.resetFaultAnalysisForm();
}

function resetFaultAnalysisForm() {
    if (this.faultAnalysisEmail) {
        this.faultAnalysisEmail.value = this.faultAnalysisEmail.value || '';
    }
    if (this.faultAnalysisFileDisplay) {
        this.faultAnalysisFileDisplay.value = '';
        this.faultAnalysisFileDisplay.placeholder = this.t('popup.faultAnalysis.form.uploadPlaceholder');
    }
    if (this.faultAnalysisFileInput) {
        this.faultAnalysisFileInput.value = '';
    }
    if (this.faultAnalysisLanguage) {
        this.faultAnalysisLanguage.value = 'zh';
    }
    if (this.faultAnalysisAgreeTerms) {
        this.faultAnalysisAgreeTerms.checked = false;
    }
    this.faultAnalysisSelectedFile = null;
    this.faultAnalysisSelectedFileSnapshot = null;
}

async function handleFaultAnalysisFileSelect(e) {
    const file = e?.target?.files?.[0];
    if (file) {
        this.faultAnalysisSelectedFile = file;
        this.faultAnalysisSelectedFileSnapshot = null;
        try {
            // 在文件选择时创建内存快照，避免提交时文件句柄失效
            const fileBuffer = await file.arrayBuffer();
            this.faultAnalysisSelectedFileSnapshot = new File(
                [fileBuffer],
                file.name,
                {
                    type: file.type,
                    lastModified: file.lastModified
                }
            );
            console.log('故障分析文件快照已创建:', file.name, file.size);
        } catch (snapshotError) {
            console.warn('故障分析文件快照创建失败，将回退原始文件对象:', file.name, snapshotError);
        }
        if (this.faultAnalysisFileDisplay) {
            this.faultAnalysisFileDisplay.value = file.name;
            this.faultAnalysisFileDisplay.placeholder = file.name;
        }
    } else {
        this.faultAnalysisSelectedFile = null;
        this.faultAnalysisSelectedFileSnapshot = null;
        if (this.faultAnalysisFileDisplay) {
            this.faultAnalysisFileDisplay.value = '';
            this.faultAnalysisFileDisplay.placeholder = this.t('popup.faultAnalysis.form.uploadPlaceholder');
        }
    }
}

async function handleFaultAnalysisSubmit() {
    if (!this.faultAnalysisSaveBtn || this.faultAnalysisSaveBtn.disabled) {
        return;
    }

    const email = this.faultAnalysisEmail?.value.trim() || '';
    if (!email) {
        this.showMessage(this.t('popup.message.enterEmail'), 'error', { centered: true, durationMs: 5000, maxWidth: '360px' });
        this.faultAnalysisEmail?.focus();
        return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        this.showMessage(this.t('popup.message.invalidEmail'), 'error', { centered: true, durationMs: 5000, maxWidth: '360px' });
        this.faultAnalysisEmail?.focus();
        return;
    }

    if (!this.faultAnalysisSelectedFile) {
        this.showMessage(this.t('popup.message.selectFile'), 'error', { centered: true, durationMs: 5000, maxWidth: '360px' });
        this.faultAnalysisFileUploadBtn?.focus();
        return;
    }

    if (!this.faultAnalysisAgreeTerms || !this.faultAnalysisAgreeTerms.checked) {
        this.showMessage(this.t('popup.message.agreeTerms'), 'error', { centered: true, durationMs: 5000, maxWidth: '360px' });
        this.faultAnalysisAgreeTerms?.focus();
        return;
    }

    const originalButtonText = this.faultAnalysisSaveBtn.textContent || '';
    this.faultAnalysisSaveBtn.disabled = true;

    const formData = {
        username: this.faultAnalysisUserName?.value.trim() || '',
        email,
        file: this.faultAnalysisSelectedFileSnapshot || this.faultAnalysisSelectedFile,
        language: this.faultAnalysisLanguage?.value || 'zh'
    };

    this.showLoadingOverlay(this.t('popup.faultAnalysis.loading'));
    try {
        const response = await this.submitFaultAnalysisAnalysis(formData);
        this.hideLoadingOverlay();

        if (response && response.status === 'success') {
            if (this.faultAnalysisHistoryView?.classList.contains('active')) {
                const startTime = this.getDateTimeInputValue('faultAnalysisStartTime');
                const endTime = this.getDateTimeInputValue('faultAnalysisEndTime');
                const status = document.getElementById('faultAnalysisStatusFilter')?.value || '';
                this.loadFaultAnalysisHistoryList(this.faultAnalysisHistoryCurrentPage, this.faultAnalysisHistoryPageSize, '', startTime, endTime, status);
            }

            const envType = await this.getEnvType();
            const successMessage = envType === 'in_env'
                ? this.t('popup.message.faultAnalysisSubmitSuccessInEnv')
                : this.t('popup.message.faultAnalysisSubmitSuccess');

            this.showMessage(successMessage, 'success', { centered: true, durationMs: 6000, maxWidth: '380px', background: '#1e7e34' });
            this.hideFaultAnalysisDialog();
        } else {
            const errorMsg = response?.message || this.t('popup.message.faultAnalysisSubmitFailed', { error: this.t('popup.common.unknownError') });
            this.showMessage(errorMsg, 'error', { centered: true, durationMs: 5000, maxWidth: '360px' });
        }
    } catch (error) {
        console.error('提交故障分析失败:', error);
        this.hideLoadingOverlay();
        this.showMessage(this.t('popup.message.faultAnalysisSubmitFailed', { error: error.message || this.t('popup.common.unknownError') }), 'error', { centered: true, durationMs: 5000, maxWidth: '360px' });
    } finally {
        this.faultAnalysisSaveBtn.disabled = false;
        this.faultAnalysisSaveBtn.textContent = originalButtonText || this.t('popup.faultAnalysis.form.submit');
    }
}

async function submitFaultAnalysisAnalysis(formData) {
    const apiKey = this.resolveApiKey();
    if (!apiKey) {
        throw new Error(this.t('popup.message.apiKeyNotConfigured'));
    }

    let modelParams = null;
    try {
        const envType = await this.getEnvType();
        if (envType === 'in_env') {
            const selectedModelValue = this.modelSelect?.value;
            if (selectedModelValue) {
                let selectedKey;
                try {
                    selectedKey = JSON.parse(selectedModelValue);
                } catch (_) {
                    selectedKey = { name: selectedModelValue };
                }
                const selectedModel = this.models.find(m => m.name === selectedKey.name && (!selectedKey.provider || m.provider === selectedKey.provider));
                const provider = selectedModel ? this.providers.find(p => p.name === selectedModel.provider) : null;
                if (selectedModel && provider) {
                    modelParams = {
                        modelName: selectedModel.displayName || selectedModel.name,
                        apiEndpoint: provider.apiEndpoint || ''
                    };
                }
            }
        }
    } catch (error) {
        console.warn('获取模型参数失败:', error);
    }

    const formDataToSend = new FormData();
    formDataToSend.append('file', formData.file);

    const queryParams = new URLSearchParams();
    queryParams.append('username', formData.username);
    queryParams.append('email', formData.email);
    queryParams.append('language', formData.language || 'zh');
    queryParams.append('diagnosisType', 'fault_analysis');
    queryParams.append('apikey', apiKey);

    if (modelParams) {
        queryParams.append('modelParams', JSON.stringify(modelParams));
    }

    const url = `/api/diagnosis/upload?${queryParams.toString()}`;

    try {
        const tempProvider = {
            authType: 'Bearer',
            apiKey: apiKey
        };
        const result = await this.requestUtil.upload(url, formDataToSend, {
            provider: tempProvider
        });
        return result;
    } catch (error) {
        console.error('故障分析接口调用失败:', error);
        throw error;
    }
}

function switchFaultAnalysisTab(tabName) {
    if (this.faultAnalysisTabs && this.faultAnalysisTabs.length > 0) {
        this.faultAnalysisTabs.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });
    }

    if (this.faultAnalysisNewView) {
        this.faultAnalysisNewView.classList.toggle('active', tabName === 'new');
    }
    if (this.faultAnalysisHistoryView) {
        this.faultAnalysisHistoryView.classList.toggle('active', tabName === 'history');
    }

    if (tabName === 'history') {
        setTimeout(() => {
            const historyView = document.getElementById('faultAnalysisHistoryView');
            if (historyView) {
                this.cleanupDateTimeFilters();
                this.setupDateTimeFilters(true, historyView);
            }
        }, 100);

        this.clearDateTimeInputValue('faultAnalysisStartTime');
        this.clearDateTimeInputValue('faultAnalysisEndTime');
        const startTime = '';
        const endTime = '';
        const status = document.getElementById('faultAnalysisStatusFilter')?.value || '';
        this.loadFaultAnalysisHistoryList(1, this.faultAnalysisHistoryPageSize, '', startTime, endTime, status);
    }
}

function handleFaultAnalysisSearch() {
    const startTime = this.getDateTimeInputValue('faultAnalysisStartTime');
    const endTime = this.getDateTimeInputValue('faultAnalysisEndTime');
    const status = document.getElementById('faultAnalysisStatusFilter')?.value || '';
    this.loadFaultAnalysisHistoryList(1, this.faultAnalysisHistoryPageSize, '', startTime, endTime, status);
}

function handleFaultAnalysisReset() {
    const statusSelect = document.getElementById('faultAnalysisStatusFilter');
    this.clearDateTimeInputValue('faultAnalysisStartTime');
    this.clearDateTimeInputValue('faultAnalysisEndTime');
    if (statusSelect) statusSelect.value = '';
    this.loadFaultAnalysisHistoryList(1, this.faultAnalysisHistoryPageSize, '', '', '', '');
}

function formatDateTime(date) {
    const year = String(date.getFullYear());
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

async function loadFaultAnalysisHistoryList(page = 1, pageSize = 10, keyword = '', startTime = '', endTime = '', status = '') {
    try {
        const apiKey = this.resolveApiKey();
        if (!apiKey) {
            this.showMessage(this.t('popup.message.apiKeyNotConfigured'), 'error');
            return;
        }

        let username = this.faultAnalysisUserName?.value.trim() || '';

        if (!username) {
            try {
                const result = await chrome.storage.sync.get(['registration']);
                const registration = result.registration;
                if (registration && registration.status === 'registered' && registration.username) {
                    username = registration.username;
                    if (this.faultAnalysisUserName) {
                        this.faultAnalysisUserName.value = username;
                    }
                }
            } catch (error) {
                console.error('获取注册信息失败:', error);
            }
        }

        if (!username || username === '-') {
            this.showMessage(this.t('popup.message.fetchUserInfoFailed'), 'error');
            return;
        }

        const requestBody = {
            pageNum: page,
            pageSize,
            username,
            diagnosisType: 'fault_analysis'
        };

        if (status !== '') {
            requestBody.status = parseInt(status, 10);
        }

        if (startTime) {
            const startDateTime = this.parseISODateTime(startTime);
            if (startDateTime) {
                requestBody.startTime = formatDateTime(startDateTime);
            }
        }

        if (endTime) {
            const endDateTime = this.parseISODateTime(endTime);
            if (endDateTime) {
                endDateTime.setHours(23, 59, 59, 999);
                requestBody.endTime = formatDateTime(endDateTime);
            }
        }

        const url = '/api/diagnosis/list';

        this.showLoadingOverlay(this.t('popup.faultAnalysis.history.loadingHistory'));

        const tempProvider = {
            authType: 'Bearer',
            apiKey: apiKey
        };
        const result = await this.requestUtil.post(url, requestBody, {
            provider: tempProvider
        });

        if (isSuccessfulListResponse(result)) {
            const data = result.data || {};
            const list = data.list || [];

            try {
                await this.i18n.ensureLanguage(this.currentLanguage);
            } catch (ensureError) {
                console.warn('加载故障分析历史记录时语言包未准备就绪:', ensureError);
            }

            this.faultAnalysisHistoryList = list.map(item => {
                const parsedCreateTime = typeof this.parseDateTime === 'function'
                    ? this.parseDateTime(item.createdAt)
                    : item.createdAt;

                let fileName = item.sqlOptimizationFilename
                    || item.sqlOptimizationFileName
                    || item.sqlOptimization_file_name
                    || item.sqlOptimization_filename
                    || item.filename
                    || item.fileName
                    || item.file_name
                    || item.originalFilename
                    || item.originalFileName
                    || item.original_filename
                    || '';

                if (!fileName) {
                    const fileUrl = item.sqlOptimizationFileurl || item.fileUrl || item.file_url || '';
                    if (fileUrl) {
                        try {
                            const urlParts = fileUrl.split('/');
                            fileName = urlParts[urlParts.length - 1] || '';
                            if (fileName.includes('?')) {
                                fileName = fileName.split('?')[0];
                            }
                        } catch (e) {
                            console.warn('从文件URL提取文件名失败:', e);
                        }
                    }
                }

                return {
                    id: item.id,
                    email: item.email || '',
                    language: item.language || 'zh',
                    problemDescription: item.backgroundHint || '',
                    fileName,
                    status: convertStatusNumberToString(item.status),
                    notifyStatus: item.notifyStatus || 'unknown',
                    createTime: parsedCreateTime,
                    reportUrl: item.reportFileurl || null,
                    username: item.username || '',
                    fileUrl: item.sqlOptimizationFileurl || item.fileUrl || null
                };
            });

            this.faultAnalysisHistoryTotal = data.total || 0;
            this.faultAnalysisHistoryCurrentPage = data.pageNum || page;
            this.faultAnalysisHistoryPageSize = data.pageSize || pageSize;

            await this.renderFaultAnalysisHistoryList();
            this.updateFaultAnalysisPagination();
        } else {
            throw new Error(result.message || this.t('popup.faultAnalysis.history.loadFailedFallback'));
        }

        this.hideLoadingOverlay();
    } catch (error) {
        console.error('加载故障分析历史记录失败:', error);
        this.hideLoadingOverlay();
        this.showMessage(this.t('popup.message.faultAnalysisLoadHistoryFailed', { error: error.message || this.t('popup.common.unknownError') }), 'error');
        this.faultAnalysisHistoryList = [];
        this.faultAnalysisHistoryTotal = 0;
        this.faultAnalysisHistoryCurrentPage = 1;
        await this.renderFaultAnalysisHistoryList();
        this.updateFaultAnalysisPagination();
    }
}

function isSuccessfulListResponse(result) {
    return !isBusinessErrorResult(result) && (result?.status === 'success' || result?.status === '200' || Boolean(result?.data));
}

function isBusinessErrorResult(result) {
    return result && typeof result === 'object' && String(result.status || '').toLowerCase() === 'error';
}

async function renderFaultAnalysisHistoryList() {
    const tbody = document.getElementById('faultAnalysisHistoryList');
    const table = document.getElementById('faultAnalysisHistoryTable');
    if (!tbody || !table) return;

    if (!this.faultAnalysisHistoryList || this.faultAnalysisHistoryList.length === 0) {
        tbody.innerHTML = '';
        const tableContainer = table.closest('.awr-history-table-container');
        if (tableContainer) {
            table.style.display = 'none';
            let emptyDiv = tableContainer.querySelector('.empty-history');
            if (!emptyDiv) {
                emptyDiv = document.createElement('div');
                emptyDiv.className = 'empty-history';
                tableContainer.appendChild(emptyDiv);
            }
            const emptyTitle = this.t('popup.faultAnalysis.history.emptyTitle');
            const emptySubtitle = this.t('popup.faultAnalysis.history.emptySubtitle');
            emptyDiv.innerHTML = `
                <div class="empty-history-icon">📝</div>
                <div class="empty-history-text">${escapeHtml(emptyTitle)}</div>
                <div class="empty-history-subtext">${escapeHtml(emptySubtitle)}</div>
            `;
            emptyDiv.style.display = 'block';
        }
        return;
    }

    table.style.display = 'table';
    const tableContainer = table.closest('.awr-history-table-container');
    if (tableContainer) {
        const emptyDiv = tableContainer.querySelector('.empty-history');
        if (emptyDiv) {
            emptyDiv.style.display = 'none';
        }
    }

    tbody.innerHTML = '';
    const rows = await Promise.all(this.faultAnalysisHistoryList.map(item => this.createFaultAnalysisHistoryTableRow(item)));
    rows.forEach(row => tbody.appendChild(row));

    const envType = await this.getEnvType();
    const isInEnv = envType === 'in_env';
    const emailHeader = table.querySelector('thead th[data-i18n="popup.faultAnalysis.table.email"]');
    if (emailHeader) {
        emailHeader.style.display = isInEnv ? 'none' : '';
    }

    const hasRunningTask = this.faultAnalysisHistoryList.some(item => item.status === 'running');
    if (hasRunningTask) {
        this.showLoadingOverlay(this.t('popup.faultAnalysis.history.overlayAnalyzing', '正在执行分析，请稍候...'));
    }
}

async function createFaultAnalysisHistoryTableRow(item) {
    const tr = document.createElement('tr');
    tr.className = 'awr-history-row';

    const locale = this.i18n?.getIntlLocale(this.currentLanguage);
    let createTime = this.t('popup.faultAnalysis.history.unknown');
    if (item.createTime) {
        try {
            const date = new Date(item.createTime);
            if (!Number.isNaN(date.getTime())) {
                createTime = date.toLocaleString(locale);
            }
        } catch (error) {
            console.error('故障分析历史记录日期解析失败:', error);
        }
    }

    const statusText = this.getFaultAnalysisStatusText(item.status);
    const statusClass = this.getFaultAnalysisStatusClass(item.status);
    const notifyStatusText = this.getFaultAnalysisNotifyStatusText(item.notifyStatus);
    const notifyStatusClass = this.getFaultAnalysisNotifyStatusClass(item.notifyStatus);

    const envType = await this.getEnvType();
    const isInEnv = envType === 'in_env';

    const isResendDisabled = item.status !== 'success';
    const resendDisabledAttr = isResendDisabled ? 'disabled' : '';
    const resendDisabledClass = isResendDisabled ? 'disabled' : '';
    const resendTitle = isResendDisabled
        ? this.t('popup.faultAnalysis.history.resendDisabledTooltip')
        : this.t('popup.faultAnalysis.history.resendTooltip');

    const problemDesc = item.problemDescription || '';
    const problemPreview = problemDesc.length > 30 ? `${problemDesc.substring(0, 30)}...` : problemDesc;

    const fileName = item.fileName || '';
    const fileNamePreview = fileName.length > 20 ? `${fileName.substring(0, 20)}...` : fileName;

    const noFileText = this.t('popup.faultAnalysis.history.notSpecified');
    const unknownText = this.t('popup.faultAnalysis.history.unknown');
    const typeText = this.t('popup.faultAnalysis.history.typeLabel', '故障分析');
    const resendButtonLabel = this.t('popup.faultAnalysis.history.resendButton');
    const downloadButtonLabel = this.t('popup.faultAnalysis.history.downloadButton') || '下载';
    const downloadTitle = this.t('popup.faultAnalysis.history.downloadTooltip') || '下载报告';

    const canDownload = item.status === 'success';
    const downloadButtonHtml = canDownload
        ? `<button class="awr-action-btn download-btn" data-id="${escapeHtml(String(item.id ?? ''))}" title="${escapeHtml(downloadTitle)}">
            ${escapeHtml(downloadButtonLabel)}
        </button>`
        : '';

    const resendButtonHtml = isInEnv ? '' : `<button class="awr-action-btn resend-email-btn ${resendDisabledClass}" data-id="${escapeHtml(String(item.id ?? ''))}" title="${escapeHtml(resendTitle)}" ${resendDisabledAttr}>
        ${escapeHtml(resendButtonLabel)}
    </button>`;

    const emailCellHtml = isInEnv ? '' : `<td class="awr-table-cell-email copyable-cell" data-full-text="${escapeHtml(item.email || unknownText)}" title="${escapeHtml(item.email || unknownText)}">${escapeHtml(item.email || unknownText)}</td>`;

    tr.innerHTML = `
        <td class="awr-table-cell-filename copyable-cell" data-full-text="${escapeHtml(fileName || noFileText)}" title="${escapeHtml(fileName || noFileText)}">${escapeHtml(fileNamePreview || noFileText)}</td>
        <td class="awr-table-cell-type">${escapeHtml(typeText)}</td>
        <td class="awr-table-cell-time">${escapeHtml(createTime)}</td>
        <td class="awr-table-cell-problem copyable-cell" data-full-text="${escapeHtml(problemDesc || '-')}" title="${escapeHtml(problemDesc || '-')}">${escapeHtml(problemPreview || '-')}</td>
        ${emailCellHtml}
        <td class="awr-table-cell-status">
            <span class="awr-history-status ${statusClass}">${escapeHtml(statusText)}</span>
        </td>
        <td class="awr-table-cell-notify-status">
            <span class="awr-history-status ${notifyStatusClass}">${escapeHtml(notifyStatusText)}</span>
        </td>
        <td class="awr-table-cell-actions">
            ${resendButtonHtml}
            ${downloadButtonHtml}
        </td>
    `;

    const resendBtn = tr.querySelector('.resend-email-btn');
    if (resendBtn && !isResendDisabled && !isInEnv) {
        resendBtn.addEventListener('click', () => {
            this.handleFaultAnalysisResend(item);
        });
    }

    const downloadBtn = tr.querySelector('.download-btn');
    if (downloadBtn && canDownload) {
        downloadBtn.addEventListener('click', () => {
            this.handleFaultAnalysisDownload(item);
        });
    }

    const copyableCells = tr.querySelectorAll('.copyable-cell');
    copyableCells.forEach(cell => {
        cell.style.cursor = 'pointer';
        cell.addEventListener('click', async (event) => {
            event.stopPropagation();
            const fullText = cell.getAttribute('data-full-text') || cell.textContent.trim();
            if (fullText && fullText !== '-') {
                try {
                    await navigator.clipboard.writeText(fullText);
                    this.showMessage(this.t('popup.common.copySuccess'), 'success', {
                        centered: true,
                        durationMs: 2000,
                        maxWidth: '200px'
                    });
                } catch (err) {
                    console.error('复制失败:', err);
                    this.showMessage('复制失败，请重试', 'error', {
                        centered: true,
                        durationMs: 2000,
                        maxWidth: '200px'
                    });
                }
            }
        });
    });

    return tr;
}

function getFaultAnalysisStatusText(status) {
    const key = {
        'pending': 'popup.faultAnalysis.history.status.pending',
        'success': 'popup.faultAnalysis.history.status.success',
        'failed': 'popup.faultAnalysis.history.status.failed',
        'running': 'popup.faultAnalysis.history.status.running',
        'unknown': 'popup.faultAnalysis.history.status.unknown'
    }[status] || 'popup.faultAnalysis.history.status.unknown';
    return this.t(key);
}

function getFaultAnalysisStatusClass(status) {
    const classMap = {
        'pending': 'status-pending',
        'success': 'status-success',
        'failed': 'status-failed',
        'running': 'status-running',
        'unknown': 'status-unknown'
    };
    return classMap[status] || '';
}

function getFaultAnalysisNotifyStatusText(status) {
    const key = {
        'pending': 'popup.faultAnalysis.history.notifyStatus.pending',
        'success': 'popup.faultAnalysis.history.notifyStatus.success',
        'failed': 'popup.faultAnalysis.history.notifyStatus.failed',
        'unknown': 'popup.faultAnalysis.history.notifyStatus.unknown'
    }[status] || 'popup.faultAnalysis.history.notifyStatus.unknown';
    return this.t(key);
}

function getFaultAnalysisNotifyStatusClass(status) {
    const classMap = {
        'pending': 'status-pending',
        'success': 'status-success',
        'failed': 'status-failed',
        'unknown': 'status-unknown'
    };
    return classMap[status] || '';
}

function updateFaultAnalysisPagination() {
    const totalPages = Math.ceil(this.faultAnalysisHistoryTotal / this.faultAnalysisHistoryPageSize);
    const pageInfo = document.getElementById('faultAnalysisPageInfo');
    const prevBtn = document.getElementById('faultAnalysisPrevPageBtn');
    const nextBtn = document.getElementById('faultAnalysisNextPageBtn');

    if (pageInfo) {
        const safeTotalPages = totalPages > 0 ? totalPages : 1;
        pageInfo.textContent = this.t('popup.faultAnalysis.pagination.info', {
            current: this.faultAnalysisHistoryCurrentPage,
            total: safeTotalPages,
            records: this.faultAnalysisHistoryTotal
        });
    }

    if (prevBtn) {
        prevBtn.disabled = this.faultAnalysisHistoryCurrentPage <= 1;
    }

    if (nextBtn) {
        nextBtn.disabled = this.faultAnalysisHistoryCurrentPage >= totalPages || totalPages === 0;
    }
}

async function handleFaultAnalysisResend(item) {
    if (item.status !== 'success') {
        this.showMessage(this.t('popup.message.resendEmailOnlySuccess'), 'error', { centered: true });
        return;
    }

    try {
        const apiKey = this.resolveApiKey();
        if (!apiKey) {
            this.showMessage(this.t('popup.message.apiKeyNotConfiguredShort'), 'error', { centered: true });
            return;
        }

        const url = `/api/diagnosis/resendEmail?id=${encodeURIComponent(item.id)}`;
        this.showLoadingOverlay(this.t('popup.faultAnalysis.history.resendingEmail'));

        const tempProvider = {
            authType: 'Bearer',
            apiKey: apiKey
        };
        const result = await this.requestUtil.post(url, null, {
            provider: tempProvider,
            redirect: 'follow'
        });

        const successStatuses = ['success', 'ok', '200'];
        const statusStr = String(result.status || '').toLowerCase().trim();
        const isSuccess = statusStr && successStatuses.includes(statusStr);
        const isEmptyStatus = !result.status || result.status === '';

        if (isSuccess || isEmptyStatus) {
            this.hideLoadingOverlay();
            this.showMessage(this.t('popup.message.faultAnalysisResendSuccess'), 'success', { centered: true });
            const startTime = this.getDateTimeInputValue('faultAnalysisStartTime');
            const endTime = this.getDateTimeInputValue('faultAnalysisEndTime');
            const status = document.getElementById('faultAnalysisStatusFilter')?.value || '';
            this.loadFaultAnalysisHistoryList(this.faultAnalysisHistoryCurrentPage, this.faultAnalysisHistoryPageSize, '', startTime, endTime, status);
        } else {
            const errorMessage = result.message || (result.status ? `Resend failed: ${result.status}` : this.t('popup.common.unknownError'));
            throw new Error(errorMessage);
        }
    } catch (error) {
        console.error('故障分析重发邮件失败:', error);
        this.hideLoadingOverlay();
        this.showMessage(this.t('popup.message.faultAnalysisResendFailed', { error: error.message || this.t('popup.common.unknownError') }), 'error', { centered: true });
    }
}

async function handleFaultAnalysisDownload(item) {
    const analysisId = item.id || item.optimization_id;
    if (!analysisId) {
        this.showMessage(this.t('popup.message.downloadFailed') || '下载失败：缺少记录ID', 'error', { centered: true });
        return;
    }

    try {
        const apiKey = this.resolveApiKey();
        if (!apiKey) {
            this.showMessage(this.t('popup.message.apiKeyNotConfiguredShort'), 'error', { centered: true });
            return;
        }

        const baseURL = this.requestUtil?.baseURL || 'http://106.38.159.13:8081';
        const url = new URL('/api/diagnosis/download', baseURL);
        this.showLoadingOverlay(this.t('popup.common.downloading'));

        url.searchParams.append('diagnosis_id', analysisId);

        const response = await fetch(url.toString(), {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Accept-Language': this.getAcceptLanguage ? this.getAcceptLanguage() : 'zh'
            }
        });

        this.hideLoadingOverlay();

        if (!response.ok) {
            throw new Error(`下载失败: HTTP ${response.status} ${response.statusText}`);
        }

        const blob = await response.blob();

        let fileName;
        if (item.fileName) {
            const nameWithoutExt = item.fileName.replace(/\.[^/.]+$/, '');
            fileName = `${nameWithoutExt}.html`;
        } else {
            fileName = `fault_analysis_report_${analysisId}.html`;
        }

        const downloadUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = downloadUrl;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(downloadUrl);
        this.showMessage(this.t('popup.message.downloadSuccess') || '下载成功', 'success', { centered: true });
    } catch (error) {
        console.error('故障分析下载失败:', error);
        this.hideLoadingOverlay();
        this.showMessage(this.t('popup.message.downloadFailed', { error: error.message || this.t('popup.common.unknownError') }), 'error', { centered: true });
    }
}

function convertStatusNumberToString(status) {
    const statusMap = {
        0: 'pending',
        1: 'success',
        2: 'failed',
        3: 'running'
    };
    return statusMap[status] || 'unknown';
}
