import {
    FIXED_CHAT_API_KEY,
    FIXED_CHAT_COMPLETIONS_URL,
    FIXED_CHAT_MODEL
} from '../constants/fixed-chat-api.js';
import { accumulateOpenAIChatCompletionSSE } from '../utils/openai-stream-read.js';

function bindToPopup(fn, popup) {
    return fn.bind(null, popup);
}

export function createQuestionController(popup) {
    return {
        handleAskQuestion: bindToPopup(handleAskQuestion, popup),
        generateQuestionSuggestions: bindToPopup(generateQuestionSuggestions, popup),
        callAPIForSuggestions: bindToPopup(callAPIForSuggestions, popup),
        shouldCheckLetterLimit: bindToPopup(shouldCheckLetterLimit, popup),
        getLetterLimit: bindToPopup(getLetterLimit, popup),
        getExpertTypeFromKnowledgeBase: bindToPopup(getExpertTypeFromKnowledgeBase, popup),
        parseSuggestions: bindToPopup(parseSuggestions, popup)
    };
}

async function handleAskQuestion(popup) {
    if (popup.isProcessing) {
        console.log('正在处理中，忽略重复请求');
        return;
    }

    popup.isProcessing = true;
    popup.hasBeenStopped = false;
    const shouldSkipCheck = popup._skipLetterLimitCheck;
    popup.startTime = Date.now();

    const questionInput = popup.questionInput;
    const knowledgeBaseSelect = popup.knowledgeBaseSelect;
    if (!questionInput) {
        console.error('questionInput 未初始化');
        popup.isProcessing = false;
        return;
    }
    const question = questionInput.value.trim();
    if (!question) {
        popup.showMessage(popup.t('popup.message.enterQuestion'), 'error');
        popup.isProcessing = false;
        return;
    }

    const selectedKnowledgeBase = knowledgeBaseSelect ? knowledgeBaseSelect.value : '';
    if (selectedKnowledgeBase && popup.shouldCheckLetterLimit() && question.length <= popup.getLetterLimit() && !shouldSkipCheck) {
        const conversationContainer = popup.forceCreateNewConversationContainer();
        popup.updateLayoutState();
        popup.setLoading(true);
        await popup.generateQuestionSuggestions(question, selectedKnowledgeBase, conversationContainer);
        popup.isProcessing = false;
        return;
    } else {
        questionInput.value = '';
        popup.updateCharacterCount();
    }

    popup._skipLetterLimitCheck = false;
    const conversationContainer = popup.forceCreateNewConversationContainer();

    if (popup.resultContainer) {
        popup.resultContainer.style.display = 'block';
    }

    popup.updateLayoutState();
    popup.setLoading(true);

    try {
        const knowledgeBaseValue = knowledgeBaseSelect ? knowledgeBaseSelect.value : null;
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const answer = await popup.streamChatWithConfig(question, null, null, knowledgeBaseValue, null, conversationContainer);
        await popup.saveConversationHistory(
            question,
            answer || '',
            'hermes-agent（固定问答接口）',
            knowledgeBaseValue || '',
            tab?.url || ''
        );
    } catch (error) {
        console.error('处理问题失败:', error);
        popup.showErrorResult(popup.t('popup.error.processingFailed', { error: error.message }), 'model', conversationContainer);
    } finally {
        popup.setLoading(false);
        popup.isProcessing = false;
    }
}

async function generateQuestionSuggestions(popup, shortQuestion, knowledgeBase, conversationContainer) {
    try {
        popup.updateQuestionDisplay(shortQuestion, conversationContainer);
        const resultTitle = conversationContainer.querySelector('.result-title');
        if (resultTitle) {
            resultTitle.textContent = popup.t('popup.suggestion.generating');
        }

        const expertType = popup.getExpertTypeFromKnowledgeBase(knowledgeBase);
        const prompt = `你是一个${expertType}专家，你的任务是补全上述意图生成三条意思相近的用户查询，要求每条生成字数不能少于10字，返回的结果以数组形式放在固定字段。用户输入：${shortQuestion}`;
        const suggestions = await popup.callAPIForSuggestions(prompt, shortQuestion);
        popup.displaySuggestions(suggestions, conversationContainer);
    } catch (error) {
        console.error('生成建议问题失败:', error);
        popup.showErrorResult(popup.t('popup.error.suggestionFailed'), 'error', conversationContainer);
    }
    popup.addToCurrentSessionHistory(shortQuestion, "已生成建议问题");
}

function getExpertTypeFromKnowledgeBase(popup, knowledgeBase) {
    const kbLower = (knowledgeBase || '').toLowerCase();
    if (kbLower.includes('oracle')) {
        return 'Oracle数据库';
    } else if (kbLower.includes('mysql')) {
        return 'MySQL数据库';
    } else if (kbLower.includes('postgresql') || kbLower.includes('postgres')) {
        return 'PostgreSQL数据库';
    } else if (kbLower.includes('sqlserver') || kbLower.includes('sql server')) {
        return 'SQL Server数据库';
    } else if (kbLower.includes('mongodb') || kbLower.includes('mongo')) {
        return 'MongoDB数据库';
    }
    return '数据库';
}

async function callAPIForSuggestions(popup, prompt, originalQuestion = '') {
    console.log('callAPIForSuggestions=======');

    const suggestionSystemPrompt = popup.applyLanguageInstructionToSystemContent(
        "你是一名资深数据库专家，需要根据用户意图补全并生成相似问题。",
        originalQuestion
    );

    const userContent = `${suggestionSystemPrompt}\n\n${prompt}`;

    const response = await fetch(FIXED_CHAT_COMPLETIONS_URL, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${FIXED_CHAT_API_KEY}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            model: FIXED_CHAT_MODEL,
            messages: [
                {
                    role: 'user',
                    content: userContent
                }
            ],
            stream: true
        })
    });

    if (!response.ok) {
        let errorText = '';
        try {
            errorText = await response.text();
        } catch (_) {
            errorText = response.statusText || popup.t('popup.common.unknownError');
        }
        throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    const cloned = response.clone();
    let content = await accumulateOpenAIChatCompletionSSE(response);
    content = String(content || '').trim();
    if (!content) {
        try {
            const result = await cloned.json();
            content = String(result?.choices?.[0]?.message?.content || '').trim();
        } catch (_) {
            const txt = await cloned.text();
            content = String(
                await accumulateOpenAIChatCompletionSSE(new Response(txt))
            ).trim();
        }
    }
    if (!content) {
        throw new Error(popup.t('popup.error.modelCallFailed'));
    }
    return popup.parseSuggestions(content);
}

function shouldCheckLetterLimit(popup) {
    return popup.knowledgeServiceConfig && popup.knowledgeServiceConfig.isOpenLetterLimit === true;
}

function getLetterLimit(popup) {
    return popup.knowledgeServiceConfig && popup.knowledgeServiceConfig.letter_limit ?
        popup.knowledgeServiceConfig.letter_limit : 5;
}

function parseSuggestions(popup, content) {
    const trimmedContent = (content || '').trim();
    if (!trimmedContent) {
        return getFallbackSuggestions(popup);
    }

    try {
        const parsed = JSON.parse(trimmedContent);
        if (Array.isArray(parsed)) {
            const valid = parsed.filter(s => typeof s === 'string' && s.trim().length > 0);
            if (valid.length > 0) {
                return valid.slice(0, 3).map(s => s.trim());
            }
        }
        if (parsed && parsed.queries && Array.isArray(parsed.queries)) {
            const valid = parsed.queries.filter(s => typeof s === 'string' && s.trim().length > 0);
            if (valid.length > 0) {
                return valid.slice(0, 3).map(s => s.trim());
            }
        }
    } catch (e) {
        const jsonMatch = trimmedContent.match(/\[[\s\S]*?\]/);
        if (jsonMatch) {
            try {
                const arr = JSON.parse(jsonMatch[0]);
                if (Array.isArray(arr)) {
                    const valid = arr.filter(s => typeof s === 'string' && s.trim().length > 0);
                    if (valid.length > 0) {
                        return valid.slice(0, 3).map(s => s.trim());
                    }
                }
            } catch (_) {
                // 忽略，继续尝试其他解析方式
            }
        }
        console.log('JSON解析失败，尝试其他解析逻辑:', e);
    }

    const suggestions = [];
    const lines = trimmedContent.split('\n');

    for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed && (trimmed.startsWith('1.') || trimmed.startsWith('2.') || trimmed.startsWith('3.') ||
            trimmed.startsWith('1、') || trimmed.startsWith('2、') || trimmed.startsWith('3、'))) {
            const suggestion = trimmed.replace(/^[123][\.、]\s*/, '').trim();
            if (suggestion.length >= 10) {
                suggestions.push(suggestion);
            }
        }
    }

    if (suggestions.length === 0) {
        return getFallbackSuggestions(popup);
    }
    return suggestions.slice(0, 3);
}

function getFallbackSuggestions(popup) {
    return [
        popup.t('popup.suggestion.fallback1'),
        popup.t('popup.suggestion.fallback2'),
        popup.t('popup.suggestion.fallback3')
    ];
}
