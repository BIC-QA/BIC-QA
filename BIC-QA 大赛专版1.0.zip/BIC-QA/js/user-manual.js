document.addEventListener('DOMContentLoaded', () => {
  const progressBar = document.getElementById('progress-bar-inner');
  const backTop = document.getElementById('back-top');
  const sections = document.querySelectorAll('[id]');
  const navLinks = document.querySelectorAll('.sidebar-link');
  const searchInput = document.getElementById('searchInput');
  const searchResults = document.getElementById('searchResults');
  const searchTargets = Array.from(document.querySelectorAll('.hero, .section-card')).map((target) => {
    const title = target.querySelector('.section-title, h1')?.textContent?.trim() || target.id || '未命名章节';
    return { element: target, title };
  });

  function updateScrollUi() {
    const scrolled = window.scrollY;
    const total = document.body.scrollHeight - window.innerHeight;
    if (progressBar) {
      progressBar.style.width = `${(scrolled / total) * 100}%`;
    }
    if (backTop) {
      backTop.classList.toggle('visible', scrolled > 300);
    }
  }

  window.addEventListener('scroll', updateScrollUi);
  updateScrollUi();

  if (backTop) {
    backTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        navLinks.forEach((link) => link.classList.remove('active'));
        const link = document.querySelector(`.sidebar-link[href="#${entry.target.id}"]`);
        if (link) link.classList.add('active');
      }
    });
  }, { rootMargin: `-${64 + 32}px 0px -60% 0px` });
  sections.forEach((section) => observer.observe(section));

  function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function clearHighlights(root) {
    root.querySelectorAll('mark.search-hit').forEach((mark) => {
      mark.replaceWith(document.createTextNode(mark.textContent));
    });
    root.normalize();
  }

  function highlightMatches(root, query) {
    if (!query) return 0;

    const source = escapeRegExp(query);
    const testRegex = new RegExp(source, 'i');
    const regex = new RegExp(source, 'gi');
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        if (['SCRIPT', 'STYLE', 'MARK'].includes(parent.tagName)) return NodeFilter.FILTER_REJECT;
        if (parent.closest('.topbar, .sidebar')) return NodeFilter.FILTER_REJECT;
        if (!testRegex.test(node.nodeValue)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    const textNodes = [];
    while (walker.nextNode()) {
      textNodes.push(walker.currentNode);
    }

    let count = 0;
    textNodes.forEach((node) => {
      const text = node.nodeValue;
      const fragment = document.createDocumentFragment();
      let lastIndex = 0;

      text.replace(regex, (match, offset) => {
        if (offset > lastIndex) {
          fragment.appendChild(document.createTextNode(text.slice(lastIndex, offset)));
        }
        const mark = document.createElement('mark');
        mark.className = 'search-hit';
        mark.textContent = match;
        fragment.appendChild(mark);
        lastIndex = offset + match.length;
        count += 1;
        return match;
      });

      if (lastIndex < text.length) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
      }

      node.replaceWith(fragment);
    });

    return count;
  }

  function getExcerpt(text, query) {
    const normalizedText = text.replace(/\s+/g, ' ').trim();
    const lowerText = normalizedText.toLocaleLowerCase();
    const lowerQuery = query.toLocaleLowerCase();
    const index = lowerText.indexOf(lowerQuery);
    if (index === -1) return normalizedText.slice(0, 72);
    const start = Math.max(0, index - 18);
    const end = Math.min(normalizedText.length, index + query.length + 30);
    const prefix = start > 0 ? '...' : '';
    const suffix = end < normalizedText.length ? '...' : '';
    return `${prefix}${normalizedText.slice(start, end)}${suffix}`;
  }

  function renderSearchResults(results, query) {
    if (!searchResults) return;

    if (!query) {
      searchResults.innerHTML = '';
      searchResults.classList.remove('visible');
      return;
    }

    if (!results.length) {
      searchResults.innerHTML = `<div class="search-result-empty">没有找到“${query}”</div>`;
      searchResults.classList.add('visible');
      return;
    }

    const items = results.slice(0, 6).map(({ element, title }) => {
      const excerpt = getExcerpt(element.textContent, query)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      const safeTitle = title
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      return `
        <button type="button" class="search-result-item" data-target-id="${element.id}">
          <span class="search-result-title">${safeTitle}</span>
          <span class="search-result-excerpt">${excerpt}</span>
        </button>
      `;
    }).join('');

    searchResults.innerHTML = `
      <div class="search-result-meta">找到 ${results.length} 个匹配章节</div>
      ${items}
    `;
    searchResults.classList.add('visible');
  }

  function runSearch({ focusFirst = false } = {}) {
    if (!searchInput) return;
    const query = searchInput.value.trim();

    searchTargets.forEach(({ element }) => {
      clearHighlights(element);
      element.classList.remove('search-hidden');
    });

    if (!query) {
      renderSearchResults([], '');
      return;
    }

    const matchedSections = [];
    let firstMatch = null;
    const normalizedQuery = query.toLocaleLowerCase();

    searchTargets.forEach((target) => {
      const text = target.element.textContent.toLocaleLowerCase();
      if (text.includes(normalizedQuery)) {
        highlightMatches(target.element, query);
        matchedSections.push(target);
        if (!firstMatch) firstMatch = target.element;
      } else {
        target.element.classList.add('search-hidden');
      }
    });

    renderSearchResults(matchedSections, query);

    if (focusFirst && firstMatch) {
      firstMatch.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', () => runSearch());
    searchInput.addEventListener('change', () => runSearch({ focusFirst: true }));
    searchInput.addEventListener('compositionend', () => runSearch());
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        runSearch({ focusFirst: true });
      }
      if (e.key === 'Escape') {
        searchInput.value = '';
        runSearch();
      }
    });

    searchInput.addEventListener('focus', () => {
      if (searchInput.value.trim() && searchResults) {
        searchResults.classList.add('visible');
      }
    });
  }

  if (searchResults) {
    searchResults.addEventListener('click', (e) => {
      const item = e.target.closest('.search-result-item');
      if (!item) return;
      const target = document.getElementById(item.dataset.targetId);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  }

  document.addEventListener('click', (e) => {
    if (searchResults && !e.target.closest('.topbar-search-wrap')) {
      searchResults.classList.remove('visible');
    }
  });

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (e) => {
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
});
