// 初始化 RequestUtil 并暴露到全局作用域
import { createRequestUtil } from './popup/utils/request.js';
window.createRequestUtil = createRequestUtil;