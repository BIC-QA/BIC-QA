/**
 * 赛事首页「配套资料」——配套 zip 直链（Gitee Release，浏览器与扩展统一下载地址）。
 * 更新版本时修改 GITEE_RELEASE_DOWNLOAD_BASE（tag）与 CONTEST_MATERIALS_DOWNLOAD_FILENAME（与附件名一致）。
 */
const GITEE_RELEASE_DOWNLOAD_BASE =
    'https://gitee.com/BIC-QA/bic-qa/releases/download/v1.0.6/';

/** 下载保存时的建议文件名（与压缩包原名一致） */
export const CONTEST_MATERIALS_DOWNLOAD_FILENAME =
    'KES 赛事配套资料包_20260509_V1.0.zip';

/** 路径随附件名 UTF-8 编码，与 Gitee 发布页直链一致 */
export const CONTEST_MATERIALS_DOWNLOAD_URL =
    GITEE_RELEASE_DOWNLOAD_BASE +
    encodeURIComponent(CONTEST_MATERIALS_DOWNLOAD_FILENAME);

/** 「关于大赛」浏览器打开的静态页（与服务器 /devkit/ 下文件一致） */
export const ABOUT_CONTEST_PAGE_URL =
    'http://106.38.159.13:8081/devkit/about-contest.html';
