import { BicQAPopup } from './app.js';
import { ABOUT_CONTEST_PAGE_URL } from './constants/contest-links.js';

let appInstance = null;
const SERVER_ASSET_BASE_URL = 'https://res.bic-qa.com/static';

function getLocalAssetUrl(fileName) {
    if (typeof chrome !== 'undefined' && chrome.runtime?.getURL) {
        return chrome.runtime.getURL(`icons/${fileName}`);
    }

    return `../icons/${fileName}`;
}

function getServerAssetUrl(fileName) {
    return `${SERVER_ASSET_BASE_URL}/${fileName}`;
}

function checkImageAccess(url) {
    return new Promise((resolve) => {
        const img = new Image();
        let settled = false;
        const finish = (isAccessible) => {
            if (settled) return;
            settled = true;
            resolve(isAccessible);
        };

        img.onload = () => finish(true);
        img.onerror = () => finish(false);
        img.src = url;
        setTimeout(() => finish(false), 5000);
    });
}

async function loadImageWithFallback(element, serverUrl, localUrl, assetName) {
    if (!element) {
        console.log(`未找到图片元素: ${assetName}`);
        return;
    }

    const applyUrl = (url) => {
        if (element.tagName?.toLowerCase() === 'link') {
            element.href = url;
        } else {
            element.src = url;
        }
    };

    try {
        console.log(`检查服务器图片(${assetName}):`, serverUrl);
        const isServerAccessible = await checkImageAccess(serverUrl);

        element.onerror = function() {
            console.log(`服务器图片(${assetName})加载失败，回退到本地图片`);
            this.onerror = null;
            applyUrl(localUrl);
        };
        applyUrl(isServerAccessible ? serverUrl : localUrl);
    } catch (error) {
        console.error(`加载图片(${assetName})失败:`, error);
        applyUrl(localUrl);
    }
}

function getLogoFileName(isDarkMode) {
    return isDarkMode ? 'logo_dark.png' : 'logo.png';
}

function getFaviconFileName(isDarkMode) {
    return 'kingbase-mark.png';
}

function bindFullscreenListeners(instance) {
    const handler = () => {
        if (typeof instance.handleFullscreenChange === 'function') {
            instance.handleFullscreenChange();
        }
    };

    document.addEventListener('fullscreenchange', handler);
    document.addEventListener('webkitfullscreenchange', handler);
    document.addEventListener('mozfullscreenchange', handler);
    document.addEventListener('MSFullscreenChange', handler);
}

// 更新页面favicon
function updateFavicon(isDarkMode) {
    try {
        const favicon = document.getElementById('favicon');
        const iconFileName = getFaviconFileName(isDarkMode);
        if (favicon) {
            favicon.type = 'image/png';
        }
        loadImageWithFallback(
            favicon,
            getServerAssetUrl(iconFileName),
            getLocalAssetUrl(iconFileName),
            `favicon-${isDarkMode ? 'dark' : 'light'}`
        );
    } catch (error) {
        console.error('更新favicon失败:', error);
    }
}

function updateHomeLogo(isDarkMode) {
    const bicLogoFileName = getLogoFileName(isDarkMode);
    loadImageWithFallback(
        document.querySelector('.sponsor-logo-main'),
        getServerAssetUrl('kingbase-logo.png'),
        getLocalAssetUrl('kingbase-logo.png'),
        '主办单位logo'
    );

    loadImageWithFallback(
        document.querySelector('.sponsor-logo-hygon'),
        getServerAssetUrl('hygon-logo.png'),
        getLocalAssetUrl('hygon-logo.png'),
        '协办单位-HYGON-logo'
    );

    loadImageWithFallback(
        document.querySelector('.sponsor-logo-bic'),
        getServerAssetUrl(bicLogoFileName),
        getLocalAssetUrl(bicLogoFileName),
        `协办单位-BIC-QA-logo-${isDarkMode ? 'dark' : 'light'}`
    );
}

function updateContactIcon() {
    loadImageWithFallback(
        document.querySelector('.contact-icon'),
        getServerAssetUrl('chatUs.png'),
        getLocalAssetUrl('chatUs.png'),
        '联系方式图标'
    );
}

function updateHomeAssets(isDarkMode) {
    updateFavicon(isDarkMode);
    updateHomeLogo(isDarkMode);
    updateContactIcon();
}

// 检测系统主题并通知background更新图标
function detectAndUpdateIcon() {
    try {
        // 检测系统主题
        const isDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;

        // 更新首页图片资源
        updateHomeAssets(isDarkMode);
        // 更新GitHub图标主题
        if (window.bicQAPopup && window.bicQAPopup.updateGitHubIconTheme) {
            window.bicQAPopup.updateGitHubIconTheme(isDarkMode);
        }
        
        // 通知background更新扩展图标
        chrome.runtime.sendMessage({
            action: 'updateIcon',
            isDarkMode: isDarkMode
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.log('通知background更新图标失败:', chrome.runtime.lastError);
            } else {
                console.log('已通知background更新图标:', isDarkMode ? '深色模式' : '浅色模式');
            }
        });
        
        // 监听主题变化
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        mediaQuery.addEventListener('change', (e) => {
            const newIsDarkMode = e.matches;
            // 更新首页图片资源
            updateHomeAssets(newIsDarkMode);
            // 更新更新图标主题
            if (window.bicQAPopup && window.bicQAPopup.updateUpdateIconTheme) {
                window.bicQAPopup.updateUpdateIconTheme();
            }
            // 更新github图标主题
            if (window.bicQAPopup && window.bicQAPopup.updateGitHubIconTheme) {
                window.bicQAPopup.updateGitHubIconTheme(newIsDarkMode);
            }
            // 通知background更新扩展图标
            chrome.runtime.sendMessage({
                action: 'updateIcon',
                isDarkMode: newIsDarkMode
            }, (response) => {
                if (chrome.runtime.lastError) {
                    console.log('通知background更新图标失败:', chrome.runtime.lastError);
                } else {
                    console.log('主题变化，已通知background更新图标:', newIsDarkMode ? '深色模式' : '浅色模式');
                }
            });
        });
    } catch (error) {
        console.error('检测主题失败:', error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    appInstance = new BicQAPopup();

    window.app = appInstance;
    window.bicQAPopup = appInstance;

    initContestPageMode(appInstance);

    bindFullscreenListeners(appInstance);
    
    // 检测主题并更新图标（异步执行，不阻塞）
    setTimeout(() => {
        detectAndUpdateIcon();
    }, 0);

    // 初始化popup二维码加载（异步执行，不阻塞）
    setTimeout(() => {
        initPopupQRCodes();
    }, 0);
});

function initContestPageMode(instance) {
    const contentArea = document.querySelector('.content-area');
    const aboutContestBtn = document.getElementById('aboutContestBtn');
    const knowledgeQaBtn = document.getElementById('knowledgeQaBtn');
    const questionInput = document.getElementById('questionInput');

    if (!contentArea) {
        return;
    }

    const switchToQaMode = () => {
        contentArea.classList.add('contest-qa-mode');
        instance.updateLayoutState?.();
        if (questionInput) {
            setTimeout(() => questionInput.focus(), 0);
        }
    };

    switchToQaMode();

    aboutContestBtn?.addEventListener('click', () => {
        if (typeof chrome !== 'undefined' && chrome.tabs?.create) {
            chrome.tabs.create({ url: ABOUT_CONTEST_PAGE_URL });
        } else {
            window.open(ABOUT_CONTEST_PAGE_URL, '_blank', 'noopener,noreferrer');
        }
    });
    knowledgeQaBtn?.addEventListener('click', switchToQaMode);
}

// 初始化popup页面的二维码加载
function initPopupQRCodes() {
    // 加载单个二维码
    async function loadQrcode(elementId, serverUrl, localUrl, qrName) {
        loadImageWithFallback(document.getElementById(elementId), serverUrl, localUrl, qrName);
    }

    // 加载DBAIOps社区二维码
    loadQrcode(
        'popup-qr-code',
        getServerAssetUrl('publicNum-QRcode.jpg'),
        getLocalAssetUrl('publicNum-QRcode.jpg'),
        'DBAIOps社区二维码'
    );

    // 加载金仓社区二维码
    loadQrcode(
        'popup-qr-code-wechat',
        getServerAssetUrl('kingbase-community-qrcode.png'),
        getLocalAssetUrl('kingbase-community-qrcode.png'),
        '金仓社区二维码'
    );
}

export { appInstance as app };
